# =============================================================================
# KILL ZONE — PERFORMANCE / MORALE / CLEANUP HARDENING PASS
# =============================================================================
# Focuses on stable frame pacing and believable unit behavior.  There are no
# graphics-quality tiers: the simple tactical presentation is kept intact and
# the renderer is made cheaper instead.

_KZ_VISUAL_TERRAIN_REV = 0
_perf_prev_cell_reset = Cell.reset_terrain
def _perf_cell_reset(self, terrain, axis=None):
    global _KZ_VISUAL_TERRAIN_REV
    before=(self.terrain,self.axis,self.door_open)
    _perf_prev_cell_reset(self,terrain,axis)
    if before!=(self.terrain,self.axis,self.door_open):
        _KZ_VISUAL_TERRAIN_REV += 1
Cell.reset_terrain=_perf_cell_reset

_KZ_SMOKE_REV = 0
# LOS caches are deliberately short lived (80–100 ms).  Runtime smoke only
# changes as simulation time advances, so the cache's time bucket already
# invalidates it before the next meaningful smoke update.  Keeping Cell.smoke
# as a normal dataclass attribute avoids property/__setattr__ overhead in the
# 2,000-cell weather loop.

_perf_prev_toggle_door=RealTimeGame.toggle_door
def _perf_toggle_door(self,u,pos):
    global _KZ_VISUAL_TERRAIN_REV
    x,y=pos if pos else (-1,-1)
    before=self.grid[y][x].door_open if self.in_bounds(x,y) and self.grid[y][x].terrain=='door' else None
    _perf_prev_toggle_door(self,u,pos)
    after=self.grid[y][x].door_open if self.in_bounds(x,y) and self.grid[y][x].terrain=='door' else None
    if before is not None and before!=after:_KZ_VISUAL_TERRAIN_REV+=1
RealTimeGame.toggle_door=_perf_toggle_door


# ------------------------------ unit state model -----------------------------
_perf_prev_add_unit2=RealTimeGame.add_unit
def _perf_add_unit(self,faction,role,x,y):
    u=_perf_prev_add_unit2(self,faction,role,x,y)
    u.morale_state='STEADY';u.low_morale_since=None;u.breaking_since=None
    u.rout_started_at=0.0;u.rally_target=None;u.rallying=False;u.rally_safe_since=None
    u.hold_position=False;u.survival_react_at=0.0;u.squad_morale=100.0
    u.rally_shock=0.0;u._cleanup_state=None
    return u
RealTimeGame.add_unit=_perf_add_unit

_perf_prev_rt_init2=RealTimeGame.__init__
def _perf_rt_init(self,*args,**kwargs):
    self._los_cache={};self._line_cache={};self._last_visual_terrain_rev=-1
    self.profile_enabled=False;self._intensity_timer=0.0;self._sector_low_since={s:None for s in ('NORTH','CENTRE','SOUTH')}
    _perf_prev_rt_init2(self,*args,**kwargs)
    self._perf.update({'los_ms':0.0,'los_calls':0,'los_hits':0,'line_calls':0,'line_hits':0})
    self._last_visual_terrain_rev=_KZ_VISUAL_TERRAIN_REV
RealTimeGame.__init__=_perf_rt_init


def _perf_cleanup_unit(self,u,reason='combat exit'):
    state=(u.casualty,bool(u.combat_effective))
    if getattr(u,'_cleanup_state',None)==state:return
    u._cleanup_state=state
    u.overwatch=False;u.fire_lane=False;u.target_uid=None;u.target_pos=None
    u.reaction_target_uid=None;u.covering_uid=None;u.path=[];u.waypoints=[];u.command_queue=[]
    u.command_delay_until=0;u.reaction_ready_at=0;u.traverse_ready_at=0
    if u.dragging_uid is not None:u.dragging_uid=None
    if u.carrying_uid is not None:u.carrying_uid=None
    for other in self.units:
        if other.uid==u.uid:continue
        if other.target_uid==u.uid:
            other.target_uid=None
            if other.order=='fire':other.order='idle'
        if other.reaction_target_uid==u.uid:other.reaction_target_uid=None
        if other.covering_uid==u.uid:other.covering_uid=None
        if other.dragging_uid==u.uid:other.dragging_uid=None
        if other.carrying_uid==u.uid:other.carrying_uid=None
    for bo in list(self.bounding_orders):
        bo.a=[i for i in bo.a if i!=u.uid];bo.b=[i for i in bo.b if i!=u.uid]
        if not bo.a and not bo.b:self.bounding_orders.remove(bo)
    for ao in list(getattr(self,'assault_orders',[])):
        ao.support=[i for i in ao.support if i!=u.uid];ao.assault=[i for i in ao.assault if i!=u.uid]
        if not ao.assault:self.assault_orders.remove(ao)
    if hasattr(self,'_occupancy') and self._occupancy.get(u.tile)==u.uid and not u.combat_effective:
        self._occupancy.pop(u.tile,None)
RealTimeGame.cleanup_unit_state=_perf_cleanup_unit


def _perf_retreat_position(self,u,extra_rear=False):
    # Explicit fallback orders win.  Otherwise prefer protected rearward terrain,
    # communication trenches and low known threat rather than simply running to an edge.
    fp=getattr(u,'fallback_point',None)
    if fp and self.in_bounds(*fp) and self.passable(*fp,u):return fp
    ux,uy=u.tile;direction=-1 if u.faction=='player' else 1
    best=None;best_score=-1e9
    radius=11 if extra_rear else 8
    for y in range(max(1,uy-radius),min(MAP_H-1,uy+radius+1)):
        for x in range(max(1,ux-radius),min(MAP_W-1,ux+radius+1)):
            if not self.passable(x,y,u):continue
            dx=(x-ux)*direction
            if dx<1 and not extra_rear:continue
            d=math.hypot(x-ux,y-uy)
            if d<2.0:continue
            c=self.grid[y][x];cover=TERRAIN[c.terrain]['cover'];th=self.tile_threat(u.faction,x,y)
            terrain_bonus=3.5 if c.terrain in ('trench','firing_step','dugout','bunker') else 2.0 if c.terrain in ('foxhole','sandbags','crater','woods') else 0
            score=cover*3.0+terrain_bonus+dx*(.45 if extra_rear else .28)-th*3.2-c.ground_suppression*.035-d*.20
            if score>best_score:best_score=score;best=(x,y)
    if best:return best
    return self.rally_points.get(u.faction,(2 if u.faction=='player' else MAP_W-3,int(clamp(uy,1,MAP_H-2))))
RealTimeGame.choose_retreat_position=_perf_retreat_position


def _perf_morale_breakdown(self,u):
    allies=[a for a in self.living(u.faction) if a.uid!=u.uid and a.combat_effective and dist(a,u)<5]
    cross=self.crossfire_pressure(u);c=self.grid[u.tile[1]][u.tile[0]];cover=max(0,TERRAIN[c.terrain]['cover']-c.cover_wear*2.2)
    factors=[('suppression',u.suppression*.34),('cohesion loss',(100-u.cohesion)*.20),('recent casualty shock',getattr(u,'rally_shock',0)*.70),('crossfire',cross*18)]
    if not allies:factors.append(('isolated',12))
    else:factors.append(('nearby squadmates',-min(18,len(allies)*4.5)))
    if cover>0:factors.append(('protected position',-cover*3.0))
    sm=getattr(u,'squad_morale',50)
    if sm>=65:factors.append(('squad confidence',-8))
    elif sm<35:factors.append(('squad shaken',8))
    return factors
RealTimeGame.morale_breakdown=_perf_morale_breakdown


def _perf_set_morale_state(self,u):
    if u.casualty=='surrendered':state='SURRENDERED'
    elif u.order=='rout':state='ROUTING'
    elif getattr(u,'rallying',False):state='RALLYING'
    elif u.suppression>=80:state='PINNED'
    elif u.morale<24 or u.cohesion<35:state='BREAKING' if u.low_morale_since is not None and self.time-u.low_morale_since>3 else 'SHAKEN'
    elif u.morale<58 or u.cohesion<58 or u.suppression>=42:state='SHAKEN'
    else:state='STEADY'
    u.morale_state=state
    return state
RealTimeGame.update_unit_morale_state=_perf_set_morale_state


# -------------------------- cached visibility / LOS --------------------------
_perf_prev_line_info=RealTimeGame.line_info
def _perf_line_info(self,a,b):
    tick=int(self.time*10)
    key=(round(a[0],1),round(a[1],1),round(b[0],1),round(b[1],1),self._terrain_revision,tick)
    cached=self._line_cache.get(key)
    prof=getattr(self,'profile_enabled',False)
    if cached is not None:
        if prof:self._perf['line_hits']=self._perf.get('line_hits',0)+1
        return cached
    t0=time.perf_counter() if prof else 0
    out=_perf_prev_line_info(self,a,b)
    self._line_cache[key]=out
    if len(self._line_cache)>900:self._line_cache.clear();self._line_cache[key]=out
    if prof:
        self._perf['line_calls']=self._perf.get('line_calls',0)+1;self._perf['los_ms']=self._perf.get('los_ms',0)+(time.perf_counter()-t0)*1000
    return out
RealTimeGame.line_info=_perf_line_info

_perf_prev_can_see2=RealTimeGame.can_see
def _perf_can_see(self,observer,target):
    tick=int(self.time*8)
    key=(observer.uid,target.uid,observer.tile,target.tile,observer.stance,target.stance,self._terrain_revision,tick)
    cached=self._los_cache.get(key);prof=getattr(self,'profile_enabled',False)
    if cached is not None:
        if prof:self._perf['los_hits']=self._perf.get('los_hits',0)+1
        return cached
    t0=time.perf_counter() if prof else 0
    out=_perf_prev_can_see2(self,observer,target);self._los_cache[key]=out
    if len(self._los_cache)>700:self._los_cache.clear();self._los_cache[key]=out
    if prof:
        self._perf['los_calls']=self._perf.get('los_calls',0)+1;self._perf['los_ms']=self._perf.get('los_ms',0)+(time.perf_counter()-t0)*1000
    return out
RealTimeGame.can_see=_perf_can_see


# ---------------------------- morale / rally loop ----------------------------
_perf_prev_cohesion=RealTimeGame.update_cohesion_and_morale
def _perf_cohesion(self,dt):
    _perf_prev_cohesion(self,dt)
    # Build living/faction lists once.  The earlier version called living(faction)
    # for every soldier, turning this 3 Hz morale pass into avoidable O(n^2) list
    # allocation on top of the actual proximity work.
    active=[u for u in self.units if u.alive and u.combat_effective]
    by_faction={'player':[],'enemy':[]}
    groups={}
    for u in active:
        by_faction.setdefault(u.faction,[]).append(u)
        groups.setdefault((u.faction,getattr(u,'squad_id',0)),[]).append(u)
    for members in groups.values():
        inv=1.0/max(1,len(members))
        squad=clamp(sum(m.morale*.50+m.cohesion*.35+(100-m.suppression)*.15 for m in members)*inv,0,100)
        for u in members:u.squad_morale=squad
    for u in active:
        cell=self.grid[u.tile[1]][u.tile[0]];safe=u.under_fire_until<=self.time and cell.ground_suppression<18 and u.suppression<38
        ux,uy=u.x,u.y;near=0
        for a in by_faction.get(u.faction,()):
            if a.uid!=u.uid:
                dx=a.x-ux;dy=a.y-uy
                if dx*dx+dy*dy<25:near+=1
        if safe:
            # Most morale shock is temporary. Cover and squad presence accelerate rallying.
            rec=dt*(1.15+min(4,TERRAIN[cell.terrain]['cover'])*.18+min(3,near)*.12)
            u.morale=clamp(u.morale+rec,0,100);u.cohesion=clamp(u.cohesion+dt*(.45+near*.10),0,100)
            if u.rally_shock>0:
                refund=min(u.rally_shock,dt*.95);u.rally_shock-=refund;u.morale=clamp(u.morale+refund*.65,0,100)
        else:u.rally_shock=max(0,u.rally_shock-dt*.12)
        severe=u.morale<24 and (u.suppression>65 or u.cohesion<45)
        if severe and u.low_morale_since is None:u.low_morale_since=self.time
        elif not severe and u.morale>30 and u.suppression<68:u.low_morale_since=None;u.breaking_since=None
        self.update_unit_morale_state(u)
RealTimeGame.update_cohesion_and_morale=_perf_cohesion


def _perf_handle_break(self,u):
    if not u.combat_effective:return
    now=self.time;cross=self.crossfire_pressure(u)
    # Suppression alone pins. It no longer makes a healthy soldier instantly run.
    if u.suppression>=88:
        u.morale_state='PINNED';u.overwatch=False;u.fire_lane=False;u.stance='prone'
        if u.order in ('overwatch','fire_lane','fire') and u.suppression>=94:u.order='idle';u.target_uid=None;u.target_pos=None
        if u.suppression>=95 and not getattr(u,'hold_position',False) and u.auto_cover and now>=getattr(u,'survival_react_at',0):
            u.survival_react_at=now+2.2
            dest=self.find_nearby_cover(u,3)
            if dest and dest!=u.tile:self.issue_move([u],dest,mode='safe',formation='column')
    severe=u.morale<16 and (u.cohesion<48 or u.suppression>86 or cross>.55)
    catastrophic=u.morale<6 and u.cohesion<28
    if not severe and not catastrophic:return
    if u.low_morale_since is None:u.low_morale_since=now
    elapsed=now-u.low_morale_since
    allies=sum(1 for a in self.living(u.faction) if a.uid!=u.uid and a.combat_effective and dist(a,u)<5)
    delay=7.0
    if getattr(u,'squad_morale',50)>=60:delay+=2.0
    elif getattr(u,'squad_morale',50)<28:delay-=1.2
    if allies==0:delay-=1.0
    if cross>.65:delay-=.8
    if getattr(u,'hold_position',False):delay+=3.5
    if catastrophic:delay=min(delay,5.0 if getattr(u,'hold_position',False) else 3.5)
    u.breaking_since=u.low_morale_since
    u.morale_state='BREAKING' if elapsed>=delay*.45 else 'PINNED'
    if elapsed<delay:return
    enemies=[e for e in self.living('enemy' if u.faction=='player' else 'player') if e.combat_effective]
    nearest=min((dist(u,e) for e in enemies),default=99)
    if nearest<3.4 and allies==0 and u.morale<7 and not getattr(u,'hold_position',False):
        u.casualty='surrendered';u.order='surrender';self.cleanup_unit_state(u,'surrender')
        if hasattr(self,'stats'):self.stats[u.faction]['surrendered']+=1
        self.add_log(f'{u.faction} {u.role} surrendered after isolation.')
        if hasattr(self,'_vs_event'):self._vs_event('surrender',f'{getattr(u,"display_name",u.role)} surrendered',u.pos)
        return
    dest=self.choose_retreat_position(u,extra_rear=u.role in ('Medic','Mortar Team','Sniper'))
    u.move_mode='safe';u.waypoints=[dest];u.path=[];u.order='rout';u.rout_started_at=now;u.rally_target=dest;u.rallying=False;u.rally_safe_since=None;u.stance='standing';u.overwatch=False;u.fire_lane=False
    self.add_log(f'{getattr(u,"display_name",u.role)} breaking — falling back to cover.')
RealTimeGame.handle_break=_perf_handle_break

_perf_prev_update_unit2=RealTimeGame.update_unit
def _perf_update_unit(self,u,dt):
    before=u.casualty;was_rout=(u.order=='rout')
    _perf_prev_update_unit2(self,u,dt)
    if before!=u.casualty and u.casualty in ('dead','incapacitated','surrendered'):
        self.cleanup_unit_state(u,u.casualty)
    if not u.combat_effective:return
    if was_rout and u.order!='rout':u.rallying=True
    # Normal steady soldiers pay essentially no extra per-tick rally cost.
    if u.order!='rout' and not getattr(u,'rallying',False):return
    if u.order=='rout' and getattr(u,'rally_target',None) and dist(u.pos,u.rally_target)<1.6:
        u.path=[];u.waypoints=[];u.order='idle';u.rallying=True
    if getattr(u,'rallying',False):
        cell=self.grid[u.tile[1]][u.tile[0]];enemy='enemy' if u.faction=='player' else 'player'
        nearest=min((dist(u,e) for e in self.living(enemy) if e.combat_effective),default=99)
        safe=u.under_fire_until<=self.time and cell.ground_suppression<18 and nearest>5.5
        if safe:
            if u.rally_safe_since is None:u.rally_safe_since=self.time
            u.suppression=max(0,u.suppression-dt*4.5);u.morale=clamp(u.morale+dt*2.7,0,100);u.cohesion=clamp(u.cohesion+dt*1.8,0,100)
            if self.time-u.rally_safe_since>=3.5 and u.morale>=30 and u.suppression<42 and u.cohesion>=40:
                u.rallying=False;u.rally_safe_since=None;u.low_morale_since=None;u.breaking_since=None;u.morale_state='SHAKEN';u.order='idle'
                self.add_log(f'{getattr(u,"display_name",u.role)} rallied.')
        else:u.rally_safe_since=None
RealTimeGame.update_unit=_perf_update_unit

_perf_prev_apply_damage2=RealTimeGame.apply_damage
def _perf_apply_damage2(self,target,damage,source,cause):
    before=target.casualty
    _perf_prev_apply_damage2(self,target,damage,source,cause)
    if before!=target.casualty and target.casualty in ('dead','incapacitated'):
        self.cleanup_unit_state(target,target.casualty)
        for ally in self.living(target.faction):
            if ally.uid!=target.uid and ally.combat_effective and dist(ally,target)<5:
                ally.rally_shock=clamp(getattr(ally,'rally_shock',0)+12,0,40)
RealTimeGame.apply_damage=_perf_apply_damage2


# Strategic collapse also gets hysteresis; a single half-second morale dip no longer
# orders an entire sector to flee.
def _perf_sector_stability(self):
    p=self.primary_line_x
    player_by_sector={sec:[u for u in self.living('player') if u.combat_effective and _vs_sector_name(u.y)==sec and u.x>=p-2] for sec in ('NORTH','CENTRE','SOUTH')}
    for sec in ('NORTH','CENTRE','SOUTH'):
        defenders=[u for u in self.units if u.faction=='enemy' and getattr(u,'initial_battle_role','')=='forward' and getattr(u,'battle_sector','')==sec]
        alive=[u for u in defenders if u.combat_effective]
        initial=max(1,self.initial_sector_counts.get(sec,len(defenders) or 1));loss=1-len(alive)/initial
        if alive:
            supp=sum(u.suppression for u in alive)/len(alive);morale=sum(u.morale for u in alive)/len(alive);cross=sum(self.crossfire_pressure(u) for u in alive)/len(alive)
        else:supp=100;morale=0;cross=1
        breach=1 if player_by_sector[sec] else 0
        stability=100-loss*45-supp*.30-(100-morale)*.22-cross*18-breach*24-sum(1 for other in self.collapsed_sectors if other!=sec)*5
        stability=clamp(stability,0,100);self.sector_stability[sec]=stability
        if stability<27 and sec not in self.collapsed_sectors:
            if self._sector_low_since.get(sec) is None:self._sector_low_since[sec]=self.time
            held=self.time-self._sector_low_since[sec]
            if held<2.5 and stability>=10:continue
            self.collapsed_sectors.add(sec);self._sector_low_since[sec]=None
            self.notify(f'ENEMY LINE COLLAPSING — {sec}',kind='good',duration=5)
            self._vs_event('collapse',f'{sec.title()} defensive sector collapsed',(p,{'NORTH':MAP_H//6,'CENTRE':MAP_H//2,'SOUTH':MAP_H*5//6}[sec]))
            for u in alive:
                low_for=self.time-u.low_morale_since if u.low_morale_since is not None else 0
                friend_near=sum(1 for a in self.living('enemy') if a.uid!=u.uid and a.combat_effective and dist(a,u)<4.5)
                player_near=sum(1 for a in self.living('player') if a.combat_effective and dist(a,u)<3.5)
                if u.morale<18 and u.suppression>88 and friend_near<=1 and player_near and low_for>=5:
                    u.casualty='surrendered';u.order='surrender';self.cleanup_unit_state(u,'sector surrender');self.stats['enemy']['surrendered']+=1;self._vs_event('surrender',f'{u.display_name} surrendered',u.pos)
                else:
                    u.plan_state='fallback';u.fallback_point=(self.secondary_line_x,int(clamp(round(u.y),2,MAP_H-3)))
                    if u.deployed and u.role in ('Machine Gunner','HMG Crew'):self.toggle_deploy(u)
                    else:
                        fp=self.choose_retreat_position(u,extra_rear=u.role in ('Medic','Mortar Team','Sniper'))
                        if self.passable(*fp,u):self.issue_move([u],fp,mode='safe',formation='column')
        elif stability>34:self._sector_low_since[sec]=None
RealTimeGame.update_sector_stability=_perf_sector_stability


def _perf_local_surrenders(self):
    for u in list(self.living('enemy')):
        if not u.combat_effective or u.casualty=='surrendered':continue
        if u.morale>20 or u.suppression<86:continue
        low_for=self.time-u.low_morale_since if u.low_morale_since is not None else 0
        if low_for<5.0:continue
        friends=[a for a in self.living('enemy') if a.uid!=u.uid and a.combat_effective and dist(a,u)<5]
        attackers=[a for a in self.living('player') if a.combat_effective and dist(a,u)<3.2]
        rear_cut=any(a.x>u.x+.5 for a in attackers)
        score=(22-u.morale)+(u.suppression-84)*.30+len(attackers)*3-len(friends)*4
        if attackers and len(friends)<=1 and (rear_cut or u.morale<8) and score>=18:
            u.casualty='surrendered';u.order='surrender';self.cleanup_unit_state(u,'local surrender');self.stats['enemy']['surrendered']+=1
            self.notify(f'ENEMY SECTION SURRENDERS — {u.battle_sector}',kind='good',duration=4);self._vs_event('surrender',f'{u.display_name} surrendered',u.pos)
RealTimeGame.update_local_surrenders=_perf_local_surrenders


# Specialists preserve themselves intelligently when a position really is lost.
_perf_prev_ai_decide3=RealTimeGame.ai_decide
def _perf_ai_decide3(self,u):
    if u.faction=='enemy' and u.combat_effective:
        compromised=(getattr(u,'battle_sector','') in getattr(self,'collapsed_sectors',set()) or getattr(u,'morale_state','') in ('BREAKING','ROUTING'))
        if compromised and u.order not in ('rout','move','pack','deploy'):
            if u.role in ('Machine Gunner','HMG Crew') and u.deployed:self.toggle_deploy(u);return
            if u.role in ('Medic','Mortar Team','Sniper'):
                dest=self.choose_retreat_position(u,extra_rear=True)
                if dest and dest!=u.tile:self.issue_move([u],dest,mode='safe',formation='column');return
    _perf_prev_ai_decide3(self,u)
RealTimeGame.ai_decide=_perf_ai_decide3


# Battle intensity/mission logic runs at 4 Hz; objective/sector evaluation stays at 2 Hz.
def _perf_mission_update(self,dt):
    self._mission_timer+=dt;self._stability_timer+=dt;self._intensity_timer+=dt
    if self._intensity_timer>=.25:
        self.update_battle_stage(self._intensity_timer);self._intensity_timer=0
    else:self.combat_intensity=max(0,self.combat_intensity-dt*1.8)
    if self._stability_timer>=.5:
        self._stability_timer=0;self.update_sector_stability();self.update_local_surrenders();self.update_objectives()
        forward=[u for u in self.living('enemy') if getattr(u,'initial_battle_role','')=='forward']
        ratio=len(forward)/max(1,self.initial_role_counts['forward']);trigger=.50 if self.difficulty=='Easy' else .68 if self.difficulty=='Hard' else .80
        if not self._reserves_activated and ratio<trigger:self.activate_enemy_reserves('forward casualties')
    self.notifications=[n for n in self.notifications if n['until']>self.time]
RealTimeGame.update_mission_state=_perf_mission_update


_perf_prev_update3=RealTimeGame.update
def _perf_update3(self,dt):
    global _KZ_VISUAL_TERRAIN_REV
    prof=getattr(self,'profile_enabled',False)
    if prof:
        for k in ('los_ms','los_calls','los_hits','line_calls','line_hits'):self._perf[k]=0 if k!='los_ms' else 0.0
    if self._last_visual_terrain_rev!=_KZ_VISUAL_TERRAIN_REV:
        self._last_visual_terrain_rev=_KZ_VISUAL_TERRAIN_REV;self._terrain_revision+=1;self._path_cache.clear();self._los_cache.clear();self._line_cache.clear()
    t0=time.perf_counter();_perf_prev_update3(self,dt);self._perf['sim_ms']=(time.perf_counter()-t0)*1000
RealTimeGame.update=_perf_update3


# ------------------------------ renderer caches ------------------------------
_perf_prev_app_init2=KillZoneApp.__init__
def _perf_app_init2(self):
    _perf_prev_app_init2(self)
    self._terrain_cache_surface=None;self._terrain_cache_key=None;self._terrain_cache_build_ms=0.0
    self._dynamic_tiles=[];self._dynamic_tiles_at=-99.0;self._text_surface_cache={};self._dust_surface_cache={}
    self._render_perf={'frame_ms':0.0,'map_ms':0.0,'terrain_ms':0.0,'dynamic_ms':0.0,'units_ms':0.0,'ui_ms':0.0,'visible_units':0,'dynamic_tiles':0}
KillZoneApp.__init__=_perf_app_init2


def _perf_cached_text(self,s,size,color):
    text=str(s);col=COLORS[color] if isinstance(color,str) else tuple(color);key=(text,int(size),tuple(col))
    surf=self._text_surface_cache.get(key)
    if surf is None:
        surf=self.get_font(size).render(text,True,col);self._text_surface_cache[key]=surf
        if len(self._text_surface_cache)>1200:
            for _ in range(250):self._text_surface_cache.pop(next(iter(self._text_surface_cache)),None)
    return surf
KillZoneApp.cached_text_surface=_perf_cached_text


def _perf_text(self,s,pos,size=14,color='text'):
    self.screen.blit(self.cached_text_surface(s,size,color),pos)
KillZoneApp.text=_perf_text


def _perf_build_terrain_cache(self):
    global _KZ_VISUAL_TERRAIN_REV
    tp=self.tile_px;key=(id(self.game),self.game.seed,tp,_KZ_VISUAL_TERRAIN_REV)
    if self._terrain_cache_surface is not None and self._terrain_cache_key==key:return self._terrain_cache_surface
    t0=time.perf_counter();surf=pygame.Surface((MAP_W*tp,MAP_H*tp));old=self.screen;self.screen=surf
    try:
        for y in range(MAP_H):
            for x in range(MAP_W):
                c=self.game.grid[y][x];r=pygame.Rect(x*tp,y*tp,tp,tp);pygame.draw.rect(surf,COLORS.get(c.terrain,COLORS['open']),r);self.draw_terrain(c,r,x,y)
    finally:self.screen=old
    self._terrain_cache_surface=surf;self._terrain_cache_key=key;self._terrain_cache_build_ms=(time.perf_counter()-t0)*1000
    return surf
KillZoneApp.ensure_terrain_cache=_perf_build_terrain_cache


def _perf_refresh_dynamic_tiles(self):
    now=time.perf_counter()
    if now-self._dynamic_tiles_at<.085:return
    self._dynamic_tiles_at=now;out=[]
    for y,row in enumerate(self.game.grid):
        for x,c in enumerate(row):
            if c.ground_suppression>18 or c.smoke>.05 or c.fire>0:out.append((x,y,c.ground_suppression,c.smoke,c.fire))
    self._dynamic_tiles=out
KillZoneApp.refresh_dynamic_tiles=_perf_refresh_dynamic_tiles


# Cached static NATO label/status surfaces; symbols remain intentionally unanimated.
def _perf_draw_unit2(self,u):
    cx,cy=self.world_to_screen(u.x,u.y);tp=self.tile_px
    if not self.map_view_rect().inflate(30,30).collidepoint((cx,cy)):return
    if u.casualty=='dead':
        pygame.draw.line(self.screen,(65,47,42),(cx-6,cy-6),(cx+6,cy+6),2);pygame.draw.line(self.screen,(65,47,42),(cx+6,cy-6),(cx-6,cy+6),2);return
    if u.casualty=='surrendered':
        pygame.draw.rect(self.screen,COLORS['muted'],(cx-8,cy-5,16,10),1);ss=self.cached_text_surface('SURR',9,'muted');self.screen.blit(ss,(cx-ss.get_width()//2,cy+7));return
    friend=u.faction=='player';fill=COLORS['nato_friend'] if friend else COLORS['nato_hostile'];ink=COLORS['black'];sw=max(16,int(tp*.85));sh=max(12,int(tp*.56))
    if friend:
        r=pygame.Rect(cx-sw//2,cy-sh//2,sw,sh);pygame.draw.rect(self.screen,fill,r);pygame.draw.rect(self.screen,ink,r,2);pygame.draw.line(self.screen,ink,(r.left+2,r.top+2),(r.right-2,r.bottom-2),2);pygame.draw.line(self.screen,ink,(r.right-2,r.top+2),(r.left+2,r.bottom-2),2)
    else:
        rad=max(9,int(tp*.42));pts=[(cx,cy-rad),(cx+rad,cy),(cx,cy+rad),(cx-rad,cy)];pygame.draw.polygon(self.screen,fill,pts);pygame.draw.polygon(self.screen,ink,pts,2);pygame.draw.line(self.screen,ink,(cx-6,cy-6),(cx+6,cy+6),2);pygame.draw.line(self.screen,ink,(cx+6,cy-6),(cx-6,cy+6),2)
    role={'Rifleman':'RF','Machine Gunner':'MG','Sniper':'SN','Medic':'MED','Engineer':'ENG','Recon':'REC','Grenadier':'GRN','Assault':'ASLT','Automatic Rifleman':'AR','Marksman':'DMR','HMG Crew':'HMG','Mortar Team':'MTR'}.get(u.role,'INF')
    surf=self.cached_text_surface(role,10 if tp<24 else 12,'white');self.screen.blit(surf,(cx-surf.get_width()//2,cy+max(8,sh//2+2)))
    if u.uid in self.selected:pygame.draw.circle(self.screen,COLORS['select'],(cx,cy),max(14,int(tp*.60)),2)
    ang=math.radians(u.facing);pygame.draw.line(self.screen,COLORS['white'],(cx,cy),(cx+math.cos(ang)*max(11,tp*.48),cy+math.sin(ang)*max(11,tp*.48)),1)
    bw=max(20,int(tp*.85));pygame.draw.rect(self.screen,(30,30,28),(cx-bw//2,cy+max(17,int(tp*.78)),bw,3));pygame.draw.rect(self.screen,COLORS['good'],(cx-bw//2,cy+max(17,int(tp*.78)),int(bw*clamp(u.hp/u.max_hp,0,1)),3))
    if u.suppression>12:
        col=COLORS['contact'] if u.suppression<55 else COLORS['suppression'] if u.suppression<80 else COLORS['danger'];pygame.draw.circle(self.screen,col,(cx,cy),max(15,int(tp*.64)),1 if u.suppression<55 else 2)
    state=getattr(u,'morale_state','STEADY');status=''
    if u.reload_timer>0:status='RLD'
    elif u.jammed:status='JAM'
    elif u.order=='rout':status='RTE'
    elif state=='BREAKING':status='BRK'
    elif state=='PINNED' or u.suppression>=80:status='PIN'
    elif state=='RALLYING':status='RLY'
    elif self.game.time<u.disoriented_until:status='CON'
    elif u.order=='suppress':status='SUP'
    elif u.overwatch:status='OW'
    elif u.order=='move':status='MOV'
    if status:
        ss=self.cached_text_surface(status,10,'status');self.screen.blit(ss,(cx-ss.get_width()//2,cy-max(21,int(tp*.8))))
KillZoneApp.draw_unit=_perf_draw_unit2


def _perf_draw_arc2(self,u):
    if not u.combat_effective or not u.alive or not (u.overwatch or u.fire_lane):return
    center=self.world_to_screen(u.x,u.y)
    if not self.map_view_rect().inflate(int(u.arc_range*self.tile_px),int(u.arc_range*self.tile_px)).collidepoint(center):return
    radius=int(u.arc_range*self.tile_px);a1=math.radians(u.fire_lane_center-u.arc_width/2);a2=math.radians(u.fire_lane_center+u.arc_width/2);col=COLORS['danger'] if u.faction=='enemy' else COLORS['contact']
    pygame.draw.line(self.screen,col,center,(center[0]+math.cos(a1)*radius,center[1]+math.sin(a1)*radius),1);pygame.draw.line(self.screen,col,center,(center[0]+math.cos(a2)*radius,center[1]+math.sin(a2)*radius),1)
KillZoneApp.draw_arc=_perf_draw_arc2


def _perf_draw_profiler(self):
    if not self.show_perf:return
    rp=self._render_perf;gp=self.game._perf;x=MAP_X+MAP_VIEW_W_PX-286;y=MAP_Y+10;w=274;h=154
    pygame.draw.rect(self.screen,(24,27,23),(x,y,w,h));pygame.draw.rect(self.screen,COLORS['muted'],(x,y,w,h),1)
    lines=[
        f'FPS {self.clock.get_fps():5.1f}   FRAME {rp.get("frame_ms",0):5.2f} ms',
        f'MAP {rp.get("map_ms",0):5.2f}  STATIC {rp.get("terrain_ms",0):5.2f}  DYN {rp.get("dynamic_ms",0):5.2f}',
        f'UNITS/FX {rp.get("units_ms",0):5.2f}   UI {rp.get("ui_ms",0):5.2f}',
        f'SIM {gp.get("sim_ms",0):5.2f}  AI {gp.get("ai_ms",0):5.2f}/{gp.get("ai_decisions",0)}',
        f'PATH {gp.get("path_ms",0):5.2f}/{gp.get("paths",0)}  LOS {gp.get("los_ms",0):5.2f}',
        f'LOS calls {gp.get("los_calls",0)} hit {gp.get("los_hits",0)+gp.get("line_hits",0)}',
        f'visible {rp.get("visible_units",0)}  dynamic tiles {rp.get("dynamic_tiles",0)}',
        f'tracers {len(self.game.tracers)}  smoke/expl {len(self.game.explosions)}  decals {len(self.game.blood)}',
    ]
    self.text('PERFORMANCE [F9]',(x+8,y+7),10,'select');yy=y+24
    for line in lines:self.text(line,(x+8,yy),9,'muted');yy+=15
KillZoneApp.draw_profiler_panel=_perf_draw_profiler


def _perf_dust_surface(self,rad,alpha):
    # Quantize alpha so hundreds of dust puffs reuse a handful of circular
    # surfaces instead of allocating/blending a new Surface every frame.
    rad=max(2,int(rad));a=max(0,min(255,int(alpha)//16*16));key=(rad,a)
    surf=self._dust_surface_cache.get(key)
    if surf is None:
        surf=pygame.Surface((rad*2+2,rad*2+2),pygame.SRCALPHA)
        pygame.draw.circle(surf,(135,118,91,a),(rad+1,rad+1),rad)
        self._dust_surface_cache[key]=surf
        if len(self._dust_surface_cache)>160:self._dust_surface_cache.clear();self._dust_surface_cache[key]=surf
    return surf
KillZoneApp.dust_surface=_perf_dust_surface


def _perf_draw_map3(self):
    t0=time.perf_counter();mr=self.map_view_rect();pygame.draw.rect(self.screen,COLORS['black'],mr);self.update_preview();x0,y0,x1,y1=self.visible_bounds();keys=pygame.key.get_pressed()
    # One blit replaces hundreds of terrain primitives every frame.
    ts=time.perf_counter();terrain=self.ensure_terrain_cache();tp=self.tile_px;src=pygame.Rect(int(self.camera_x*tp),int(self.camera_y*tp),MAP_VIEW_W_PX,MAP_VIEW_H_PX);ox,oy=self.shake_offset
    self.screen.blit(terrain,(MAP_X+ox,MAP_Y+oy),src);pygame.draw.rect(self.screen,COLORS['muted'],mr,1);terrain_ms=(time.perf_counter()-ts)*1000
    td=time.perf_counter();self.refresh_dynamic_tiles();dynamic_count=0
    for x,y,supp,smoke,fire in self._dynamic_tiles:
        if not (x0<=x<x1 and y0<=y<y1):continue
        r=self.cell_rect(x,y)
        if not r.colliderect(mr):continue
        dynamic_count+=1
        if supp>18:self.screen.blit(self.overlay_surface((r.w,r.h),(190,105,45),int(clamp(supp*1.1,20,105))),r.topleft)
        if smoke>.05:self.screen.blit(self.overlay_surface((r.w,r.h),(190,190,185),int(clamp(smoke*38,20,165))),r.topleft)
        if fire>0:pygame.draw.circle(self.screen,COLORS['fire'],r.center,max(2,int(min(r.w,r.h)*.18)))
    if self.show_threat:
        for y in range(y0,y1):
            for x in range(x0,x1):
                th=self.game.tile_threat('player',x,y)
                if th>.25:
                    r=self.cell_rect(x,y)
                    if r.colliderect(mr):self.screen.blit(self.overlay_surface((r.w,r.h),(210,70,55),int(clamp(th*34,12,100))),r.topleft)
    dynamic_ms=(time.perf_counter()-td)*1000
    tu=time.perf_counter()
    for b in self.game.blood:
        sx,sy=self.world_to_screen(b.x,b.y)
        if mr.collidepoint((sx,sy)):pygame.draw.circle(self.screen,COLORS['blood_dark'],(sx,sy),max(2,int(b.size*self.tile_px*.45)))
    for puff in self.game.dust:
        sx,sy=self.world_to_screen(puff.x,puff.y)
        if mr.collidepoint((sx,sy)):
            alpha=int(120*clamp(puff.life/max(.01,puff.total),0,1));rad=max(2,int(puff.size*self.tile_px));self.screen.blit(self.dust_surface(rad,alpha),(sx-rad-1,sy-rad-1))
    for tr in self.game.tracers:
        a=self.world_to_screen(*tr.a);b=self.world_to_screen(*tr.b)
        if mr.clipline(a,b):pygame.draw.line(self.screen,(234,215,145),a,b,1)
    for imp in self.game.impacts:
        sx,sy=self.world_to_screen(imp.x,imp.y)
        if mr.collidepoint((sx,sy)):pygame.draw.circle(self.screen,COLORS['impact'],(sx,sy),2)
    # Strict unit culling also means stale tactical arcs can never survive their owner.
    visible_units=0
    for u in self.game.units:
        if u.x<x0-2 or u.x>x1+2 or u.y<y0-2 or u.y>y1+2:continue
        if u.faction=='enemy' and u.alive and not self.game.visible_to('player',u):continue
        if u.combat_effective and (u.overwatch or u.fire_lane):self.draw_arc(u)
        self.draw_unit(u);visible_units+=1
    for e in self.game.explosions:
        sx,sy=self.world_to_screen(e.x,e.y)
        if mr.collidepoint((sx,sy)):pygame.draw.circle(self.screen,COLORS['danger'] if e.kind=='HE' else COLORS['smoke'],(sx,sy),int(e.radius*self.tile_px),1);self.text(f'{e.timer:.1f}',(sx-10,sy-8),12,'white')
    units_ms=(time.perf_counter()-tu)*1000
    self.draw_tactical_previews();self.draw_planned_orders()
    if keys[pygame.K_LALT]:self.draw_directional_cover(self.map_cell_from_mouse(self.mouse))
    self.draw_selection_box()
    if self.game.victory or self.game.defeat:self.draw_after_action()
    if self.state in ('game','deployment'):
        self.draw_objectives();self.draw_contact_intel();self.draw_assault_plan();self.draw_notifications()
    self._render_perf.update({'map_ms':(time.perf_counter()-t0)*1000,'terrain_ms':terrain_ms,'dynamic_ms':dynamic_ms,'units_ms':units_ms,'visible_units':visible_units,'dynamic_tiles':dynamic_count})
    self.draw_profiler_panel()
KillZoneApp.draw_map=_perf_draw_map3


# --------------------------- morale / command UI -----------------------------
def _perf_command_rects(self):
    labels=['ASSAULT','SUPPRESS','OVERWATCH','GRENADE','SMOKE','RELOAD','STANCE','FORMATION','DISCIPLINE','PRIORITY','BOUND','AUTO','HOLD','FALLBACK']
    gap=3;x=MAP_X;y=MAP_Y+MAP_VIEW_H_PX+84;w=(WINDOW_W-MAP_X*2-gap*(len(labels)-1))//len(labels)
    return {lab:pygame.Rect(x+i*(w+gap),y,w,31) for i,lab in enumerate(labels)}
KillZoneApp.command_bar_rects=_perf_command_rects


def _perf_handle_command_bar2(self,pos):
    us=self.selected_units()
    for name,r in self.command_bar_rects().items():
        if not r.collidepoint(pos):continue
        if name=='ASSAULT':self.command_mode='assault'
        elif not us:return True
        elif name=='SUPPRESS':self.command_mode='suppress'
        elif name=='OVERWATCH':
            for u in us:self.game.set_overwatch(u,angle_to(u,self.map_cell_from_mouse(self.mouse) or u.tile),100)
        elif name=='GRENADE':self.command_mode='grenade'
        elif name=='SMOKE':self.command_mode='smoke'
        elif name=='RELOAD':
            for u in us:self.game.start_reload(u)
        elif name=='STANCE':
            for u in us:self.game.cycle_stance(u)
        elif name=='FORMATION':self.cycle_formation()
        elif name=='DISCIPLINE':self.cycle_discipline(us)
        elif name=='PRIORITY':self.cycle_priority(us)
        elif name=='BOUND':self.command_mode='bound'
        elif name=='AUTO':
            new=not all(u.auto_reload and u.auto_cover and u.auto_smoke and u.auto_medic for u in us)
            for u in us:u.auto_reload=u.auto_cover=u.auto_smoke=u.auto_medic=new
        elif name=='HOLD':
            new=not all(getattr(u,'hold_position',False) for u in us)
            for u in us:u.hold_position=new
            self.message='Hold position enabled' if new else 'Hold position released'
        elif name=='FALLBACK':self.command_mode='fallback'
        return True
    return False
KillZoneApp.handle_command_bar=_perf_handle_command_bar2

_perf_prev_context2=KillZoneApp.issue_context_command
def _perf_issue_context2(self,cell,append=False):
    if self.command_mode=='fallback':
        us=self.selected_units()
        if us and cell and self.game.in_bounds(*cell):
            for u in us:u.fallback_point=cell
            self.message=f'Fallback/rally point set: {cell}';self.command_mode='normal'
        return
    _perf_prev_context2(self,cell,append=append)
KillZoneApp.issue_context_command=_perf_issue_context2


def _perf_draw_bottom(self):
    y0=MAP_Y+MAP_VIEW_H_PX+2;pygame.draw.rect(self.screen,COLORS['panel'],(0,y0,WINDOW_W,WINDOW_H-y0))
    for key,r in self.squad_rects().items():
        active=(key=='ALL' and len(self.selected)==len([u for u in self.game.living('player') if u.combat_effective])) or (key!='ALL' and self.selected and all(getattr(self.game.get_unit(i),'squad_id',-1)==key for i in self.selected if self.game.get_unit(i)))
        pygame.draw.rect(self.screen,COLORS['panel2'],r,border_radius=3);pygame.draw.rect(self.screen,COLORS['select'] if active else COLORS['muted'],r,1,border_radius=3);lab='ALL' if key=='ALL' else f'SQUAD {chr(64+int(key))}';ss=self.cached_text_surface(lab,11,'white');self.screen.blit(ss,(r.centerx-ss.get_width()//2,r.centery-ss.get_height()//2))
    for u,r in self.unit_card_rects():
        sel=u.uid in self.selected;pygame.draw.rect(self.screen,COLORS['panel2'],r,border_radius=2);pygame.draw.rect(self.screen,COLORS['select'] if sel else COLORS['muted'],r,2 if sel else 1,border_radius=2);abbr={'Rifleman':'RF','Machine Gunner':'MG','Sniper':'SN','Medic':'MED','Engineer':'ENG','Recon':'REC','Grenadier':'GRN','Assault':'AS','Automatic Rifleman':'AR','Marksman':'DMR','HMG Crew':'HMG','Mortar Team':'MTR'}.get(u.role,'INF');self.text(abbr,(r.x+4,r.y+3),10,'white');self.text(f'{u.hp:.0f}',(r.x+4,r.y+18),9,'good' if u.hp>u.max_hp*.5 else 'danger');pygame.draw.rect(self.screen,(30,30,28),(r.x+30,r.y+20,30,3));pygame.draw.rect(self.screen,COLORS['contact'],(r.x+30,r.y+20,int(30*u.suppression/100),3))
    us=self.selected_units()
    if us:
        for name,r in self.command_bar_rects().items():
            active=(name=='ASSAULT' and self.command_mode=='assault') or (name=='FALLBACK' and self.command_mode=='fallback') or (name=='HOLD' and all(getattr(u,'hold_position',False) for u in us))
            pygame.draw.rect(self.screen,COLORS['panel2'],r,border_radius=3);pygame.draw.rect(self.screen,COLORS['select'] if active else COLORS['muted'],r,2 if active else 1,border_radius=3);label=name
            if name=='FORMATION':label=self.formation.upper()
            elif name=='DISCIPLINE':label=us[0].fire_discipline.upper()
            elif name=='PRIORITY':label=us[0].target_priority.upper()
            elif name=='AUTO':label='AUTO ON' if all(u.auto_reload and u.auto_cover and u.auto_smoke and u.auto_medic for u in us) else 'AUTO OFF'
            ss=self.cached_text_surface(label,9,'select' if active or name in ('ASSAULT','FORMATION') else 'white');self.screen.blit(ss,(r.centerx-ss.get_width()//2,r.centery-ss.get_height()//2))
KillZoneApp.draw_command_bar=_perf_draw_bottom


def _perf_draw_sidebar3(self):
    x=SIDEBAR_X;w=WINDOW_W-x-12;pygame.draw.rect(self.screen,COLORS['panel'],(x,MAP_Y,w,MAP_VIEW_H_PX));obj=self.game.current_objective;y=MAP_Y+9
    if obj:
        pygame.draw.rect(self.screen,COLORS['panel2'],(x+8,y,w-16,76),border_radius=3);pygame.draw.rect(self.screen,COLORS['objective'],(x+8,y,w-16,76),1,border_radius=3);self.text(f'OBJECTIVE {self.game.objective_index+1}/{len(self.game.objectives)}',(x+16,y+7),10,'objective');self.text(obj['title'][:34],(x+16,y+24),11,'white');pygame.draw.rect(self.screen,(25,27,24),(x+16,y+48,w-32,7));pygame.draw.rect(self.screen,COLORS['objective'],(x+16,y+48,int((w-32)*clamp(obj['progress'],0,1)),7));self.text(f'{obj["progress"]*100:.0f}%',(x+w-45,y+59),9,'muted');y+=88
    self.text('SELECTED',(x+14,y),15,'white');y+=22;us=self.selected_units()
    if not us:self.text('No units selected',(x+14,y),12,'muted');y+=24
    else:
        firing=sum(1 for u in us if u.order=='fire');reloading=sum(1 for u in us if u.reload_timer>0);pinned=sum(1 for u in us if getattr(u,'morale_state','')=='PINNED');wounded=sum(1 for u in us if u.casualty=='wounded');self.text(f'{len(us)} troops | fire {firing} rld {reloading} pin {pinned} wnd {wounded}',(x+14,y),10,'status');y+=18
        for u in us[:3]:
            name=getattr(u,'display_name',f'SQ{getattr(u,"squad_id",0)} #{u.uid}');state=getattr(u,'morale_state','STEADY');self.text(f'{name} — {u.role}'[:39],(x+14,y),11,'select');y+=15;self.text(f'HP {u.hp:.0f} MOR {u.morale:.0f} SUP {u.suppression:.0f} COH {u.cohesion:.0f}',(x+14,y),10,'text');y+=14;self.text(f'{state} | {u.weapon_name} {u.ammo} | {u.order}',(x+14,y),9,'contact' if state in ('PINNED','BREAKING','ROUTING') else 'muted');y+=18
        if len(us)==1:
            u=us[0];self.text(f'MORALE — {getattr(u,"morale_state","STEADY")}',(x+14,y),10,'white');y+=14
            factors=sorted(self.game.morale_breakdown(u),key=lambda z:abs(z[1]),reverse=True)[:3]
            for name,val in factors:self.text(f'{name[:24]:24s} {val:+.0f}',(x+14,y),9,'danger' if val>0 else 'good');y+=13
            if u.low_morale_since is not None:self.text(f'under break pressure {self.game.time-u.low_morale_since:.1f}s',(x+14,y),9,'muted');y+=14
            if getattr(u,'fallback_point',None):self.text(f'fallback {u.fallback_point}'+(' | HOLD' if u.hold_position else ''),(x+14,y),9,'select');y+=14
    report_y=max(y+5,MAP_Y+350);self.text('FIELD REPORT',(x+14,report_y),13,'white');yy=report_y+20
    for line in self.game.log[-5:]:self.text(line[:43],(x+14,yy),10,'muted');yy+=15
    sec_y=min(MAP_Y+MAP_VIEW_H_PX-72,yy+4);self.text('LINE STABILITY',(x+14,sec_y),9,'muted');sec_y+=13
    for sec in ('NORTH','CENTRE','SOUTH'):
        st=self.game.sector_stability.get(sec,100);col='danger' if st>65 else 'contact' if st>30 else 'good';self.text(f'{sec:6s} {st:3.0f}%'+(' COLLAPSED' if sec in self.game.collapsed_sectors else ''),(x+14,sec_y),8,col);sec_y+=12
    if pygame.key.get_pressed()[pygame.K_LALT]:
        cell=self.map_cell_from_mouse(self.mouse)
        if cell:
            cx,cy=cell;c=self.game.grid[cy][cx];td=TERRAIN[c.terrain];base=MAP_Y+MAP_VIEW_H_PX-96;pygame.draw.rect(self.screen,COLORS['panel2'],(x+8,base-5,w-16,88),border_radius=3);self.text('TILE INTEL [LALT]',(x+14,base),11,'select');self.text(f'{cell} {c.terrain.upper()} cover {td["cover"]} conceal {td["conceal"]}',(x+14,base+17),10,'white');self.text(f'move x{td["move"]:.2f} smoke {c.smoke:.1f} suppression {c.ground_suppression:.0f}',(x+14,base+34),10,'muted');self.text(f'known threat {self.game.tile_threat("player",cx,cy):.1f}',(x+14,base+51),10,'contact');self.text('edges: green strong / yellow partial / red open',(x+14,base+68),9,'muted')
KillZoneApp.draw_sidebar=_perf_draw_sidebar3


# Keep profiler instrumentation off unless requested; prune noncombat selections.
_perf_prev_handle_key2=KillZoneApp.handle_key
def _perf_handle_key2(self,key,mods):
    _perf_prev_handle_key2(self,key,mods)
    if hasattr(self,'game'):self.game.profile_enabled=bool(self.show_perf)
KillZoneApp.handle_key=_perf_handle_key2

_perf_prev_settings_event2=KillZoneApp.handle_settings_event
def _perf_settings_event2(self,e):
    _perf_prev_settings_event2(self,e)
    if hasattr(self,'game'):self.game.profile_enabled=bool(self.show_perf)
KillZoneApp.handle_settings_event=_perf_settings_event2

_perf_prev_draw3=KillZoneApp.draw
def _perf_draw3(self):
    t0=time.perf_counter()
    if hasattr(self,'game'):
        self.game.profile_enabled=bool(self.show_perf)
        self.selected=[uid for uid in self.selected if (self.game.get_unit(uid) and self.game.get_unit(uid).combat_effective)]
    _perf_prev_draw3(self)
    frame=(time.perf_counter()-t0)*1000;self._render_perf['frame_ms']=frame;self._render_perf['ui_ms']=max(0,frame-self._render_perf.get('map_ms',0))
KillZoneApp.draw=_perf_draw3

