from __future__ import annotations

import heapq
import json
import math
import os
import random
import sys
import threading
import time
import urllib.request
from pathlib import Path
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

try:
    import pygame
except ImportError:
    pygame = None

# =============================================================================
# KILL ZONE — REALTIME TACTICAL INFANTRY SANDBOX
# =============================================================================
# This build deliberately uses a deterministic fixed-step simulation underneath
# a smooth pygame presentation. It is real-time: movement, aiming, reloads,
# suppression, reactions, bleeding, smoke, fire, AI and support weapons all
# continue simultaneously.
# =============================================================================

APP_TITLE = "KILL ZONE — Realtime Tactical Infantry"
TILE = 28
MAP_W, MAP_H = 56, 36
MAP_X, MAP_Y = 18, 66
MAP_VIEW_W_PX, MAP_VIEW_H_PX = 39 * TILE, 20 * TILE
SIDEBAR_X = MAP_X + MAP_VIEW_W_PX + 18
WINDOW_W, WINDOW_H = SIDEBAR_X + 320, 790
FPS = 0  # 0 = uncapped renderer; simulation remains fixed-step at 30 Hz
SIM_DT = 1 / 30
Coord = Tuple[int, int]

COLORS = {
    "bg": (25, 29, 25), "panel": (42, 47, 40), "panel2": (55, 60, 51),
    "text": (222, 222, 198), "muted": (153, 157, 141), "white": (242, 242, 225),
    "black": (16, 17, 15), "select": (229, 210, 119), "player": (89, 145, 91),
    "enemy": (170, 73, 65), "objective": (212, 167, 74), "danger": (217, 91, 80),
    "good": (132, 175, 112), "contact": (220, 187, 107), "blue": (104, 145, 177),
    "open": (115, 102, 78), "road": (127, 114, 91), "trench": (72, 62, 49),
    "woods": (51, 76, 48), "wall": (102, 104, 96), "bunker": (69, 73, 65),
    "crater": (91, 77, 59), "mud": (78, 65, 49), "rubble": (102, 95, 83),
    "wire": (111, 107, 97), "sandbags": (122, 105, 73), "foxhole": (83, 70, 52),
    "hill": (137, 123, 91), "water": (57, 83, 91), "bridge": (110, 91, 62),
    "building": (86, 82, 73), "woodwall": (105, 82, 57), "window": (105, 113, 110),
    "door": (113, 84, 57), "mine": (134, 76, 57),
    "dugout": (58, 54, 46), "firing_step": (79, 68, 51),
    "smoke": (182, 184, 177), "fire": (222, 125, 55),
    "nato_friend": (92, 190, 232), "nato_hostile": (240, 96, 86),
    "blood": (111, 19, 18), "blood_dark": (63, 12, 12),
    "impact": (228, 205, 151), "suppression": (220, 165, 84), "status": (194, 211, 174),
}

TERRAIN: Dict[str, dict] = {
    "open":     {"cover": 0, "move": 1.00, "blocks": False, "conceal": 0,  "height": 0, "hp": None, "pen": 0},
    "road":     {"cover": 0, "move": 0.82, "blocks": False, "conceal": 0,  "height": 0, "hp": None, "pen": 0},
    "trench":   {"cover": 4, "move": 0.72, "blocks": False, "conceal": 10, "height": -1,"hp": None, "pen": 0},
    "woods":    {"cover": 2, "move": 1.50, "blocks": False, "conceal": 26, "height": 0, "hp": 45, "pen": 1},
    "wall":     {"cover": 5, "move": 999,  "blocks": True,  "conceal": 0,  "height": 1, "hp": 80, "pen": 4},
    "bunker":   {"cover": 5, "move": 1.35, "blocks": False, "conceal": 15, "height": 0, "hp": 150,"pen": 3},
    "crater":   {"cover": 2, "move": 1.35, "blocks": False, "conceal": 7,  "height": -1,"hp": None, "pen": 0},
    "mud":      {"cover": 0, "move": 1.65, "blocks": False, "conceal": 0,  "height": 0, "hp": None, "pen": 0},
    "rubble":   {"cover": 2, "move": 1.40, "blocks": False, "conceal": 6,  "height": 0, "hp": None, "pen": 0},
    "wire":     {"cover": 0, "move": 2.80, "blocks": False, "conceal": 0,  "height": 0, "hp": 30, "pen": 0},
    "sandbags": {"cover": 3, "move": 1.35, "blocks": False, "conceal": 4,  "height": 0, "hp": 55, "pen": 1},
    "foxhole":  {"cover": 3, "move": 0.90, "blocks": False, "conceal": 11, "height": -1,"hp": None, "pen": 0},
    "hill":     {"cover": 1, "move": 1.30, "blocks": False, "conceal": 0,  "height": 1, "hp": None, "pen": 0},
    "water":    {"cover": 0, "move": 999,  "blocks": True,  "conceal": 0,  "height": -1,"hp": None, "pen": 0},
    "bridge":   {"cover": 0, "move": 0.95, "blocks": False, "conceal": 0,  "height": 0, "hp": 70, "pen": 1},
    "building": {"cover": 5, "move": 999,  "blocks": True,  "conceal": 0,  "height": 1, "hp": 105,"pen": 4},
    "woodwall": {"cover": 4, "move": 999,  "blocks": False, "conceal": 0,  "height": 1, "hp": 55, "pen": 3},
    "window":   {"cover": 4, "move": 999,  "blocks": False, "conceal": 2,  "height": 1, "hp": 30, "pen": 1},
    "door":     {"cover": 2, "move": 1.00, "blocks": False, "conceal": 2,  "height": 0, "hp": 35, "pen": 1},
    "dugout":   {"cover": 5, "move": 0.82, "blocks": False, "conceal": 22, "height": -1, "hp": 110, "pen": 3},
    "firing_step":{"cover": 4, "move": 0.74, "blocks": False, "conceal": 8, "height": -1, "hp": None, "pen": 0},
}

WEAPONS: Dict[str, dict] = {
    "Service Rifle": {"range": 11.0, "damage": 32, "acc": 62, "supp": 16, "rpm": 190, "mag": 20, "reload": 2.5, "heat": 2, "cool": 18, "pen": 2},
    "SMG": {"range": 6.5, "damage": 23, "acc": 56, "supp": 18, "rpm": 520, "mag": 30, "reload": 2.2, "heat": 2, "cool": 19, "pen": 1},
    "Automatic Rifle": {"range": 9.0, "damage": 27, "acc": 55, "supp": 27, "rpm": 430, "mag": 20, "reload": 2.6, "heat": 4, "cool": 17, "pen": 2},
    "Light Machine Gun": {"range": 12.0, "damage": 28, "acc": 53, "supp": 46, "rpm": 600, "mag": 50, "reload": 4.6, "heat": 7, "cool": 12, "pen": 2},
    "Heavy Machine Gun": {"range": 15.0, "damage": 38, "acc": 58, "supp": 65, "rpm": 520, "mag": 100,"reload": 6.0, "heat": 9, "cool": 10, "pen": 4},
    "Scoped Rifle": {"range": 17.0, "damage": 84, "acc": 79, "supp": 34, "rpm": 45, "mag": 5, "reload": 3.0, "heat": 1, "cool": 25, "pen": 3},
    "Marksman Rifle": {"range": 14.0, "damage": 48, "acc": 72, "supp": 23, "rpm": 120, "mag": 10, "reload": 2.8, "heat": 2, "cool": 22, "pen": 3},
    "Carbine": {"range": 8.0, "damage": 28, "acc": 61, "supp": 17, "rpm": 300, "mag": 20, "reload": 2.2, "heat": 2, "cool": 20, "pen": 2},
}

ROLES: Dict[str, dict] = {
    "Rifleman": {"hp": 100, "weapon": "Service Rifle", "speed": 2.55, "spot": 10.5, "mags": 5, "grenades": 2, "smoke": 1, "rifle_grenades": 0, "satchel": 0},
    "Machine Gunner": {"hp": 120, "weapon": "Light Machine Gun", "speed": 2.15, "spot": 9.5, "mags": 4, "grenades": 0, "smoke": 0, "rifle_grenades": 0, "satchel": 0, "crew": 2},
    "Sniper": {"hp": 75, "weapon": "Scoped Rifle", "speed": 2.40, "spot": 16.0, "mags": 6, "grenades": 0, "smoke": 1, "rifle_grenades": 0, "satchel": 0},
    "Medic": {"hp": 90, "weapon": "Carbine", "speed": 2.55, "spot": 10.0, "mags": 4, "grenades": 0, "smoke": 2, "rifle_grenades": 0, "satchel": 0, "med": 5},
    "Engineer": {"hp": 105, "weapon": "Carbine", "speed": 2.35, "spot": 10.0, "mags": 4, "grenades": 1, "smoke": 1, "rifle_grenades": 0, "satchel": 2, "tools": 5},
    "Recon": {"hp": 80, "weapon": "Carbine", "speed": 3.10, "spot": 17.0, "mags": 4, "grenades": 0, "smoke": 2, "rifle_grenades": 0, "satchel": 0},
    "Grenadier": {"hp": 95, "weapon": "Service Rifle", "speed": 2.45, "spot": 10.0, "mags": 4, "grenades": 3, "smoke": 1, "rifle_grenades": 4, "satchel": 0},
    "Assault": {"hp": 105, "weapon": "SMG", "speed": 2.75, "spot": 9.0, "mags": 5, "grenades": 3, "smoke": 1, "rifle_grenades": 0, "satchel": 0},
    "Automatic Rifleman": {"hp": 105, "weapon": "Automatic Rifle", "speed": 2.35, "spot": 9.5, "mags": 5, "grenades": 1, "smoke": 0, "rifle_grenades": 0, "satchel": 0},
    "Marksman": {"hp": 90, "weapon": "Marksman Rifle", "speed": 2.45, "spot": 13.5, "mags": 5, "grenades": 1, "smoke": 1, "rifle_grenades": 0, "satchel": 0},
    "HMG Crew": {"hp": 135, "weapon": "Heavy Machine Gun", "speed": 1.45, "spot": 10.5, "mags": 3, "grenades": 0, "smoke": 0, "rifle_grenades": 0, "satchel": 0, "crew": 2},
    "Mortar Team": {"hp": 95, "weapon": "Carbine", "speed": 1.90, "spot": 9.0, "mags": 3, "grenades": 0, "smoke": 0, "rifle_grenades": 0, "satchel": 0, "mortar": 8},
}

STANCE = {
    "standing": {"speed": 1.00, "hit": 0, "acc": 0, "spot": 0},
    "crouched": {"speed": 0.72, "hit": -8, "acc": 3, "spot": -1},
    "prone": {"speed": 0.38, "hit": -17, "acc": 7, "spot": -3},
}

DIFFICULTY = {
    # Weapon physics are shared between difficulties. Difficulty changes force size,
    # decision cadence and tactical coordination instead of granting aim cheats.
    "Easy": {"enemy": 8, "acc": 0, "ai": 0.72, "tactics": .55},
    "Hard": {"enemy": 11, "acc": 0, "ai": 0.42, "tactics": 1.00},
    "Veteran": {"enemy": 14, "acc": 0, "ai": 0.25, "tactics": 1.30},
}

PLAYER_ROLE_ORDER = [
    "Rifleman", "Machine Gunner", "Sniper", "Medic", "Engineer", "Recon",
    "Grenadier", "Assault", "Automatic Rifleman", "Marksman", "HMG Crew", "Mortar Team",
]
DEFAULT_PLAYER_ROSTER = [
    "Rifleman", "Rifleman", "Machine Gunner", "Sniper", "Medic", "Engineer",
    "Recon", "Grenadier", "Assault", "Automatic Rifleman", "Marksman", "HMG Crew", "Mortar Team",
]
MAX_PLAYER_UNITS = 16
MAX_ROLE_COUNT = 8

BASE_DIR = Path(__file__).resolve().parent
ASSET_DIR = BASE_DIR / "assets"
AUDIO_DIR = ASSET_DIR / "audio"
FX_DIR = ASSET_DIR / "fx"

# Redistribution-safe CC0 assets. The game downloads these once on the first run.
# Source/license details are also written to ASSET_SOURCES.md in the repository.
ASSET_MANIFEST = {
    "rifle_556.mp3": "https://raw.githubusercontent.com/euuuuuuan/fatal-funnel-public/main/apps/game/public/sfx/rifle_556.mp3",
    "rifle_762.mp3": "https://raw.githubusercontent.com/euuuuuuan/fatal-funnel-public/main/apps/game/public/sfx/rifle_762.mp3",
    "smg_9mm.mp3": "https://raw.githubusercontent.com/euuuuuuan/fatal-funnel-public/main/apps/game/public/sfx/smg_9mm.mp3",
    "explosion1.ogg": "https://opengameart.org/sites/default/files/explosion1_0.ogg",
    "explosion2.ogg": "https://opengameart.org/sites/default/files/explosion2.ogg",
    "hurt_01.mp3": "https://opengameart.org/sites/default/files/hurt_01_0.mp3",
    "hurt_03.mp3": "https://opengameart.org/sites/default/files/hurt_03.mp3",
    "scream_horror1.mp3": "https://opengameart.org/sites/default/files/scream_horror1_0.mp3",
    "blood_red.png": "https://opengameart.org/sites/default/files/blood_red_0.png",
}


def bootstrap_assets_async():
    """Fetch optional CC0 presentation assets without blocking startup."""
    AUDIO_DIR.mkdir(parents=True, exist_ok=True)
    FX_DIR.mkdir(parents=True, exist_ok=True)
    def worker():
        for name, url in ASSET_MANIFEST.items():
            dest = (FX_DIR if name.endswith('.png') else AUDIO_DIR) / name
            if dest.exists() and dest.stat().st_size > 128:
                continue
            try:
                req = urllib.request.Request(url, headers={"User-Agent": "KillZone/0.4"})
                with urllib.request.urlopen(req, timeout=8) as r:
                    data = r.read()
                if len(data) > 128:
                    dest.write_bytes(data)
            except Exception:
                # Audio/FX are optional; gameplay must remain functional offline.
                pass
    threading.Thread(target=worker, name="killzone-assets", daemon=True).start()


def clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


def dist(a, b) -> float:
    ax, ay = a.pos if hasattr(a, "pos") else a
    bx, by = b.pos if hasattr(b, "pos") else b
    return math.hypot(ax - bx, ay - by)


def angle_to(a, b) -> float:
    ax, ay = a.pos if hasattr(a, "pos") else a
    bx, by = b.pos if hasattr(b, "pos") else b
    return math.degrees(math.atan2(by - ay, bx - ax)) % 360


def angle_diff(a: float, b: float) -> float:
    return abs((a - b + 180) % 360 - 180)


@dataclass
class Cell:
    terrain: str = "open"
    axis: Optional[str] = None
    hp: Optional[float] = None
    smoke: float = 0.0
    fire: float = 0.0
    mine: bool = False
    mine_seen_player: bool = False
    mine_seen_enemy: bool = False
    fort_progress: float = 0.0
    door_open: bool = False
    cover_wear: float = 0.0
    ground_suppression: float = 0.0

    def reset_terrain(self, terrain: str, axis: Optional[str] = None):
        self.terrain = terrain
        self.axis = axis
        hp = TERRAIN[terrain]["hp"]
        self.hp = float(hp) if hp is not None else None
        self.cover_wear = 0.0


@dataclass
class Explosion:
    x: float
    y: float
    timer: float
    radius: float
    damage: float
    suppression: float
    kind: str = "HE"
    faction: str = "neutral"


@dataclass
class Tracer:
    a: Tuple[float, float]
    b: Tuple[float, float]
    life: float = 0.20
    total: float = 0.20


@dataclass
class Impact:
    x: float
    y: float
    kind: str = "dirt"
    life: float = 0.22


@dataclass
class BloodDecal:
    x: float
    y: float
    size: float
    seed: int
    fresh: float = 1.0


@dataclass
class BoundingOrder:
    a: List[int]
    b: List[int]
    dest: Coord
    phase: int = 0
    timer: float = 0.0


@dataclass
class Unit:
    uid: int
    faction: str
    role: str
    x: float
    y: float
    hp: float
    max_hp: float
    morale: float = 100.0
    suppression: float = 0.0
    cohesion: float = 100.0
    stance: str = "standing"
    facing: float = 0.0
    casualty: str = "healthy"  # healthy/wounded/incapacitated/dead/surrendered
    bleed: float = 0.0
    weapon_name: str = "Service Rifle"
    ammo: int = 0
    magazines: List[int] = field(default_factory=list)
    grenades: int = 0
    smoke_grenades: int = 0
    rifle_grenades: int = 0
    satchel: int = 0
    med_supplies: int = 0
    tools: int = 0
    mortar_shells: int = 0
    crew: int = 1
    assistant_alive: bool = False
    barrel_spares: int = 1
    heat: float = 0.0
    jammed: bool = False
    deployed: bool = False
    bayonet: bool = False
    aim_progress: float = 0.0
    order: str = "idle"
    fire_mode: str = "normal"  # snap/normal/aimed/rapid
    target_uid: Optional[int] = None
    target_pos: Optional[Tuple[float, float]] = None
    path: List[Coord] = field(default_factory=list)
    waypoints: List[Coord] = field(default_factory=list)
    move_mode: str = "safe"  # fast/safe/manual
    action_timer: float = 0.0
    reload_timer: float = 0.0
    next_shot: float = 0.0
    signature: float = 0.0
    overwatch: bool = False
    arc_width: float = 90.0
    arc_range: float = 10.0
    fire_lane: bool = False
    fire_lane_center: float = 0.0
    dragging_uid: Optional[int] = None
    carrying_uid: Optional[int] = None
    reload_emergency: bool = False
    covering_uid: Optional[int] = None
    route_preview: List[Coord] = field(default_factory=list)
    selected: bool = False
    last_ai: float = 0.0
    spotted_player_until: float = 0.0
    spotted_enemy_until: float = 0.0
    peek_until: float = 0.0
    rally_shock: float = 0.0
    momentum: float = 0.0
    fire_discipline: str = "free"  # hold / return / free / confident
    target_priority: str = "specialist"  # nearest / exposed / specialist / suppressed
    command_queue: List[Tuple[str, object]] = field(default_factory=list)
    under_fire_until: float = 0.0
    last_attacker_uid: Optional[int] = None
    stamina: float = 100.0
    disoriented_until: float = 0.0
    traverse_ready_at: float = 0.0
    reaction_ready_at: float = 0.0
    reaction_target_uid: Optional[int] = None
    command_delay_until: float = 0.0
    stationary_time: float = 0.0
    prepared: float = 0.0
    incoming_bearings: List[Tuple[float, float]] = field(default_factory=list)
    auto_reload: bool = True
    auto_cover: bool = True
    auto_smoke: bool = True
    auto_medic: bool = True
    fallback_point: Optional[Coord] = None

    @property
    def pos(self):
        return (self.x, self.y)

    @property
    def tile(self) -> Coord:
        return (int(round(self.x)), int(round(self.y)))

    @property
    def weapon(self) -> dict:
        return WEAPONS[self.weapon_name]

    @property
    def alive(self) -> bool:
        return self.casualty not in ("dead", "surrendered")

    @property
    def combat_effective(self) -> bool:
        return self.casualty in ("healthy", "wounded") and self.hp > 0


class RealTimeGame:
    def __init__(self, seed: Optional[int] = None, difficulty: str = "Hard", player_roster: Optional[List[str]] = None):
        self.seed = seed if seed is not None else random.randint(100000, 999999)
        cleaned_roster = [r for r in (player_roster or DEFAULT_PLAYER_ROSTER) if r in ROLES][:MAX_PLAYER_UNITS]
        self.player_roster = cleaned_roster or ["Rifleman"]
        self.rng = random.Random(self.seed)
        self.difficulty = difficulty
        self.time = 0.0
        self.grid = [[Cell() for _ in range(MAP_W)] for _ in range(MAP_H)]
        self.units: List[Unit] = []
        self.explosions: List[Explosion] = []
        self.tracers: List[Tracer] = []
        self.impacts: List[Impact] = []
        self.blood: List[BloodDecal] = []
        self.events: List[dict] = []
        self.bounding_orders: List[BoundingOrder] = []
        self.intel = {"player": {}, "enemy": {}}
        self.log: List[str] = []
        self.next_uid = 1
        self.weather = self.rng.choice(["clear", "clear", "rain", "fog"])
        self.wind = self.rng.choice([(1, 0), (-1, 0), (0, 1), (0, -1)])
        self.support = {"player_HE": 2, "player_SMOKE": 2, "enemy_HE": 1, "enemy_SMOKE": 1}
        self.victory = False
        self.defeat = False
        self.paused = False
        self._spot_timer = 0.0
        self._world_timer = 0.0
        self._cohesion_timer = 0.0
        self.generate_map()
        self.rally_points = {"player": (3, MAP_H//2), "enemy": (MAP_W-4, MAP_H//2)}
        self.spawn_default_forces()
        self.add_log(f"Realtime battle started. Seed {self.seed}. Weather: {self.weather}.")

    # ------------------------------------------------------------------ map
    def set_cell(self, x: int, y: int, terrain: str, axis: Optional[str] = None):
        if 0 <= x < MAP_W and 0 <= y < MAP_H:
            self.grid[y][x].reset_terrain(terrain, axis)
            if terrain == "door":
                self.grid[y][x].door_open = False

    def generate_map(self):
        # Base no-man's-land with coherent lanes rather than noise.
        for y in range(MAP_H):
            for x in range(MAP_W):
                self.set_cell(x, y, "open")
        # Main road.
        road_y = self.rng.randint(5, MAP_H - 6)
        for x in range(MAP_W):
            if self.rng.random() < .94:
                self.set_cell(x, road_y, "road")
        # Defensive trench network on the east.
        tx = MAP_W - 10
        for y in range(2, MAP_H - 2):
            self.set_cell(tx, y, "trench", "V")
        for x in range(tx - 5, MAP_W - 2):
            for y in (5, MAP_H // 2, MAP_H - 6):
                self.set_cell(x, y, "trench", "H")
        # Communication trench toward the centre.
        cx, cy = tx, MAP_H // 2
        for i in range(7):
            self.set_cell(cx - i, cy + (i // 3), "trench", "H")
        # Traverses, firing bays and dugouts break up long enfilade lines.
        for y in range(4, MAP_H-4, 5):
            side = -1 if (y//5) % 2 else 1
            self.set_cell(tx + side, y, "trench", "H")
            self.set_cell(tx + side, y + 1, "firing_step", "V")
            if self.in_bounds(tx + 2*side, y+1):
                self.set_cell(tx + 2*side, y+1, "dugout")
            if self.in_bounds(tx - side, y):
                self.set_cell(tx - side, y, "sandbags")
        # Bunkers / sandbags.
        for y in (5, MAP_H // 2, MAP_H - 6):
            self.set_cell(tx + 2, y, "bunker")
            for dy in (-1, 1):
                if 0 <= y + dy < MAP_H:
                    self.set_cell(tx - 1, y + dy, "sandbags")
        # Wire belt with deliberate breaches.
        wx = tx - 5
        gaps = {road_y, MAP_H // 2 + 1, self.rng.randint(2, MAP_H - 3)}
        for y in range(1, MAP_H - 1):
            if y not in gaps:
                self.set_cell(wx, y, "wire")
        # Minefield patches behind/around wire.
        for _ in range(28):
            x = self.rng.randint(wx - 2, tx - 1)
            y = self.rng.randint(2, MAP_H - 3)
            if self.grid[y][x].terrain in ("open", "mud", "road"):
                self.grid[y][x].mine = True
        # Crater field in open ground.
        for _ in range(55):
            x = self.rng.randint(8, wx - 2)
            y = self.rng.randint(1, MAP_H - 2)
            if self.grid[y][x].terrain == "open":
                self.set_cell(x, y, self.rng.choice(["crater", "crater", "mud", "foxhole"]))
        # Woods clusters and hills.
        for _ in range(6):
            cx = self.rng.randint(4, wx - 2)
            cy = self.rng.randint(2, MAP_H - 3)
            for _ in range(self.rng.randint(7, 14)):
                x = int(clamp(cx + self.rng.randint(-2, 2), 1, MAP_W - 2))
                y = int(clamp(cy + self.rng.randint(-2, 2), 1, MAP_H - 2))
                if self.grid[y][x].terrain == "open":
                    self.set_cell(x, y, self.rng.choice(["woods", "woods", "hill"]))
        # Small building compound with doors.
        bx, by = self.rng.randint(11, 16), self.rng.randint(3, MAP_H - 8)
        for x in range(bx, bx + 5):
            for y in (by, by + 4):
                self.set_cell(x, y, "building")
        for y in range(by, by + 5):
            for x in (bx, bx + 4):
                self.set_cell(x, y, "building")
        self.set_cell(bx + 2, by + 4, "door")
        self.set_cell(bx + 1, by, "window")
        self.set_cell(bx + 3, by, "window")
        # A lighter wooden hut demonstrates bullet penetration through thin walls.
        hx,hy=bx+7,max(2,by-1)
        if hx+3<MAP_W-2:
            for xx in range(hx,hx+4):
                self.set_cell(xx,hy,"woodwall");self.set_cell(xx,hy+3,"woodwall")
            for yy in range(hy,hy+4):
                self.set_cell(hx,yy,"woodwall");self.set_cell(hx+3,yy,"woodwall")
            self.set_cell(hx+1,hy+3,"door")
            self.set_cell(hx+2,hy,"window")
        # Stream and bridges sometimes.
        if self.rng.random() < .55:
            sx = self.rng.randint(18, 23)
            bridge_ys = {road_y, self.rng.randint(4, MAP_H - 5)}
            for y in range(MAP_H):
                self.set_cell(sx, y, "bridge" if y in bridge_ys else "water")
        # Defensive wall fragments.
        for _ in range(12):
            x = self.rng.randint(tx - 2, MAP_W - 3)
            y = self.rng.randint(2, MAP_H - 3)
            if self.grid[y][x].terrain == "open":
                self.set_cell(x, y, "wall")

    # --------------------------------------------------------------- spawning
    def add_unit(self, faction: str, role: str, x: float, y: float) -> Unit:
        d = ROLES[role]
        weapon = d["weapon"]
        mag = WEAPONS[weapon]["mag"]
        u = Unit(
            uid=self.next_uid, faction=faction, role=role, x=x, y=y,
            hp=float(d["hp"]), max_hp=float(d["hp"]), weapon_name=weapon,
            ammo=mag, magazines=[mag for _ in range(max(0, d.get("mags", 4) - 1))],
            grenades=d.get("grenades", 0), smoke_grenades=d.get("smoke", 0),
            rifle_grenades=d.get("rifle_grenades", 0), satchel=d.get("satchel", 0),
            med_supplies=d.get("med", 0), tools=d.get("tools", 0),
            mortar_shells=d.get("mortar", 0), crew=d.get("crew", 1),
            assistant_alive=(role in ("Machine Gunner", "HMG Crew")),
            barrel_spares=2 if role in ("Machine Gunner", "HMG Crew") else 0,
            facing=0 if faction == "player" else 180,
        )
        self.next_uid += 1
        self.units.append(u)
        return u

    def spawn_default_forces(self):
        player_roles = list(self.player_roster)
        slots = [(2 + i % 4, 3 + (i // 4) * 5 + (i % 2)) for i in range(len(player_roles))]
        for role, (x, y) in zip(player_roles, slots):
            self.add_unit("player", role, x, min(y, MAP_H - 2))
        enemy_pool = ["Rifleman", "Rifleman", "Machine Gunner", "Marksman", "Assault", "Grenadier", "Engineer", "Medic", "Automatic Rifleman", "HMG Crew"]
        n = DIFFICULTY[self.difficulty]["enemy"]
        spots = []
        tx = MAP_W - 10
        for y in range(2, MAP_H - 2):
            if self.grid[y][tx].terrain in ("trench", "firing_step"):
                spots.append((tx, y))
        self.rng.shuffle(spots)
        for i in range(n):
            role = enemy_pool[i % len(enemy_pool)]
            x, y = spots[i % len(spots)]
            if self.unit_at(x, y) is not None:
                y = int(clamp(y + 1, 1, MAP_H - 2))
            u = self.add_unit("enemy", role, x, y)
            if role in ("Machine Gunner", "HMG Crew"):
                u.deployed = True
                u.fire_lane = True
                u.fire_lane_center = 180
                u.arc_width = 90

    # ------------------------------------------------------------- utilities
    def add_log(self, msg: str):
        self.log.append(msg)
        self.log = self.log[-12:]

    def emit(self, event_type: str, **payload):
        payload["type"] = event_type
        self.events.append(payload)

    def drain_events(self) -> List[dict]:
        out, self.events = self.events, []
        return out

    def get_unit(self, uid: Optional[int]) -> Optional[Unit]:
        return next((u for u in self.units if u.uid == uid), None)

    def unit_at(self, x: int, y: int, include_incap=True) -> Optional[Unit]:
        for u in self.units:
            if not u.alive:
                continue
            if not include_incap and not u.combat_effective:
                continue
            if int(round(u.x)) == x and int(round(u.y)) == y:
                return u
        return None

    def living(self, faction: Optional[str] = None) -> List[Unit]:
        return [u for u in self.units if u.alive and (faction is None or u.faction == faction)]

    @staticmethod
    def in_bounds(x: int, y: int) -> bool:
        return 0 <= x < MAP_W and 0 <= y < MAP_H

    def line_cells(self, a, b) -> List[Coord]:
        x0, y0 = (int(round(a[0])), int(round(a[1])))
        x1, y1 = (int(round(b[0])), int(round(b[1])))
        cells = []
        dx, dy = abs(x1-x0), abs(y1-y0)
        sx, sy = (1 if x0 < x1 else -1), (1 if y0 < y1 else -1)
        err = dx-dy
        while True:
            cells.append((x0,y0))
            if x0 == x1 and y0 == y1: break
            e2 = 2*err
            if e2 > -dy: err -= dy; x0 += sx
            if e2 < dx: err += dx; y0 += sy
        return cells

    def line_info(self, a, b) -> Tuple[bool, float, int, float]:
        """clear, smoke density, soft penetration cost, maximum intervening height."""
        smoke = 0.0
        soft_pen = 0
        max_h = -9
        cells = self.line_cells(a, b)
        for x, y in cells[1:-1]:
            c = self.grid[y][x]
            smoke += c.smoke
            if c.terrain == "hill":
                max_h = max(max_h, TERRAIN[c.terrain]["height"])
            if c.terrain == "door" and not c.door_open:
                return False, smoke, 99, max_h
            if c.terrain in ("woods", "sandbags", "door", "woodwall", "window"):
                soft_pen += TERRAIN[c.terrain]["pen"]
            elif TERRAIN[c.terrain]["blocks"]:
                return False, smoke, 99, max_h
        # reverse-slope abstraction: a hill between two lower positions blocks sight/fire.
        sh = TERRAIN[self.grid[int(round(a[1]))][int(round(a[0]))].terrain]["height"]
        th = TERRAIN[self.grid[int(round(b[1]))][int(round(b[0]))].terrain]["height"]
        if max_h > max(sh, th) and len(cells) > 3:
            return False, smoke, soft_pen, max_h
        return True, smoke, soft_pen, max_h

    def trench_corner_blocked(self, a: Unit, b: Unit) -> bool:
        if dist(a, b) > 5.0:
            return False
        ax, ay = a.tile; bx, by = b.tile
        if self.grid[ay][ax].terrain != "trench" or self.grid[by][bx].terrain != "trench":
            return False
        # If endpoints sit in differently oriented trench pieces without straight connection,
        # treat the corner as blind until somebody peeks/moves around it.
        aa, ba = self.grid[ay][ax].axis, self.grid[by][bx].axis
        return aa is not None and ba is not None and aa != ba and self.time > a.peek_until

    def can_see(self, observer: Unit, target: Unit) -> bool:
        if not observer.combat_effective or not target.alive:
            return False
        d = dist(observer, target)
        oh = TERRAIN[self.grid[observer.tile[1]][observer.tile[0]].terrain]["height"]
        th = TERRAIN[self.grid[target.tile[1]][target.tile[0]].terrain]["height"]
        role_spot = ROLES[observer.role]["spot"] + STANCE[observer.stance]["spot"] + max(0, oh-th)*2.0
        conceal = TERRAIN[self.grid[target.tile[1]][target.tile[0]].terrain]["conceal"] / 10
        if target.stance == "prone": conceal += 2.0
        if target.signature > 0: conceal -= min(3.0, target.signature / 18)
        if self.weather == "fog": role_spot -= 3.0
        if d > role_spot - conceal:
            return False
        clear, smoke, _, _ = self.line_info(observer.pos, target.pos)
        if not clear or smoke >= 2.1:
            return False
        if self.trench_corner_blocked(observer, target):
            return False
        return True

    def visible_to(self, faction: str, target: Unit) -> bool:
        if target.faction == faction:
            return True
        attr = "spotted_player_until" if faction == "player" else "spotted_enemy_until"
        return getattr(target, attr) > self.time

    def update_spotting(self):
        for target in self.living():
            for faction in ("player", "enemy"):
                if target.faction == faction: continue
                observers = [u for u in self.living(faction) if u.combat_effective]
                if any(self.can_see(o, target) for o in observers):
                    if faction == "player": target.spotted_player_until = self.time + 2.2
                    else: target.spotted_enemy_until = self.time + 2.2
                    self.intel[faction][target.uid] = {"pos": (target.x, target.y), "seen": self.time, "role": target.role}
        # engineers/recon reveal adjacent mines.
        for u in self.living():
            if u.role not in ("Engineer", "Recon"): continue
            ux, uy = u.tile
            radius = 3 if u.role == "Engineer" else 2
            for y in range(max(0,uy-radius), min(MAP_H,uy+radius+1)):
                for x in range(max(0,ux-radius), min(MAP_W,ux+radius+1)):
                    if self.grid[y][x].mine and math.hypot(x-ux,y-uy) <= radius:
                        if u.faction == "player": self.grid[y][x].mine_seen_player = True
                        else: self.grid[y][x].mine_seen_enemy = True

    def effective_cover(self, attacker: Unit, target: Unit) -> float:
        tx, ty = target.tile
        c = self.grid[ty][tx]
        cover = float(TERRAIN[c.terrain]["cover"])
        # Directional trench cover: strongest when fire crosses the trench, weak along it.
        if c.terrain in ("trench", "firing_step") and c.axis:
            shot = angle_to(target, attacker)
            axis_deg = 0 if c.axis == "H" else 90
            along = min(angle_diff(shot, axis_deg), angle_diff(shot, axis_deg + 180))
            if along < 28:
                cover = 1.0  # enfilade
            else:
                cover = 5.0
        # flanking/rear fire defeats some cover.
        incoming = angle_to(target, attacker)
        flank = angle_diff(target.facing, incoming)
        if flank > 120: cover -= 2
        elif flank > 70: cover -= 1
        # stance changes exposed body area.
        if target.stance == "prone": cover += 1.5
        elif target.stance == "crouched": cover += .7
        # Sustained fire chips away at parapets, sandbags and firing positions.
        cover -= c.cover_wear * 2.2
        return max(0, cover)

    def crossfire_pressure(self, target: Unit) -> float:
        """0..1 pressure from recent fire arriving from meaningfully different bearings."""
        target.incoming_bearings = [(a,t) for a,t in target.incoming_bearings if self.time-t <= 3.2]
        if len(target.incoming_bearings) < 2:
            return 0.0
        angles=[a for a,_ in target.incoming_bearings]
        spread=max((angle_diff(a,b) for a in angles for b in angles), default=0.0)
        if spread < 45:return 0.0
        return clamp((spread-45)/105,0,1)

    def reaction_delay(self, u: Unit, target: Optional[Unit] = None) -> float:
        base={"Heavy Machine Gun":.72,"Light Machine Gun":.58,"Scoped Rifle":.62,"Marksman Rifle":.46,"Service Rifle":.34,"Carbine":.30,"SMG":.24,"Automatic Rifle":.36}.get(u.weapon_name,.36)
        base += u.suppression*.012
        base += self.crossfire_pressure(u)*.75
        if self.time < u.disoriented_until:base += .9
        if u.casualty=="wounded":base += .18 + (1-u.hp/max(1,u.max_hp))*.35
        if u.prepared>.7:base *= .72
        return clamp(base,.16,2.8)

    def traverse_delay(self, u: Unit, target) -> float:
        turn=angle_diff(u.facing,angle_to(u,target))
        speed={"Heavy Machine Gun":65,"Light Machine Gun":95,"Scoped Rifle":120,"Marksman Rifle":145,"Service Rifle":170,"Carbine":195,"SMG":230,"Automatic Rifle":150}.get(u.weapon_name,170)
        if u.deployed and u.weapon_name in ("Heavy Machine Gun","Light Machine Gun"):speed*=.72
        speed*=clamp(1-u.suppression*.005,.45,1.0)
        return turn/max(30,speed)

    def degrade_cover(self, pos: Tuple[float,float], power: float, weapon_pen: int = 1):
        x,y=int(round(pos[0])),int(round(pos[1]))
        if not self.in_bounds(x,y):return
        c=self.grid[y][x]
        if c.terrain not in ("sandbags","woodwall","window","door","trench","firing_step","foxhole","bunker","woods"):
            return
        wear=(power/120.0)*(0.45+weapon_pen*.12)
        c.cover_wear=clamp(c.cover_wear+wear,0,1)
        if c.hp is not None and power>12:
            c.hp-=power*.10
            if c.hp<=0:
                if c.terrain in ("sandbags","woodwall","window","door","bunker"):c.reset_terrain("rubble")
                elif c.terrain=="woods":c.reset_terrain("open")

    def known_contacts(self, faction: str, memory: float = 10.0):
        out=[]
        stale=[]
        for uid, info in self.intel[faction].items():
            age=self.time-info["seen"]
            if age>memory:
                stale.append(uid);continue
            out.append((uid, info, age))
        for uid in stale:self.intel[faction].pop(uid,None)
        return out

    # --------------------------------------------------------------- pathing
    def passable(self, x: int, y: int, unit: Optional[Unit] = None) -> bool:
        if not self.in_bounds(x,y): return False
        c = self.grid[y][x]
        if c.terrain == "door" and not c.door_open: return False
        if TERRAIN[c.terrain]["move"] >= 999: return False
        other = self.unit_at(x,y)
        if other and (unit is None or other.uid != unit.uid) and other.combat_effective:
            return False
        return True

    def tile_threat(self, faction: str, x: int, y: int) -> float:
        # Deliberately cheap approximation for routing/overlay. Actual shots still use
        # precise LOS. Re-running Bresenham LOS for every A* candidate made safe
        # routing too expensive for a real-time simulation.
        threat = 0.0
        enemy_faction = "enemy" if faction == "player" else "player"
        for e in self.living(enemy_faction):
            if not e.combat_effective:
                continue
            if faction == "player" and not self.visible_to("player", e):
                continue
            if faction == "enemy" and not self.visible_to("enemy", e):
                continue
            d = math.hypot(e.x-x, e.y-y)
            if d > e.weapon["range"] + 1.5:
                continue
            local = max(.15, 1.25 - d / max(1.0, e.weapon["range"]))
            bearing = angle_to(e, (x,y))
            if (e.overwatch or e.fire_lane) and angle_diff(e.fire_lane_center, bearing) <= e.arc_width/2:
                local += .9
            if e.role in ("Machine Gunner","HMG Crew"):
                local += .35
            threat += local
        return threat

    def find_path(self, unit: Unit, dest: Coord, mode: Optional[str] = None) -> List[Coord]:
        mode = mode or unit.move_mode
        start = unit.tile
        if not self.passable(*dest, unit): return []
        pq = [(0.0, start)]
        came: Dict[Coord, Optional[Coord]] = {start: None}
        cost = {start: 0.0}
        while pq:
            _, cur = heapq.heappop(pq)
            if cur == dest: break
            x,y = cur
            for nx,ny in ((x+1,y),(x-1,y),(x,y+1),(x,y-1)):
                if not self.passable(nx,ny,unit): continue
                cell = self.grid[ny][nx]
                step = TERRAIN[cell.terrain]["move"]
                # Connected trenches are intentionally fast protected movement routes.
                if cell.terrain == "trench" and self.grid[y][x].terrain == "trench": step *= .62
                if mode == "safe":
                    step += self.tile_threat(unit.faction,nx,ny) * 2.45
                    step += cell.ground_suppression * .025
                    step = max(.18, step - min(.72, TERRAIN[cell.terrain]["cover"] * .12))
                    # Formation offsets and occupied-tile checks handle friendly spacing;
                    # keep A* itself cheap enough for realtime use.
                elif mode == "fast": step *= .8
                ncost = cost[cur] + step
                if (nx,ny) not in cost or ncost < cost[(nx,ny)]:
                    cost[(nx,ny)] = ncost
                    h = abs(dest[0]-nx)+abs(dest[1]-ny)
                    heapq.heappush(pq,(ncost+h*.4,(nx,ny)))
                    came[(nx,ny)] = cur
        if dest not in came: return []
        out=[]; cur=dest
        while cur != start:
            out.append(cur); cur=came[cur]
        out.reverse()
        return out

    def formation_offsets(self, n: int, formation: str):
        if formation == "line":
            return [(i-(n-1)/2,0) for i in range(n)]
        if formation == "column":
            return [(0,i) for i in range(n)]
        if formation == "wedge":
            out=[(0,0)]
            for i in range(1,n):
                rank=(i+1)//2;side=-1 if i%2 else 1;out.append((side*rank,rank))
            return out
        # spread
        cols=max(2,int(math.ceil(math.sqrt(n))))
        return [((i%cols)-(cols-1)/2,(i//cols)) for i in range(n)]

    def issue_move(self, units: List[Unit], dest: Coord, append=False, mode=None, formation="spread"):
        effective=[u for u in units if u.combat_effective]
        offsets=self.formation_offsets(len(effective),formation)
        for u,(ox,oy) in zip(effective,offsets):
            d = (int(clamp(round(dest[0]+ox),0,MAP_W-1)), int(clamp(round(dest[1]+oy),0,MAP_H-1)))
            if not self.passable(*d,u): d=dest
            if mode: u.move_mode = mode
            if append:
                u.command_queue.append(("move", d))
                continue
            u.waypoints = [d]
            u.path = []
            u.order = "move"
            u.command_delay_until = max(u.command_delay_until, self.time + u.suppression*.006 + self.crossfire_pressure(u)*.35)
            u.target_uid = None
            u.overwatch = False
            u.fire_lane = False

    def queue_fire(self, u: Unit, target_uid: int, mode: str = "normal"):
        u.command_queue.append(("fire", (target_uid, mode)))

    def process_command_queue(self, u: Unit):
        if u.order != "idle" or u.action_timer>0 or u.reload_timer>0 or not u.command_queue:return
        kind,data=u.command_queue.pop(0)
        if kind=="move": self.issue_move([u],data,formation="column")
        elif kind=="fire":
            uid,mode=data;t=self.get_unit(uid)
            if t and t.combat_effective:self.issue_fire(u,t,mode)

    # --------------------------------------------------------------- combat
    def hit_chance(self, attacker: Unit, target: Unit, mode: Optional[str]=None, reaction=False) -> float:
        mode = mode or attacker.fire_mode
        w = attacker.weapon
        d = dist(attacker,target)
        if d > w["range"]: return 0.0
        clear, smoke, soft_pen, _ = self.line_info(attacker.pos,target.pos)
        if not clear: return 0.0
        if soft_pen > w["pen"] + 1: return 0.0
        chance = float(w["acc"])
        chance += DIFFICULTY[self.difficulty]["acc"] if attacker.faction == "enemy" else 0
        chance -= max(0,d - 2) * 2.8
        chance -= self.effective_cover(attacker,target) * 9
        chance += STANCE[attacker.stance]["acc"] + STANCE[target.stance]["hit"]
        chance -= attacker.suppression * .32
        wound=max(0,1-attacker.hp/max(1,attacker.max_hp))
        if attacker.casualty == "wounded": chance -= 4 + wound*12
        if self.time < attacker.disoriented_until: chance -= 18
        chance += attacker.prepared*7
        chance += (attacker.cohesion - 50) * .08
        chance += (attacker.morale - 50) * .05
        chance -= smoke * 19
        chance -= soft_pen * 7
        if mode == "snap": chance -= 16
        elif mode == "aimed": chance += 18 + attacker.aim_progress * 10
        elif mode == "rapid": chance -= 12
        if attacker.deployed and attacker.role in ("Machine Gunner","HMG Crew"): chance += 8
        if attacker.role == "Sniper" and mode == "aimed" and attacker.suppression < 30 and attacker.action_timer <= 0 and smoke < .4 and d >= 3:
            chance = max(chance,80)
        if reaction: chance -= 8 + attacker.suppression*.06 + self.crossfire_pressure(attacker)*8
        # Facing/flank benefits.
        incoming = angle_to(target,attacker)
        flank = angle_diff(target.facing,incoming)
        if flank > 125: chance += 22
        elif flank > 75: chance += 11
        tc=self.grid[target.tile[1]][target.tile[0]]
        if tc.terrain in ("trench","firing_step") and tc.axis:
            shot=angle_to(target,attacker);axis_deg=0 if tc.axis=="H" else 90
            along=min(angle_diff(shot,axis_deg),angle_diff(shot,axis_deg+180))
            if along<28:chance+=12
        # CQB
        if d <= 2.2:
            if attacker.role == "Assault": chance += 18
            if attacker.bayonet and attacker.weapon_name in ("Service Rifle","Carbine"): chance += 8
            if attacker.weapon_name == "Scoped Rifle": chance -= 30
        ah = TERRAIN[self.grid[attacker.tile[1]][attacker.tile[0]].terrain]["height"]
        th = TERRAIN[self.grid[target.tile[1]][target.tile[0]].terrain]["height"]
        chance += (ah-th)*6.0
        if self.weather == "rain": chance -= 3
        elif self.weather == "fog": chance -= 7
        return clamp(chance,2,96)

    def fire_interval(self,u:Unit) -> float:
        rpm=u.weapon["rpm"]
        factor = 1.0
        if u.fire_mode == "rapid": factor=.62
        elif u.fire_mode == "snap": factor=.78
        elif u.fire_mode == "aimed": factor=1.45
        return 60.0/rpm*factor

    def issue_fire(self, unit: Unit, target: Unit, mode="normal"):
        if not unit.combat_effective: return
        unit.order="fire"; unit.target_uid=target.uid; unit.fire_mode=mode
        unit.overwatch=False; unit.fire_lane=False
        unit.command_delay_until=max(unit.command_delay_until,self.time+unit.suppression*.005)
        unit.traverse_ready_at=max(unit.traverse_ready_at,self.time+self.traverse_delay(unit,target))
        if mode == "aimed": unit.aim_progress = 0.0

    def perform_shot(self, attacker: Unit, target: Unit, reaction=False):
        if not attacker.combat_effective or not target.combat_effective: return
        if attacker.jammed or attacker.reload_timer > 0 or attacker.carrying_uid is not None: return
        if self.time < attacker.command_delay_until or self.time < attacker.traverse_ready_at:return
        if attacker.heat >= 100:
            attacker.order = "idle"
            self.add_log(f"{attacker.role} overheated; fire stopped.")
            return
        if attacker.ammo <= 0:
            self.start_reload(attacker); return
        w=attacker.weapon
        d=dist(attacker,target)
        if d>w["range"]: return
        attacker.facing=angle_to(attacker,target)
        chance=self.hit_chance(attacker,target,reaction=reaction)
        if chance <= 0: return
        attacker.ammo -= 1
        attacker.next_shot=self.time+self.fire_interval(attacker)
        attacker.signature=max(attacker.signature, 55 if attacker.role in ("Machine Gunner","HMG Crew") else 32)
        attacker.aim_progress = max(0, attacker.aim_progress - .35)
        # Heat / jams.
        heat_add=w["heat"] * (1.35 if attacker.fire_mode=="rapid" else 1.0)
        attacker.heat += heat_add
        jam_p=.002 + max(0,attacker.heat-75)*.0015
        if self.rng.random()<jam_p:
            attacker.jammed=True
            self.add_log(f"{attacker.role} weapon jammed.")
        ax,ay=attacker.pos; bx,by=target.pos
        self.tracers.append(Tracer((ax,ay),(bx,by)))
        self.emit("shot", weapon=attacker.weapon_name, pos=attacker.pos, faction=attacker.faction)
        target.under_fire_until=self.time+3.4;target.last_attacker_uid=attacker.uid
        target.incoming_bearings.append((angle_to(target,attacker),self.time))
        roll=self.rng.uniform(0,100)
        hit=roll<=chance
        # suppression always exists around actual fire; MGs are area denial weapons.
        supp=w["supp"]*(1.08 if hit else .72)
        if attacker.role in ("Machine Gunner","HMG Crew") and attacker.deployed: supp*=1.35
        # Prepared cover protects lives far more than it protects nerves.
        cover=self.effective_cover(attacker,target)
        supp*=max(.82,1-cover*.035)
        cross=self.crossfire_pressure(target)
        supp*=1.0+cross*.48
        target.suppression=clamp(target.suppression+supp,0,100)
        target.morale=clamp(target.morale-supp*(.15+cross*.08),0,100)
        tc=self.grid[target.tile[1]][target.tile[0]]
        tc.ground_suppression=clamp(tc.ground_suppression+supp*.55,0,100)
        self.degrade_cover(target.pos, w["damage"]*(.34 if hit else .20), w["pen"])
        if hit:
            close_mult=1.0+max(0,4-d)*.08
            dmg=w["damage"]*close_mult*self.rng.uniform(.80,1.18)
            if target.casualty=="wounded": dmg*=1.08
            self.apply_damage(target,dmg,attacker,"gunfire")
            self.impacts.append(Impact(target.x,target.y,"body",.20))
            attacker.momentum=clamp(attacker.momentum+12,0,100)
            attacker.prepared=max(0,attacker.prepared-.32)
            # Coordinated attack bonus: allies hitting already suppressed targets build momentum.
            if target.suppression>=50:
                for ally in self.living(attacker.faction):
                    if dist(ally,attacker)<=6: ally.momentum=clamp(ally.momentum+3,0,100)
        else:
            terrain=self.grid[target.tile[1]][target.tile[0]].terrain
            kind="metal" if terrain in ("wall","bunker","wire") else "cover" if TERRAIN[terrain]["cover"]>=2 else "dirt"
            self.impacts.append(Impact(target.x+self.rng.uniform(-.25,.25),target.y+self.rng.uniform(-.25,.25),kind,.18))
            # Near-miss suppression follows the bullet path rather than only the target tile.
            for other in self.living(target.faction):
                if other.uid==target.uid:continue
                px,py=other.pos;vx=bx-ax;vy=by-ay
                den=vx*vx+vy*vy
                q=0 if den<=1e-8 else clamp(((px-ax)*vx+(py-ay)*vy)/den,0,1)
                dd=math.hypot(px-(ax+q*vx),py-(ay+q*vy))
                if dd<=0.75:
                    other.suppression=clamp(other.suppression+supp*(.34 if dd<.35 else .20),0,100)
                    other.under_fire_until=self.time+2.2;other.last_attacker_uid=attacker.uid

    def apply_damage(self,target:Unit,damage:float,source:Optional[Unit],cause:str):
        if not target.alive: return
        target.hp-=damage
        target.morale=clamp(target.morale-damage*.35,0,100)
        target.under_fire_until=self.time+3.5
        if source:target.last_attacker_uid=source.uid
        self.emit("hurt", pos=target.pos, damage=damage, cause=cause)
        if damage>=12:
            self.blood.append(BloodDecal(target.x+self.rng.uniform(-.18,.18),target.y+self.rng.uniform(-.18,.18),clamp(damage/85,.12,.65),self.rng.randint(0,999999),1.0))
            self.blood=self.blood[-180:]
        if target.assistant_alive and damage >= 30 and self.rng.random() < min(.45, damage/180):
            target.assistant_alive = False
            target.crew = max(1, target.crew-1)
            target.morale = max(0, target.morale-12)
            self.add_log(f"{target.faction} {target.role} lost its assistant gunner.")
        if target.hp<=0:
            # Incapacitation vs immediate death.
            lethality=clamp((damage-25)/75,.12,.70)
            if self.rng.random()<lethality:
                target.casualty="dead"; target.hp=0; target.bleed=0
                self.blood.append(BloodDecal(target.x,target.y,self.rng.uniform(.55,.95),self.rng.randint(0,999999),1.0))
                self.emit("death", pos=target.pos, cause=cause)
                self.add_log(f"{target.faction} {target.role} killed ({cause}).")
            else:
                target.casualty="incapacitated"; target.hp=0; target.bleed=self.rng.uniform(12,28)
                self.add_log(f"{target.faction} {target.role} incapacitated.")
            target.order="idle"; target.path=[]; target.waypoints=[]
            # nearby casualty shock
            for ally in self.living(target.faction):
                if ally.uid!=target.uid and dist(ally,target)<5:
                    ally.morale=max(0,ally.morale-12)
                    ally.suppression=clamp(ally.suppression+8,0,100)
        elif target.hp<target.max_hp*.72 and target.casualty=="healthy":
            target.casualty="wounded"; target.bleed=self.rng.uniform(5,12)

    def start_reload(self,u:Unit, emergency=False):
        if u.reload_timer>0 or not u.magazines: return
        speed=1.0
        if u.role in ("Machine Gunner","HMG Crew") and u.assistant_alive: speed=.72
        wound=max(0,1-u.hp/max(1,u.max_hp));speed*=1.0+wound*.55
        if u.suppression>60:speed*=1.18
        if emergency: speed*=.68
        u.reload_emergency=emergency
        u.reload_timer=u.weapon["reload"]*speed
        u.order="reload"

    def finish_reload(self,u:Unit, emergency=None):
        if not u.magazines: return
        if emergency is None: emergency=u.reload_emergency
        # Tactical reload preserves a partial magazine. Emergency reload drops it.
        old=u.ammo
        new=u.magazines.pop(0)
        if old>0 and not emergency: u.magazines.append(old)
        u.ammo=new;u.reload_timer=0;u.reload_emergency=False;u.order="idle"

    def should_auto_reload(self,u:Unit) -> bool:
        if not u.auto_reload or not u.magazines or u.reload_timer>0 or u.action_timer>0 or u.jammed:return False
        if u.order in ("move","rout","medic","deploy","pack","barrel","clear_jam") or u.carrying_uid is not None:return False
        if u.ammo<=0:return True
        if u.role in ("Machine Gunner","HMG Crew","Automatic Rifleman") and u.order in ("idle","overwatch","fire_lane"):
            return u.ammo <= max(4,int(u.weapon["mag"]*.12))
        return False

    def clear_jam(self,u:Unit):
        if u.jammed and u.action_timer<=0:
            u.action_timer=1.8; u.order="clear_jam"

    def change_barrel(self,u:Unit):
        if u.role not in ("Machine Gunner","HMG Crew") or u.barrel_spares<=0 or u.action_timer>0: return
        u.action_timer=4.0; u.order="barrel"

    def toggle_deploy(self,u:Unit):
        if u.role not in ("Machine Gunner","HMG Crew","Mortar Team"): return
        u.action_timer=2.0 if not u.deployed else 1.2
        u.order="deploy" if not u.deployed else "pack"

    def set_overwatch(self,u:Unit,center:float,width=90):
        u.overwatch=True; u.fire_lane=False; u.fire_lane_center=center; u.arc_width=width
        u.arc_range=min(u.weapon["range"],12); u.order="overwatch"

    def set_fire_lane(self,u:Unit,center:float,width=45):
        if u.role not in ("Machine Gunner","HMG Crew"): return
        if not u.deployed: self.toggle_deploy(u); return
        u.fire_lane=True; u.overwatch=False; u.fire_lane_center=center; u.arc_width=width; u.arc_range=u.weapon["range"]; u.order="fire_lane"

    def suppress_area(self,u:Unit,pos:Tuple[float,float]):
        if u.role not in ("Machine Gunner","HMG Crew","Automatic Rifleman"): return
        u.order="suppress"; u.target_pos=pos; u.target_uid=None

    def throw_grenade(self,u:Unit,pos:Tuple[float,float],smoke=False,cook=0.0,rifle=False):
        if dist(u.pos,pos)> (7 if rifle else 4.5): return
        if smoke:
            if u.smoke_grenades<=0:return
            u.smoke_grenades-=1; fuse=max(.5,1.5-cook)
            self.explosions.append(Explosion(pos[0],pos[1],fuse,2.3,0,0,"SMOKE",u.faction))
        elif rifle:
            if u.rifle_grenades<=0:return
            u.rifle_grenades-=1; fuse=.8
            self.explosions.append(Explosion(pos[0],pos[1],fuse,2.0,62,58,"HE",u.faction))
        else:
            if u.grenades<=0:return
            u.grenades-=1; fuse=max(.35,2.4-cook)
            self.explosions.append(Explosion(pos[0],pos[1],fuse,2.0,72,68,"HE",u.faction))
        u.action_timer=.8; u.signature=max(u.signature,10)
        self.grenade_reaction(pos,u.faction)

    def grenade_reaction(self,pos,faction):
        for u in self.living():
            if not u.combat_effective or dist(u.pos,pos)>2.5: continue
            if u.suppression>=80 or u.action_timer>0: continue
            # auto dive away: useful but not guaranteed.
            if self.rng.random()<.68:
                ux,uy=u.tile
                candidates=[]
                for nx,ny in ((ux+1,uy),(ux-1,uy),(ux,uy+1),(ux,uy-1)):
                    if self.passable(nx,ny,u): candidates.append((dist((nx,ny),pos),(nx,ny)))
                if candidates:
                    _,best=max(candidates)
                    u.waypoints=[best];u.path=[];u.order="move";u.stance="prone"

    def place_satchel(self,u:Unit,pos:Coord):
        if u.satchel<=0 or dist(u.pos,pos)>1.5:return
        u.satchel-=1;u.action_timer=2.0
        self.explosions.append(Explosion(pos[0],pos[1],3.0,2.7,130,95,"HE",u.faction))

    def bayonet_toggle(self,u:Unit):
        if u.weapon_name not in ("Service Rifle","Carbine"): return
        u.bayonet=not u.bayonet

    def trench_assault(self,u:Unit,target:Unit):
        if not u.combat_effective or not target.combat_effective:return
        if dist(u,target)>1.45:return
        ux,uy=u.tile;tx,ty=target.tile
        if self.grid[uy][ux].terrain!="trench" or self.grid[ty][tx].terrain!="trench":return
        chance=45 + (u.morale-target.morale)*.25 + (u.momentum*.15) + (18 if u.bayonet else 0) + (20 if target.suppression>=50 else 0)
        if u.role=="Assault":chance+=20
        if self.rng.uniform(0,100)<clamp(chance,10,95):
            self.apply_damage(target,self.rng.uniform(55,100),u,"trench assault")
            target.suppression=100
        else:
            u.suppression=clamp(u.suppression+40,0,100)
        u.action_timer=1.8

    # ---------------------------------------------------- engineers / medics
    def medic_action(self,medic:Unit,target:Unit):
        if medic.role!="Medic" or medic.med_supplies<=0 or dist(medic,target)>1.5:return
        medic.action_timer=3.0;medic.order="medic";medic.target_uid=target.uid

    def drag_toggle(self,u:Unit,target:Unit):
        if dist(u,target)>1.5:return
        if target.casualty!="incapacitated":return
        u.carrying_uid=None
        u.dragging_uid=None if u.dragging_uid==target.uid else target.uid

    def carry_toggle(self,u:Unit,target:Unit):
        if dist(u,target)>1.5:return
        if target.casualty!="incapacitated":return
        u.dragging_uid=None
        u.carrying_uid=None if u.carrying_uid==target.uid else target.uid
        if u.carrying_uid is not None:
            u.target_uid=None
            u.overwatch=False;u.fire_lane=False

    def share_ammo(self,u:Unit,target:Unit):
        if dist(u,target)>1.5 or not u.magazines:return
        mag=u.magazines.pop()
        # only compatible weapon magazines transfer directly
        if u.weapon_name==target.weapon_name: target.magazines.append(mag)
        else: u.magazines.append(mag); return
        self.add_log(f"{u.role} shared a magazine with {target.role}.")

    def engineer_action(self,u:Unit,pos:Coord,kind:str):
        if u.role!="Engineer" or dist(u.pos,pos)>1.6:return
        x,y=pos;c=self.grid[y][x]
        if kind=="cut" and c.terrain=="wire" and u.tools>0:
            u.tools-=1;u.action_timer=2.5;u.order="eng_cut";u.target_pos=pos
        elif kind=="bangalore" and c.terrain=="wire" and u.satchel>0:
            u.satchel-=1;u.action_timer=2.0
            self.explosions.append(Explosion(x,y,2.0,2.4,95,80,"HE",u.faction))
        elif kind=="clear_mine" and c.mine and u.tools>0:
            u.tools-=1;u.action_timer=2.2;u.order="eng_mine";u.target_pos=pos
        elif kind=="fortify" and c.terrain in ("open","crater","mud","rubble") and u.tools>0:
            u.tools-=1;u.action_timer=5.0;u.order="eng_fort";u.target_pos=pos
        elif kind=="trench" and c.terrain in ("open","mud") and u.tools>0:
            u.tools-=1;u.action_timer=8.0;u.order="eng_trench";u.target_pos=pos
        elif kind=="wire" and c.terrain in ("open","mud","rubble") and u.tools>0:
            u.tools-=1;u.action_timer=4.5;u.order="eng_wire";u.target_pos=pos

    def scan_mines(self,u:Unit):
        if u.role not in ("Engineer","Recon"):return
        ux,uy=u.tile;radius=5 if u.role=="Engineer" else 4
        for y in range(max(0,uy-radius),min(MAP_H,uy+radius+1)):
            for x in range(max(0,ux-radius),min(MAP_W,ux+radius+1)):
                if self.grid[y][x].mine and math.hypot(x-ux,y-uy)<=radius:
                    if u.faction=="player":self.grid[y][x].mine_seen_player=True
                    else:self.grid[y][x].mine_seen_enemy=True
        u.action_timer=1.5;u.signature=max(u.signature,3)

    def peek(self,u:Unit):
        u.peek_until=self.time+2.0;u.action_timer=.6;u.signature=max(u.signature,4)

    # ------------------------------------------------------- indirect support
    def mortar_fire(self,u:Unit,pos:Tuple[float,float],smoke=False):
        if u.role!="Mortar Team" or not u.deployed or u.mortar_shells<=0:return
        if dist(u.pos,pos)<5 or dist(u.pos,pos)>22:return
        u.mortar_shells-=1;u.action_timer=3.0
        flight=2.8+self.rng.uniform(-.3,.4)
        scatter=1.4 if u.suppression<40 else 2.5
        px=clamp(pos[0]+self.rng.gauss(0,scatter*.35),0,MAP_W-1)
        py=clamp(pos[1]+self.rng.gauss(0,scatter*.35),0,MAP_H-1)
        if smoke:self.explosions.append(Explosion(px,py,flight,3.0,0,0,"SMOKE",u.faction))
        else:self.explosions.append(Explosion(px,py,flight,2.8,92,82,"HE",u.faction))

    def call_support(self,faction:str,pos:Tuple[float,float],smoke=False):
        key=f"{faction}_{'SMOKE' if smoke else 'HE'}"
        if self.support.get(key,0)<=0:return
        self.support[key]-=1
        for i in range(4 if not smoke else 3):
            px=clamp(pos[0]+self.rng.uniform(-2.0,2.0),0,MAP_W-1)
            py=clamp(pos[1]+self.rng.uniform(-2.0,2.0),0,MAP_H-1)
            self.explosions.append(Explosion(px,py,3.0+i*.35,3.0,85 if not smoke else 0,80 if not smoke else 0,"SMOKE" if smoke else "HE",faction))

    # -------------------------------------------------------------- explosions
    def resolve_explosion(self,e:Explosion):
        self.emit("explosion", pos=(e.x,e.y), kind=e.kind, radius=e.radius)
        if e.kind=="SMOKE":
            for y in range(max(0,int(e.y-e.radius)),min(MAP_H,int(e.y+e.radius)+1)):
                for x in range(max(0,int(e.x-e.radius)),min(MAP_W,int(e.x+e.radius)+1)):
                    d=math.hypot(x-e.x,y-e.y)
                    if d<=e.radius:
                        add=max(0,2.9-d*.34)
                        self.grid[y][x].smoke=clamp(self.grid[y][x].smoke+add,0,5.0)
            return
        for u in self.living():
            d=dist(u.pos,(e.x,e.y))
            if d<=e.radius:
                c=self.grid[u.tile[1]][u.tile[0]]
                confined=1.22 if c.terrain in ("trench","bunker","building") else 1.0
                dmg=max(0,e.damage*(1-d/e.radius)*confined)
                if u.stance=="prone":dmg*=.78
                self.apply_damage(u,dmg,None,"blast")
                shock=e.suppression*(1-d/e.radius)*confined
                u.suppression=clamp(u.suppression+shock,0,100)
                u.morale=clamp(u.morale-shock*.12,0,100)
                if d<=e.radius*.85:u.disoriented_until=max(u.disoriented_until,self.time+.7+(1-d/e.radius)*1.6)
                self.grid[u.tile[1]][u.tile[0]].ground_suppression=clamp(self.grid[u.tile[1]][u.tile[0]].ground_suppression+shock*.7,0,100)
        # terrain destruction and cratering
        for y in range(max(0,int(e.y-e.radius)),min(MAP_H,int(e.y+e.radius)+1)):
            for x in range(max(0,int(e.x-e.radius)),min(MAP_W,int(e.x+e.radius)+1)):
                d=math.hypot(x-e.x,y-e.y)
                if d>e.radius:continue
                c=self.grid[y][x]
                power=e.damage*(1-d/e.radius)
                if c.hp is not None:
                    c.hp-=power
                    if c.hp<=0:
                        if c.terrain in ("wall","building","woodwall","window","bunker","sandbags","door"):c.reset_terrain("rubble")
                        elif c.terrain=="wire":c.reset_terrain("open")
                        elif c.terrain=="bridge":c.reset_terrain("water")
                        elif c.terrain=="woods":c.reset_terrain("open")
                if power>65 and c.terrain in ("open","mud","road"): c.reset_terrain("crater")
                if power>105 and c.terrain=="trench" and self.rng.random()<.42: c.reset_terrain("rubble")
                if power>45 and c.terrain in ("woods","building") and self.rng.random()<.3:c.fire=max(c.fire,4.0)

    # ------------------------------------------------------------- simulation
    def update(self,dt:float):
        if self.paused or self.victory or self.defeat:return
        self.time+=dt
        self._world_timer -= dt
        self._spot_timer -= dt
        self._cohesion_timer -= dt
        if self._world_timer <= 0:
            self.update_weather_world(.20)
            self._world_timer = .20
        if self._spot_timer <= 0:
            self.update_spotting()
            self._spot_timer = .16
        # simultaneous unit simulation
        for u in list(self.units):
            self.update_unit(u,dt)
        self.update_reaction_fire()
        self.update_auto_behaviors()
        self.update_autofire()
        self.update_bounding_orders(dt)
        self.update_explosions(dt)
        if self._cohesion_timer <= 0:
            self.update_cohesion_and_morale(.33)
            self._cohesion_timer = .33
        self.update_ai(dt)
        self.check_end()
        for t in list(self.tracers):
            t.life-=dt
            if t.life<=0:self.tracers.remove(t)
        for i in list(self.impacts):
            i.life-=dt
            if i.life<=0:self.impacts.remove(i)
        for b in self.blood:b.fresh=max(0,b.fresh-dt*.09)

    def update_weather_world(self,dt):
        # Smoke decays, drifts with wind, rain creates some mud and suppresses fire.
        drift_chance=dt*.12
        moves=[]
        for y,row in enumerate(self.grid):
            for x,c in enumerate(row):
                if c.smoke>0:
                    c.smoke=max(0,c.smoke-dt*(.075 if self.weather=="fog" else .11))
                    if c.smoke>.8 and self.rng.random()<drift_chance:
                        nx,ny=x+self.wind[0],y+self.wind[1]
                        if self.in_bounds(nx,ny):moves.append((nx,ny,c.smoke*.10))
                if c.ground_suppression>0:
                    c.ground_suppression=max(0,c.ground_suppression-dt*2.1)
                if c.fire>0:
                    c.fire=max(0,c.fire-dt*(.42 if self.weather=="rain" else .14))
                    if c.fire>1 and self.rng.random()<dt*.04:
                        for nx,ny in ((x+1,y),(x-1,y),(x,y+1),(x,y-1)):
                            if self.in_bounds(nx,ny) and self.grid[ny][nx].terrain in ("woods","building"):
                                self.grid[ny][nx].fire=max(self.grid[ny][nx].fire,2.0)
                if self.weather=="rain" and c.terrain=="open" and self.rng.random()<dt*.00035:
                    c.reset_terrain("mud")
        for x,y,s in moves:self.grid[y][x].smoke=max(self.grid[y][x].smoke,s)

    def update_unit(self,u:Unit,dt:float):
        if not u.alive:return
        if u.casualty=="incapacitated":
            if u.bleed>0:
                u.bleed-=dt
                if u.bleed<=0:
                    u.casualty="dead"
                    self.blood.append(BloodDecal(u.x,u.y,self.rng.uniform(.45,.75),self.rng.randint(0,999999),1.0))
                    self.emit("death",pos=u.pos,cause="bleedout")
                    self.add_log(f"{u.faction} {u.role} bled out.")
            return
        if not u.combat_effective:return
        # Continuous suppression/heat/signature/stamina model. Intermittent incoming
        # fire keeps soldiers keyed up instead of letting suppression vanish instantly.
        cell=self.grid[u.tile[1]][u.tile[0]]
        cover=max(0,TERRAIN[cell.terrain]["cover"]-cell.cover_wear*2.2)
        under_fire=u.under_fire_until>self.time or cell.ground_suppression>22
        decay=(.75+cover*.16+(u.cohesion/100)*.55) if under_fire else (3.0+cover*.42+(u.cohesion/100)*1.45)
        u.suppression=max(0,u.suppression-dt*decay)
        u.heat=max(0,u.heat-dt*u.weapon["cool"])
        u.signature=max(0,u.signature-dt*8)
        u.momentum=max(0,u.momentum-dt*1.65)
        u.incoming_bearings=[(a,t) for a,t in u.incoming_bearings if self.time-t<=3.2]
        moving=u.order in ("move","rout") and (u.path or u.waypoints)
        if moving:
            drain=14 if u.move_mode=="fast" else 5.5
            u.stamina=max(0,u.stamina-dt*drain)
            u.stationary_time=0;u.prepared=max(0,u.prepared-dt*.9)
        else:
            u.stamina=min(100,u.stamina+dt*(11 if u.stance!="standing" else 8))
            if u.suppression<35 and cover>=1:
                u.stationary_time+=dt;u.prepared=clamp(u.stationary_time/4.0,0,1)
            else:u.stationary_time=max(0,u.stationary_time-dt)
        # Ground that is actively being swept by fire passes some suppression to arrivals.
        if cell.ground_suppression>18:
            u.suppression=clamp(u.suppression+dt*cell.ground_suppression*.035,0,100)
        # Broken soldiers prioritize survival over weapon maintenance.
        if (u.morale<16 or u.suppression>=98) and u.order not in ("rout","surrender"):
            self.handle_break(u)
        # Automatic weapon maintenance is deliberately state-aware.
        if u.order not in ("rout","surrender") and self.should_auto_reload(u):
            self.start_reload(u);return
        if u.action_timer>0:
            u.action_timer-=dt
            if u.action_timer<=0:self.complete_action(u)
            return
        if u.reload_timer>0:
            u.reload_timer-=dt
            if u.reload_timer<=0:self.finish_reload(u)
            return
        if u.jammed:return
        if self.time < u.command_delay_until:return
        # aiming can build while stationary
        if u.order=="fire" and u.fire_mode=="aimed" and not u.path:
            u.aim_progress=clamp(u.aim_progress+dt*.55,0,1)
        else:u.aim_progress=max(0,u.aim_progress-dt*.3)
        if u.order in ("move","rout"):
            self.update_movement(u,dt)
        elif u.order=="fire":
            target=self.get_unit(u.target_uid)
            if not target or not target.combat_effective:u.order="idle";u.target_uid=None
            elif self.time>=u.next_shot:self.perform_shot(u,target)
        elif u.order=="suppress":
            if self.time>=u.next_shot:self.perform_suppressive_shot(u)
        elif u.order in ("overwatch","fire_lane","idle"):
            pass
        self.process_command_queue(u)

    def complete_action(self,u:Unit):
        order=u.order
        if order=="clear_jam":u.jammed=False;u.order="idle"
        elif order=="barrel":u.barrel_spares=max(0,u.barrel_spares-1);u.heat=5;u.order="idle"
        elif order=="deploy":u.deployed=True;u.order="idle"
        elif order=="pack":u.deployed=False;u.order="idle"
        elif order=="medic":
            t=self.get_unit(u.target_uid)
            if t and dist(u,t)<=1.7 and u.med_supplies>0:
                u.med_supplies-=1
                if t.casualty=="incapacitated":
                    t.casualty="wounded";t.hp=max(22,t.max_hp*.24);t.bleed=0;t.morale=max(t.morale,35)
                    self.add_log(f"Medic stabilized {t.role}.")
                elif t.casualty=="wounded":
                    t.hp=min(t.max_hp*.75,t.hp+30);t.bleed=0
            u.order="idle"
        elif order.startswith("eng_"):
            if u.target_pos:
                x,y=int(u.target_pos[0]),int(u.target_pos[1]);c=self.grid[y][x]
                if order=="eng_cut" and c.terrain=="wire":c.reset_terrain("open")
                elif order=="eng_mine":c.mine=False;c.mine_seen_player=c.mine_seen_enemy=False
                elif order=="eng_fort":c.reset_terrain("sandbags")
                elif order=="eng_trench":c.reset_terrain("trench","H")
                elif order=="eng_wire":c.reset_terrain("wire")
            u.order="idle"

    def update_movement(self,u:Unit,dt:float):
        if u.deployed and u.role in ("Machine Gunner","HMG Crew","Mortar Team"):return
        if not u.path:
            if u.waypoints:
                dest=u.waypoints[0];u.path=self.find_path(u,dest,u.move_mode)
                if not u.path:u.waypoints.pop(0);return
            else:u.order="idle";return
        nx,ny=u.path[0]
        if not self.passable(nx,ny,u):u.path=[];return
        cell=self.grid[ny][nx]
        terrain_mult=TERRAIN[cell.terrain]["move"]
        base=ROLES[u.role]["speed"]*STANCE[u.stance]["speed"]
        wound=max(0,1-u.hp/max(1,u.max_hp))
        if u.casualty=="wounded":base*=clamp(1-wound*.42,.58,.92)
        base*=.68+.32*(u.stamina/100)
        if u.suppression>=50:base*=.78
        if u.suppression>=80:base*=.55
        if u.dragging_uid is not None:base*=.48
        if u.carrying_uid is not None:base*=.62
        speed=base/max(.55,terrain_mult)
        vx, vy = nx-u.x, ny-u.y
        vl = math.hypot(vx,vy)
        if vl < speed*dt or vl < 1e-6:
            oldx, oldy = u.x, u.y
            u.x,u.y=nx,ny;u.path.pop(0)
            if vl>1e-6:u.facing=math.degrees(math.atan2(ny-oldy,nx-oldx))%360
            self.on_enter_tile(u,nx,ny)
            if not u.path and u.waypoints and u.waypoints[0]==(nx,ny):u.waypoints.pop(0)
        else:
            step=speed*dt/vl;u.x+=vx*step;u.y+=vy*step;u.facing=math.degrees(math.atan2(vy,vx))%360
            u.signature=max(u.signature,10 if u.stance!="prone" else 4)
        if u.dragging_uid:
            t=self.get_unit(u.dragging_uid)
            if t and t.casualty=="incapacitated":t.x=u.x-.25*math.cos(math.radians(u.facing));t.y=u.y-.25*math.sin(math.radians(u.facing))
            else:u.dragging_uid=None
        if u.carrying_uid:
            t=self.get_unit(u.carrying_uid)
            if t and t.casualty=="incapacitated":t.x=u.x;t.y=u.y
            else:u.carrying_uid=None

    def on_enter_tile(self,u:Unit,x:int,y:int):
        c=self.grid[y][x]
        if c.mine:
            seen=c.mine_seen_player if u.faction=="player" else c.mine_seen_enemy
            trigger=.25 if seen else .72
            if self.rng.random()<trigger:
                c.mine=False;c.mine_seen_player=c.mine_seen_enemy=True
                self.explosions.append(Explosion(x,y,.05,1.7,90,80,"HE",u.faction))
        if c.ground_suppression>20:u.suppression=clamp(u.suppression+c.ground_suppression*.12,0,100)
        # Breaching into the enemy half of a trench rewards a successful assault with
        # temporary momentum and shocks nearby defenders.
        if c.terrain in ("trench","firing_step"):
            enemy_half=(u.faction=="player" and x>MAP_W*.58) or (u.faction=="enemy" and x<MAP_W*.42)
            if enemy_half:
                u.momentum=clamp(u.momentum+22,0,100)
                for e in self.living("enemy" if u.faction=="player" else "player"):
                    if dist(e,u)<3.2:
                        e.suppression=clamp(e.suppression+10,0,100);e.morale=max(0,e.morale-6)
        # fire damages units standing in it
        if c.fire>0:self.apply_damage(u,8,None,"fire")

    def perform_suppressive_shot(self,u:Unit):
        if u.ammo<=0:self.start_reload(u);return
        if not u.target_pos:return
        u.ammo-=1;u.next_shot=self.time+self.fire_interval(u)*.65;u.heat+=u.weapon["heat"]*1.2;u.signature=55
        tx,ty=u.target_pos
        self.tracers.append(Tracer(u.pos,(tx,ty)))
        cx,cy=int(round(tx)),int(round(ty))
        if self.in_bounds(cx,cy):
            self.grid[cy][cx].ground_suppression=clamp(self.grid[cy][cx].ground_suppression+u.weapon["supp"]*.85,0,100)
            self.degrade_cover((tx,ty),u.weapon["damage"]*.24,u.weapon["pen"])
        for target in self.living("enemy" if u.faction=="player" else "player"):
            if dist(target.pos,(tx,ty))<=2.2:
                target.incoming_bearings.append((angle_to(target,u),self.time))
                cross=self.crossfire_pressure(target)
                gain=u.weapon["supp"]*(.78+cross*.32)
                target.suppression=clamp(target.suppression+gain,0,100)
                target.morale=clamp(target.morale-u.weapon["supp"]*(.09+cross*.05),0,100)

    def update_reaction_fire(self):
        for shooter in self.living():
            if not shooter.combat_effective or shooter.jammed or shooter.reload_timer>0 or self.time<shooter.next_shot:continue
            if not (shooter.overwatch or shooter.fire_lane):continue
            enemies=self.living("enemy" if shooter.faction=="player" else "player")
            valid=[]
            for t in enemies:
                if not t.combat_effective:continue
                if not (t.order=="move" or t.signature>6):continue
                d=dist(shooter,t)
                if d>shooter.arc_range:continue
                if angle_diff(shooter.fire_lane_center,angle_to(shooter,t))>shooter.arc_width/2:continue
                if not self.can_see(shooter,t):continue
                valid.append((d,t))
            if valid:
                _,target=min(valid,key=lambda z:z[0])
                if shooter.reaction_target_uid!=target.uid:
                    shooter.reaction_target_uid=target.uid
                    shooter.reaction_ready_at=self.time+self.reaction_delay(shooter,target)
                    shooter.traverse_ready_at=max(shooter.traverse_ready_at,self.time+self.traverse_delay(shooter,target))
                    continue
                if self.time<shooter.reaction_ready_at or self.time<shooter.traverse_ready_at:continue
                old=shooter.fire_mode;shooter.fire_mode="rapid" if shooter.fire_lane else "snap"
                self.perform_shot(shooter,target,reaction=True)
                shooter.fire_mode=old
                shooter.reaction_ready_at=self.time+self.reaction_delay(shooter,target)*.55

    def update_explosions(self,dt):
        for e in list(self.explosions):
            e.timer-=dt
            if e.timer<=0:
                self.resolve_explosion(e);self.explosions.remove(e)

    def update_cohesion_and_morale(self,dt):
        for u in self.living():
            allies=[a for a in self.living(u.faction) if a.uid!=u.uid and a.combat_effective]
            near=sum(1 for a in allies if dist(a,u)<=5)
            ux,uy=u.tile
            junction=0
            if self.grid[uy][ux].terrain=="trench":
                junction=sum(1 for nx,ny in ((ux+1,uy),(ux-1,uy),(ux,uy+1),(ux,uy-1)) if self.in_bounds(nx,ny) and self.grid[ny][nx].terrain=="trench")
            target=clamp(35+near*16+(12 if junction>=3 else 0),20,100)
            u.cohesion += (target-u.cohesion)*dt*.12
            if u.suppression<20 and u.cohesion>60:u.morale=clamp(u.morale+dt*.8,0,100)

    def handle_break(self,u:Unit):
        enemies=self.living("enemy" if u.faction=="player" else "player")
        nearest=min((dist(u,e) for e in enemies),default=99)
        allies=sum(1 for a in self.living(u.faction) if a.uid!=u.uid and dist(a,u)<5 and a.combat_effective)
        if nearest<4 and allies==0 and u.morale<12:
            u.casualty="surrendered";u.order="surrender";u.path=[];u.waypoints=[]
            self.add_log(f"{u.faction} {u.role} surrendered.")
            for ally in self.living(u.faction):
                if ally.uid!=u.uid and dist(ally,u)<6:
                    ally.morale=max(0,ally.morale-10);ally.suppression=clamp(ally.suppression+6,0,100)
            return
        # rout toward own map edge with safer pathing
        rx,ry=self.rally_points.get(u.faction,(1 if u.faction=="player" else MAP_W-2,int(clamp(round(u.y),1,MAP_H-2))))
        y=int(clamp(round((ry+u.y)/2),1,MAP_H-2));x=rx
        u.move_mode="safe";u.waypoints=[(x,y)];u.path=[];u.order="rout";u.stance="standing"

    def choose_auto_target(self,u:Unit):
        enemies=[e for e in self.living("enemy" if u.faction=="player" else "player") if e.combat_effective and self.visible_to(u.faction,e) and self.can_see(u,e) and dist(u,e)<=u.weapon["range"]]
        if not enemies:return None
        if u.target_priority=="nearest":return min(enemies,key=lambda e:dist(u,e))
        if u.target_priority=="exposed":return min(enemies,key=lambda e:(self.effective_cover(u,e),dist(u,e)))
        if u.target_priority=="suppressed":return max(enemies,key=lambda e:(e.suppression,-dist(u,e)))
        return min(enemies,key=lambda e:(0 if e.role in ("Machine Gunner","HMG Crew","Sniper","Medic","Mortar Team") else 1,dist(u,e)))

    def find_nearby_cover(self,u:Unit,radius=4) -> Optional[Coord]:
        ux,uy=u.tile;best=None;best_score=-999
        for y in range(max(0,uy-radius),min(MAP_H,uy+radius+1)):
            for x in range(max(0,ux-radius),min(MAP_W,ux+radius+1)):
                if not self.passable(x,y,u):continue
                d=math.hypot(x-ux,y-uy);c=self.grid[y][x]
                score=TERRAIN[c.terrain]["cover"]*2.2 - self.tile_threat(u.faction,x,y)*2.4 - d*.45 - c.ground_suppression*.03
                if score>best_score and TERRAIN[c.terrain]["cover"]>=1:
                    best_score=score;best=(x,y)
        return best

    def update_auto_behaviors(self):
        # Conservative autonomy: react to emergencies, but never override explicit
        # player fire/movement orders unless the soldier is pinned.
        for u in self.living("player"):
            if not u.combat_effective:continue
            if u.auto_medic and u.role=="Medic" and u.med_supplies>0 and u.order=="idle":
                wounded=[a for a in self.living("player") if a.uid!=u.uid and a.casualty in ("wounded","incapacitated") and dist(a,u)<=1.5]
                if wounded:self.medic_action(u,min(wounded,key=lambda a:a.hp));continue
            if u.auto_smoke and u.smoke_grenades>0 and u.suppression>78 and u.order in ("idle","overwatch","fire_lane"):
                if self.grid[u.tile[1]][u.tile[0]].smoke<1.0:
                    self.throw_grenade(u,u.pos,smoke=True);continue
            if u.auto_cover and u.suppression>84 and u.order in ("idle","overwatch","fire_lane","fire"):
                dest=self.find_nearby_cover(u,3)
                if dest and dest!=u.tile:self.issue_move([u],dest,mode="safe",formation="column")

    def update_autofire(self):
        for u in self.living("player"):
            if not u.combat_effective or u.order not in ("idle","overwatch") or u.jammed or u.reload_timer>0 or self.time<u.next_shot:continue
            if u.fire_discipline=="hold":continue
            t=None
            if u.fire_discipline=="return" and u.under_fire_until>self.time and u.last_attacker_uid:
                cand=self.get_unit(u.last_attacker_uid)
                if cand and cand.combat_effective and self.visible_to("player",cand) and self.can_see(u,cand):t=cand
            elif u.fire_discipline in ("free","confident"):
                t=self.choose_auto_target(u)
            if t:
                if u.fire_discipline=="confident" and self.hit_chance(u,t)<60:continue
                self.perform_shot(u,t,reaction=True)

    def bounding_advance(self, units: List[Unit], dest: Coord):
        us=[u for u in units if u.combat_effective]
        if len(us)<2:
            self.issue_move(us,dest,mode="safe");return
        a=[u.uid for i,u in enumerate(us) if i%2==0];b=[u.uid for i,u in enumerate(us) if i%2==1]
        self.bounding_orders.append(BoundingOrder(a,b,dest,0,0))
        self.add_log("Bounding overwatch advance started.")

    def update_bounding_orders(self,dt):
        for bo in list(self.bounding_orders):
            bo.timer+=dt
            A=[self.get_unit(i) for i in bo.a];B=[self.get_unit(i) for i in bo.b]
            A=[u for u in A if u and u.combat_effective];B=[u for u in B if u and u.combat_effective]
            if not A and not B:self.bounding_orders.remove(bo);continue
            if bo.phase==0:
                sx=sum(u.x for u in A+B)/max(1,len(A+B));sy=sum(u.y for u in A+B)/max(1,len(A+B))
                mid=(int(round((sx+bo.dest[0])/2)),int(round((sy+bo.dest[1])/2)))
                self.issue_move(A,mid,mode="safe",formation="line")
                for u in B:self.set_overwatch(u,angle_to(u,bo.dest),100)
                bo.phase=1;bo.timer=0
            elif bo.phase==1 and (bo.timer>5 or all(u.order=="idle" for u in A)):
                self.issue_move(B,bo.dest,mode="safe",formation="line")
                for u in A:self.set_overwatch(u,angle_to(u,bo.dest),100)
                bo.phase=2;bo.timer=0
            elif bo.phase==2 and (bo.timer>6 or all(u.order=="idle" for u in B)):
                self.issue_move(A,bo.dest,mode="safe",formation="line")
                bo.phase=3;bo.timer=0
            elif bo.phase==3 and (bo.timer>6 or all(dist(u.pos,bo.dest)<3 for u in A+B)):
                for u in A+B:
                    if u.order=="idle":self.set_overwatch(u,angle_to(u,bo.dest),120)
                self.bounding_orders.remove(bo)

    # ------------------------------------------------------------------- AI
    def update_ai(self,dt):
        delay=DIFFICULTY[self.difficulty]["ai"]
        for u in self.living("enemy"):
            if not u.combat_effective or u.order in ("rout","medic","deploy","pack","barrel","clear_jam") or u.action_timer>0:continue
            if self.time-u.last_ai<delay:continue
            u.last_ai=self.time+self.rng.uniform(0,.15)
            self.ai_decide(u)

    def ai_decide(self,u:Unit):
        # maintain weapons first
        if u.jammed:self.clear_jam(u);return
        if u.ammo<=0 and u.magazines:self.start_reload(u);return
        if u.heat>88 and u.barrel_spares>0 and u.role in ("Machine Gunner","HMG Crew"):self.change_barrel(u);return
        # A compromised defensive position should not be held to the last pixel.
        cross=self.crossfire_pressure(u)
        if (u.suppression>74 or u.morale<34 or cross>.55) and u.order not in ("rout","move"):
            if u.auto_smoke and u.smoke_grenades>0 and self.grid[u.tile[1]][u.tile[0]].smoke<1.0 and (self.difficulty=="Veteran" or u.suppression>84):
                self.throw_grenade(u,u.pos,smoke=True);return
            dest=self.find_nearby_cover(u,5)
            if dest and (dest!=u.tile):
                if u.deployed and u.role in ("Machine Gunner","HMG Crew"):self.toggle_deploy(u);return
                self.issue_move([u],dest,mode="safe",formation="column");return
        # medic behaviour
        if u.role=="Medic" and u.med_supplies>0:
            wounded=[a for a in self.living("enemy") if a.uid!=u.uid and a.casualty in ("wounded","incapacitated")]
            if wounded:
                t=min(wounded,key=lambda a:dist(u,a))
                if dist(u,t)<=1.5:self.medic_action(u,t);return
                if dist(u,t)<7:self.issue_move([u],t.tile,mode="safe");return
        visible=[p for p in self.living("player") if p.combat_effective and self.can_see(u,p)]
        if visible:
            target=min(visible,key=lambda p:(0 if p.role in ("Machine Gunner","Sniper","Medic") else 1,dist(u,p)))
            d=dist(u,target)
            # smoke if badly suppressed
            if u.smoke_grenades>0 and u.suppression>60 and d<6:
                self.throw_grenade(u,u.pos,smoke=True);return
            # grenades in CQB/cover
            if u.grenades>0 and d<4.2 and self.effective_cover(u,target)>=2:
                self.throw_grenade(u,target.pos,cook=.7);return
            if u.rifle_grenades>0 and 4<d<7:self.throw_grenade(u,target.pos,rifle=True);return
            # Local counterattack only against an overextended, already-shaken attacker.
            nearby_target_allies=sum(1 for a in self.living("player") if a.uid!=target.uid and a.combat_effective and dist(a,target)<4)
            if u.role in ("Assault","Rifleman") and target.x>MAP_W-13 and target.suppression>55 and nearby_target_allies<=1 and d<5:
                nx=int(clamp(round(target.x+1.5),1,MAP_W-2));ny=int(clamp(round(target.y),1,MAP_H-2))
                if self.passable(nx,ny,u):self.issue_move([u],(nx,ny),mode="safe",formation="column");return
            # MG/HMG deploy + fire lane/suppression
            if u.role in ("Machine Gunner","HMG Crew"):
                if not u.deployed:self.toggle_deploy(u);return
                if target.suppression<60:self.suppress_area(u,target.pos);return
            if u.role=="Sniper":self.issue_fire(u,target,"aimed");return
            if u.role=="Assault" and d<3:self.issue_fire(u,target,"rapid");return
            if d<=u.weapon["range"]:
                mode="aimed" if d>7 and u.suppression<35 else "normal"
                self.issue_fire(u,target,mode);return
        # no visible target: use overwatch or maneuver/flank
        contacts=self.known_contacts("enemy",memory=9.0)
        if contacts:
            _,info,_=min(contacts,key=lambda z:math.hypot(u.x-z[1]["pos"][0],u.y-z[1]["pos"][1]))
            tx,ty=info["pos"]
            # Flank the last-known position; never track a hidden player's live coordinates.
            dx=tx-u.x;dy=ty-u.y
            side=self.rng.choice([-1,1]);length=max(1,math.hypot(dx,dy))
            fx=int(clamp(tx + side*(-dy/length)*4,1,MAP_W-2));fy=int(clamp(ty + side*(dx/length)*4,1,MAP_H-2))
            if self.rng.random()<.55:self.issue_move([u],(fx,fy),mode="safe")
            else:self.set_overwatch(u,angle_to(u,(tx,ty)),90)
        else:
            # Defensive weapons cover sectors, but reposition if their current nest is
            # badly degraded rather than behaving like immovable turrets.
            c=self.grid[u.tile[1]][u.tile[0]]
            if u.role in ("Machine Gunner","HMG Crew") and c.cover_wear>.65:
                if u.deployed:self.toggle_deploy(u)
                else:
                    dest=self.find_nearby_cover(u,5)
                    if dest:self.issue_move([u],dest,mode="safe",formation="column")
                return
            if u.role in ("Machine Gunner","HMG Crew") and u.deployed:self.set_fire_lane(u,180,60)
            else:self.set_overwatch(u,180,120)

    def toggle_door(self, u: Unit, pos: Coord):
        if dist(u.pos, pos) > 1.6:
            return
        x, y = pos
        c = self.grid[y][x]
        if c.terrain != "door":
            return
        c.door_open = not c.door_open
        u.action_timer = .55
        self.add_log(f"{u.role} {'opened' if c.door_open else 'closed'} a door.")

    def coordinated_advance(self, units: List[Unit], dest: Coord):
        """MG/automatic weapons cover while maneuver elements advance."""
        if not units:
            return
        coverers = [u for u in units if u.role in ("Machine Gunner", "HMG Crew", "Automatic Rifleman") and u.combat_effective]
        movers = [u for u in units if u not in coverers and u.combat_effective]
        for u in coverers:
            if u.role in ("Machine Gunner", "HMG Crew") and not u.deployed:
                self.toggle_deploy(u)
            u.covering_uid = movers[0].uid if movers else None
            self.suppress_area(u, dest)
        if movers:
            self.issue_move(movers, dest, mode="safe", formation="wedge")
            for m in movers:
                m.momentum = clamp(m.momentum + 10, 0, 100)
        self.add_log("Coordinated covering advance ordered.")

    # ----------------------------------------------------------- convenience
    def cycle_stance(self,u:Unit):
        order=["standing","crouched","prone"];u.stance=order[(order.index(u.stance)+1)%3]

    def cycle_move_mode(self,u:Unit):
        modes=["fast","safe","manual"];u.move_mode=modes[(modes.index(u.move_mode)+1)%3]

    def check_end(self):
        p=[u for u in self.living("player") if u.combat_effective]
        e=[u for u in self.living("enemy") if u.combat_effective]
        if not e:self.victory=True
        if not p:self.defeat=True


# =============================================================================
# PYGAME FRONT END
# =============================================================================

class KillZoneApp:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption(APP_TITLE)
        self.display_mode="windowed"  # windowed / borderless / exclusive
        self.last_fullscreen_mode="borderless"
        self.fullscreen=False
        self.window=None
        # All UI/game drawing happens at a stable logical resolution.  The
        # finished frame is scaled to the actual window/desktop in present().
        # This avoids the top-left 1448x790 image seen when SDL rejects
        # SCALED+FULLSCREEN and Pygame falls back to an unscaled desktop mode.
        self.screen=pygame.Surface((WINDOW_W,WINDOW_H))
        self.apply_display_mode()
        self.clock=pygame.time.Clock()
        self.fonts={s:pygame.font.SysFont("consolas",s,bold=(s>=20)) for s in (12,14,16,20,26,36,48,60)}
        bootstrap_assets_async()
        self.game=RealTimeGame()
        self.state="menu"  # menu / setup / settings / help / game
        self.battle_active=False
        self.setup_difficulty="Hard"
        self.setup_roster={role:DEFAULT_PLAYER_ROSTER.count(role) for role in PLAYER_ROLE_ORDER}
        self.battle_roster=list(DEFAULT_PLAYER_ROSTER)
        self.menu_speed=1.0
        self.menu_show_help=True
        self.show_fps=False
        self.selected:List[int]=[]
        self.drag_start:Optional[Tuple[int,int]]=None
        self.drag_additive=False
        self.mouse=(0,0)
        self.running=True
        self.accum=0.0
        self.speed=1.0
        self.command_mode="normal"
        self.cook=0.0
        self.show_threat=False
        self.show_help=True
        self.formation="wedge"
        self.control_groups={i:[] for i in range(1,10)}
        self.audio_enabled=True
        self.audio=None
        self.blood_sprite=None
        self.asset_refresh_at=0.0
        self.message="LMB select • RMB order • ` tactical slow • F1 help"
        self.init_presentation_assets()

    def desktop_size(self):
        try:
            info=pygame.display.Info()
            w=int(getattr(info,"current_w",0) or 0);h=int(getattr(info,"current_h",0) or 0)
            if w>0 and h>0:return w,h
        except Exception:
            pass
        return WINDOW_W,WINDOW_H

    def apply_display_mode(self):
        mode=getattr(self,"display_mode","windowed")
        try:
            if mode=="borderless":
                # Borderless desktop window: native desktop dimensions, no decorations.
                size=self.desktop_size()
                self.window=pygame.display.set_mode(size,getattr(pygame,"NOFRAME",0))
            elif mode=="exclusive":
                # Exclusive fullscreen at the desktop/native mode.  (0,0) asks SDL
                # for the current display resolution instead of the logical canvas size.
                self.window=pygame.display.set_mode((0,0),pygame.FULLSCREEN)
            else:
                self.display_mode="windowed"
                self.window=pygame.display.set_mode((WINDOW_W,WINDOW_H))
        except pygame.error:
            # A driver can reject exclusive/borderless modes.  Always recover to
            # a normal window instead of leaving the game in a broken display state.
            self.display_mode="windowed"
            self.window=pygame.display.set_mode((WINDOW_W,WINDOW_H))
        self.fullscreen=self.display_mode!="windowed"
        if self.fullscreen:self.last_fullscreen_mode=self.display_mode

    def set_display_mode(self,mode):
        if mode not in ("windowed","borderless","exclusive"):return
        self.display_mode=mode
        self.apply_display_mode()

    def cycle_display_mode(self):
        modes=["windowed","borderless","exclusive"]
        self.set_display_mode(modes[(modes.index(self.display_mode)+1)%len(modes)])

    def toggle_fullscreen(self):
        # F11 is a quick toggle.  It returns to whichever fullscreen flavour
        # the player most recently selected in Settings.
        if self.display_mode=="windowed":self.set_display_mode(self.last_fullscreen_mode)
        else:self.set_display_mode("windowed")

    def display_to_logical(self,pos):
        if not self.window:return (int(pos[0]),int(pos[1]))
        try:w,h=self.window.get_size()
        except Exception:w,h=WINDOW_W,WINDOW_H
        if w<=0 or h<=0:return (int(pos[0]),int(pos[1]))
        return (int(clamp(pos[0]*WINDOW_W/w,0,WINDOW_W-1)),int(clamp(pos[1]*WINDOW_H/h,0,WINDOW_H-1)))

    def normalize_event_pos(self,e):
        if hasattr(e,"pos"):
            pos=self.display_to_logical(e.pos)
            try:e.pos=pos
            except Exception:
                try:e.dict["pos"]=pos
                except Exception:pass
        return e

    def present(self):
        if self.window is None:return
        try:size=self.window.get_size()
        except Exception:size=(WINDOW_W,WINDOW_H)
        if size==(WINDOW_W,WINDOW_H):
            self.window.blit(self.screen,(0,0))
        else:
            # Scale directly into the display surface to avoid allocating a new
            # full-screen Surface every frame.  Filling the complete destination
            # removes the unused right/bottom bands from the old fullscreen path.
            pygame.transform.scale(self.screen,size,self.window)
        pygame.display.flip()

    def current_setup_roster(self) -> List[str]:
        roster=[]
        for role in PLAYER_ROLE_ORDER:
            roster.extend([role]*self.setup_roster.get(role,0))
        return roster[:MAX_PLAYER_UNITS]

    def init_presentation_assets(self):
        try:
            if not pygame.mixer.get_init():pygame.mixer.init()
        except Exception:
            self.audio_enabled=False
        self.audio={}
        self.refresh_assets()

    def refresh_assets(self):
        if self.audio_enabled:
            for name in ("rifle_556.mp3","rifle_762.mp3","smg_9mm.mp3","explosion1.ogg","explosion2.ogg","hurt_01.mp3","hurt_03.mp3","scream_horror1.mp3"):
                path=AUDIO_DIR/name
                if path.exists() and name not in self.audio:
                    try:self.audio[name]=pygame.mixer.Sound(str(path))
                    except Exception:pass
        b=FX_DIR/"blood_red.png"
        if b.exists() and self.blood_sprite is None:
            try:self.blood_sprite=pygame.image.load(str(b)).convert_alpha()
            except Exception:pass

    def play_event(self,ev):
        if not self.audio_enabled:return
        typ=ev.get("type")
        names=[];vol=.45
        if typ=="shot":
            w=ev.get("weapon","")
            if w in ("Scoped Rifle","Marksman Rifle","Heavy Machine Gun"):names=["rifle_762.mp3"]
            elif w in ("SMG",):names=["smg_9mm.mp3"]
            else:names=["rifle_556.mp3"]
            vol=.30 if w not in ("Heavy Machine Gun",) else .38
        elif typ=="explosion":names=["explosion1.ogg","explosion2.ogg"];vol=.60
        elif typ=="hurt":
            if ev.get("damage",0)<20:return
            names=["hurt_01.mp3","hurt_03.mp3"];vol=.24
        elif typ=="death":names=["scream_horror1.mp3","hurt_03.mp3"];vol=.22
        avail=[n for n in names if n in self.audio]
        if avail:
            snd=self.audio[random.choice(avail)];snd.set_volume(vol);snd.play()

    def get_font(self,size):
        # UI panels use a few in-between sizes (e.g. 13/18). Build fonts lazily
        # instead of assuming every requested size was pre-cached at startup.
        if size not in self.fonts:
            self.fonts[size]=pygame.font.SysFont("consolas",size,bold=(size>=20))
        return self.fonts[size]

    def text(self,s,pos,size=14,color="text"):
        surf=self.get_font(size).render(str(s),True,COLORS[color] if isinstance(color,str) else color)
        self.screen.blit(surf,pos)

    def button(self, rect, label, mouse=None, enabled=True, accent=False):
        hover=bool(mouse and rect.collidepoint(mouse))
        fill=COLORS["panel2"] if hover and enabled else COLORS["panel"]
        if accent and enabled:
            fill=(68,76,58) if not hover else (82,92,69)
        if not enabled:
            fill=(36,39,35)
        pygame.draw.rect(self.screen,fill,rect,border_radius=4)
        pygame.draw.rect(self.screen,COLORS["select"] if hover and enabled else COLORS["muted"],rect,2,border_radius=4)
        surf=self.fonts[20].render(label,True,COLORS["white"] if enabled else COLORS["muted"])
        self.screen.blit(surf,(rect.centerx-surf.get_width()//2,rect.centery-surf.get_height()//2))

    def main_menu_rects(self):
        w,h=300,54
        x=WINDOW_W//2-w//2
        y=292
        rects={}
        if self.battle_active:
            rects["continue"]=pygame.Rect(x,y,w,h);y+=64
        rects["play"]=pygame.Rect(x,y,w,h);y+=64
        rects["settings"]=pygame.Rect(x,y,w,h);y+=64
        rects["help"]=pygame.Rect(x,y,w,h);y+=64
        rects["quit"]=pygame.Rect(x,y,w,h)
        return rects

    def setup_rects(self):
        x=WINDOW_W//2-330
        return {
            "easy":pygame.Rect(x,170,200,48),
            "hard":pygame.Rect(x+230,170,200,48),
            "veteran":pygame.Rect(x+460,170,200,48),
            "balanced":pygame.Rect(WINDOW_W//2-310,650,190,44),
            "clear":pygame.Rect(WINDOW_W//2-95,650,190,44),
            "start":pygame.Rect(WINDOW_W//2+120,650,190,44),
            "back":pygame.Rect(WINDOW_W//2-95,708,190,42),
        }

    def roster_rects(self):
        rects={}
        left=84;right=WINDOW_W//2+30;top=282;row_h=55
        for i,role in enumerate(PLAYER_ROLE_ORDER):
            col=0 if i<6 else 1;row=i if i<6 else i-6
            x=left if col==0 else right;y=top+row*row_h
            rects[(role,"minus")]=pygame.Rect(x+440,y+6,36,34)
            rects[(role,"plus")]=pygame.Rect(x+526,y+6,36,34)
        return rects

    def settings_rects(self):
        x=WINDOW_W//2-330
        return {
            "speed05":pygame.Rect(x,275,200,48),
            "speed1":pygame.Rect(x+230,275,200,48),
            "speed2":pygame.Rect(x+460,275,200,48),
            "help":pygame.Rect(WINDOW_W//2-165,365,330,46),
            "audio":pygame.Rect(WINDOW_W//2-165,423,330,46),
            "fps":pygame.Rect(WINDOW_W//2-165,481,330,46),
            "fullscreen":pygame.Rect(WINDOW_W//2-165,539,330,46),
            "back":pygame.Rect(WINDOW_W//2-150,620,300,48),
        }

    def help_menu_rects(self):
        return {"back":pygame.Rect(WINDOW_W//2-150,710,300,46)}

    def start_battle(self):
        roster=self.current_setup_roster()
        if not roster:
            self.message="Choose at least one unit before starting."
            return
        self.battle_roster=list(roster)
        self.game=RealTimeGame(difficulty=self.setup_difficulty,player_roster=roster)
        self.selected=[]
        self.command_mode="normal"
        self.cook=0.0
        self.show_threat=False
        self.show_help=self.menu_show_help
        self.speed=self.menu_speed
        self.control_groups={i:[] for i in range(1,10)}
        self.battle_active=True
        self.state="game"

    def handle_menu_event(self,e):
        if e.type==pygame.QUIT:
            self.running=False;return
        if e.type==pygame.KEYDOWN:
            if e.key==pygame.K_RETURN:
                self.state="setup"
            elif e.key==pygame.K_ESCAPE:
                return  # main-menu Escape is intentionally a no-op; use the Quit button
            return
        if e.type!=pygame.MOUSEBUTTONDOWN or e.button!=1:return
        for name,r in self.main_menu_rects().items():
            if not r.collidepoint(e.pos):continue
            if name=="continue":
                self.state="game"
            elif name=="play":
                self.state="setup"
            elif name=="settings":
                self.state="settings"
            elif name=="help":
                self.state="help"
            elif name=="quit":
                self.running=False
            return

    def handle_setup_event(self,e):
        if e.type==pygame.QUIT:
            self.running=False;return
        if e.type==pygame.KEYDOWN and e.key==pygame.K_ESCAPE:
            self.state="menu";return
        if e.type!=pygame.MOUSEBUTTONDOWN or e.button!=1:return
        total=sum(self.setup_roster.values())
        for (role,action),r in self.roster_rects().items():
            if not r.collidepoint(e.pos):continue
            count=self.setup_roster.get(role,0)
            if action=="minus" and count>0:self.setup_roster[role]=count-1
            elif action=="plus" and count<MAX_ROLE_COUNT and total<MAX_PLAYER_UNITS:self.setup_roster[role]=count+1
            return
        for name,r in self.setup_rects().items():
            if not r.collidepoint(e.pos):continue
            if name in ("easy","hard","veteran"):
                self.setup_difficulty=name.title()
            elif name=="balanced":
                self.setup_roster={role:DEFAULT_PLAYER_ROSTER.count(role) for role in PLAYER_ROLE_ORDER}
            elif name=="clear":
                self.setup_roster={role:0 for role in PLAYER_ROLE_ORDER}
            elif name=="start":
                self.start_battle()
            elif name=="back":
                self.state="menu"
            return

    def handle_settings_event(self,e):
        if e.type==pygame.QUIT:
            self.running=False;return
        if e.type==pygame.KEYDOWN and e.key==pygame.K_ESCAPE:
            self.state="menu";return
        if e.type!=pygame.MOUSEBUTTONDOWN or e.button!=1:return
        for name,r in self.settings_rects().items():
            if not r.collidepoint(e.pos):continue
            if name=="speed05":self.menu_speed=.5
            elif name=="speed1":self.menu_speed=1.0
            elif name=="speed2":self.menu_speed=2.0
            elif name=="help":self.menu_show_help=not self.menu_show_help
            elif name=="audio":self.audio_enabled=not self.audio_enabled
            elif name=="fps":self.show_fps=not self.show_fps
            elif name=="fullscreen":self.toggle_fullscreen()
            elif name=="back":self.state="menu"
            return

    def handle_help_menu_event(self,e):
        if e.type==pygame.QUIT:
            self.running=False;return
        if e.type==pygame.KEYDOWN and e.key in (pygame.K_ESCAPE,pygame.K_F1):
            self.state="menu";return
        if e.type==pygame.MOUSEBUTTONDOWN and e.button==1 and self.help_menu_rects()["back"].collidepoint(e.pos):
            self.state="menu"

    def map_cell_from_mouse(self,pos) -> Optional[Coord]:
        mx,my=pos
        x=(mx-MAP_X)//TILE;y=(my-MAP_Y)//TILE
        if 0<=x<MAP_W and 0<=y<MAP_H:return int(x),int(y)
        return None

    def unit_at_pixel(self,pos) -> Optional[Unit]:
        cell=self.map_cell_from_mouse(pos)
        if not cell:return None
        return self.game.unit_at(*cell)

    def selected_units(self) -> List[Unit]:
        out=[]
        for uid in self.selected:
            u=self.game.get_unit(uid)
            if u and u.faction=="player" and u.alive:out.append(u)
        return out

    def select(self,u:Optional[Unit],add=False):
        if not add:self.selected=[]
        if u and u.faction=="player":
            if u.uid in self.selected and add:self.selected.remove(u.uid)
            elif u.uid not in self.selected:self.selected.append(u.uid)

    def issue_context_command(self,cell:Coord,append=False):
        units=self.selected_units()
        if not units:return
        target=self.game.unit_at(*cell)
        if target and target.faction=="player":
            mods=pygame.key.get_mods()
            for u in units:
                if u.uid==target.uid: continue
                if mods & pygame.KMOD_CTRL:
                    self.game.share_ammo(u,target)
                elif (mods & pygame.KMOD_ALT) and target.casualty=="incapacitated":
                    self.game.carry_toggle(u,target)
                elif u.role=="Medic" and target.casualty in ("wounded","incapacitated"):
                    self.game.medic_action(u,target)
                elif target.casualty=="incapacitated":
                    self.game.drag_toggle(u,target)
            return
        if target and target.faction=="enemy" and self.game.visible_to("player",target):
            for u in units:
                ux,uy=u.tile;tx,ty=target.tile
                if append:
                    self.game.queue_fire(u,target.uid,u.fire_mode);continue
                if u.bayonet and dist(u,target)<=1.5 and self.game.grid[uy][ux].terrain in ("trench","firing_step") and self.game.grid[ty][tx].terrain in ("trench","firing_step"):
                    self.game.trench_assault(u,target)
                else:
                    self.game.issue_fire(u,target,u.fire_mode)
            return
        if self.command_mode=="grenade":
            for u in units:self.game.throw_grenade(u,cell,cook=self.cook)
            self.command_mode="normal";return
        if self.command_mode=="smoke":
            for u in units:self.game.throw_grenade(u,cell,smoke=True)
            self.command_mode="normal";return
        if self.command_mode=="rifle_grenade":
            for u in units:self.game.throw_grenade(u,cell,rifle=True)
            self.command_mode="normal";return
        if self.command_mode=="satchel":
            for u in units:self.game.place_satchel(u,cell)
            self.command_mode="normal";return
        if self.command_mode=="suppress":
            for u in units:self.game.suppress_area(u,cell)
            self.command_mode="normal";return
        if self.command_mode=="mortar":
            for u in units:self.game.mortar_fire(u,cell,False)
            self.command_mode="normal";return
        if self.command_mode=="mortar_smoke":
            for u in units:self.game.mortar_fire(u,cell,True)
            self.command_mode="normal";return
        if self.command_mode=="support_he":
            self.game.call_support("player",cell,False);self.command_mode="normal";return
        if self.command_mode=="support_smoke":
            self.game.call_support("player",cell,True);self.command_mode="normal";return
        if self.command_mode=="bound":
            self.game.bounding_advance(units,cell);self.command_mode="normal";return
        if self.command_mode.startswith("eng_"):
            kind=self.command_mode.split("_",1)[1]
            for u in units:self.game.engineer_action(u,cell,kind)
            self.command_mode="normal";return
        self.game.issue_move(units,cell,append=append,formation=self.formation)

    def cycle_formation(self):
        fs=["wedge","line","column","spread"];self.formation=fs[(fs.index(self.formation)+1)%len(fs)]

    def cycle_discipline(self,units):
        ds=["hold","return","free","confident"]
        for u in units:u.fire_discipline=ds[(ds.index(u.fire_discipline)+1)%len(ds)]

    def cycle_priority(self,units):
        ps=["nearest","exposed","specialist","suppressed"]
        for u in units:u.target_priority=ps[(ps.index(u.target_priority)+1)%len(ps)]

    def command_bar_rects(self):
        labels=["SUPPRESS","OVERWATCH","GRENADE","SMOKE","RELOAD","STANCE","FORMATION","DISCIPLINE","PRIORITY","BOUND","AUTO"]
        w=104;gap=4;x=MAP_X;y=MAP_Y+MAP_H*TILE+8
        return {lab:pygame.Rect(x+i*(w+gap),y,w,32) for i,lab in enumerate(labels)}

    def handle_command_bar(self,pos):
        us=self.selected_units()
        if not us:return False
        for name,r in self.command_bar_rects().items():
            if not r.collidepoint(pos):continue
            if name=="SUPPRESS":self.command_mode="suppress"
            elif name=="OVERWATCH":
                cell=self.map_cell_from_mouse(self.mouse)
                if cell:
                    for u in us:self.game.set_overwatch(u,angle_to(u,cell),90)
            elif name=="GRENADE":self.command_mode="grenade"
            elif name=="SMOKE":self.command_mode="smoke"
            elif name=="RELOAD":
                for u in us:self.game.start_reload(u)
            elif name=="STANCE":
                for u in us:self.game.cycle_stance(u)
            elif name=="FORMATION":self.cycle_formation()
            elif name=="DISCIPLINE":self.cycle_discipline(us)
            elif name=="PRIORITY":self.cycle_priority(us)
            elif name=="BOUND":self.command_mode="bound"
            elif name=="AUTO":
                enabled=not all(u.auto_reload and u.auto_cover and u.auto_smoke and u.auto_medic for u in us)
                for u in us:
                    u.auto_reload=enabled;u.auto_cover=enabled;u.auto_smoke=enabled;u.auto_medic=enabled
                self.message=f"Selected-unit autonomy {'ON' if enabled else 'OFF'}"
            return True
        return False

    def handle_key(self,key,mods):
        us=self.selected_units()
        if key==pygame.K_ESCAPE:
            self.game.paused=True
            self.state="menu"
            return
        if key==pygame.K_SPACE:self.game.paused=not self.game.paused
        elif key==pygame.K_F1:self.show_help=not self.show_help
        elif key==pygame.K_TAB:self.show_threat=not self.show_threat
        elif pygame.K_1<=key<=pygame.K_9:
            num=key-pygame.K_0
            if mods & pygame.KMOD_CTRL:self.control_groups[num]=[u.uid for u in us]
            else:self.selected=[uid for uid in self.control_groups.get(num,[]) if self.game.get_unit(uid) and self.game.get_unit(uid).alive]
        elif key==pygame.K_MINUS:self.speed=.5
        elif key==pygame.K_EQUALS:self.speed=1.0
        elif key==pygame.K_RIGHTBRACKET:self.speed=2.0
        elif key==pygame.K_F3:self.command_mode="bound"
        elif key==pygame.K_F4:self.cycle_formation()
        elif key==pygame.K_F7:self.cycle_discipline(us)
        elif key==pygame.K_F8:self.cycle_priority(us)
        elif key==pygame.K_F10:
            enabled=not all(u.auto_reload and u.auto_cover and u.auto_smoke and u.auto_medic for u in us) if us else True
            for u in us:u.auto_reload=enabled;u.auto_cover=enabled;u.auto_smoke=enabled;u.auto_medic=enabled
        elif key==pygame.K_z:
            for u in us:self.game.cycle_stance(u)
        elif key==pygame.K_x:
            for u in us:self.game.cycle_move_mode(u)
        elif key==pygame.K_a:
            for u in us:u.fire_mode="aimed";u.order="idle";u.aim_progress=0
        elif key==pygame.K_f:
            for u in us:u.fire_mode="snap"
        elif key==pygame.K_w:
            for u in us:u.fire_mode="rapid"
        elif key==pygame.K_r:
            for u in us:self.game.start_reload(u, emergency=bool(mods & pygame.KMOD_SHIFT))
        elif key==pygame.K_j:
            for u in us:self.game.clear_jam(u)
        elif key==pygame.K_b:
            for u in us:self.game.change_barrel(u)
        elif key==pygame.K_d:
            for u in us:self.game.toggle_deploy(u)
        elif key==pygame.K_v:
            for u in us:self.game.bayonet_toggle(u)
        elif key==pygame.K_p:
            for u in us:self.game.peek(u)
        elif key==pygame.K_g:self.command_mode="grenade";self.cook=0
        elif key==pygame.K_c and (mods & pygame.KMOD_SHIFT):self.cook=min(1.8,self.cook+.6);self.command_mode="grenade"
        elif key==pygame.K_c:
            cell=self.map_cell_from_mouse(self.mouse)
            if cell:self.game.coordinated_advance(us,cell)
        elif key==pygame.K_s:self.command_mode="smoke"
        elif key==pygame.K_l:self.command_mode="rifle_grenade"
        elif key==pygame.K_k:self.command_mode="satchel"
        elif key==pygame.K_q:self.command_mode="suppress"
        elif key==pygame.K_m:self.command_mode="mortar"
        elif key==pygame.K_n:self.command_mode="mortar_smoke"
        elif key==pygame.K_h:self.command_mode="support_he"
        elif key==pygame.K_y:self.command_mode="support_smoke"
        elif key==pygame.K_o:
            cell=self.map_cell_from_mouse(self.mouse)
            if cell:
                for u in us:self.game.set_overwatch(u,angle_to(u,cell),90)
        elif key==pygame.K_i:
            cell=self.map_cell_from_mouse(self.mouse)
            if cell:
                for u in us:self.game.set_fire_lane(u,angle_to(u,cell),45)
        elif key==pygame.K_e:
            if mods & pygame.KMOD_SHIFT:
                for u in us:self.game.scan_mines(u)
            else:
                # engineer contextual action: cut wire, clear mine, otherwise build sandbags.
                cell=self.map_cell_from_mouse(self.mouse)
                if cell:
                    c=self.game.grid[cell[1]][cell[0]]
                    kind="cut" if c.terrain=="wire" else "clear_mine" if c.mine else "fortify"
                    for u in us:self.game.engineer_action(u,cell,kind)
        elif key==pygame.K_t:
            cell=self.map_cell_from_mouse(self.mouse)
            if cell:
                for u in us:self.game.engineer_action(u,cell,"trench")
        elif key==pygame.K_u:
            cell=self.map_cell_from_mouse(self.mouse)
            if cell:
                for u in us:self.game.engineer_action(u,cell,"bangalore")
        elif key in (pygame.K_RETURN, pygame.K_KP_ENTER):
            cell=self.map_cell_from_mouse(self.mouse)
            if cell:
                for u in us:self.game.toggle_door(u,cell)
        elif key==pygame.K_F9:
            cell=self.map_cell_from_mouse(self.mouse)
            if cell:
                t=self.game.unit_at(*cell)
                if t and t.faction=="player":
                    for u in us:
                        if u.uid!=t.uid:self.game.share_ammo(u,t)
        elif key==pygame.K_4:
            cell=self.map_cell_from_mouse(self.mouse)
            if cell:
                for u in us:self.game.engineer_action(u,cell,"wire")
        elif key==pygame.K_F5:
            self.game=RealTimeGame(difficulty=self.game.difficulty,player_roster=self.battle_roster);self.selected=[]
        elif key==pygame.K_F6:
            ds=["Easy","Hard","Veteran"];d=ds[(ds.index(self.game.difficulty)+1)%3]
            self.game=RealTimeGame(difficulty=d,player_roster=self.battle_roster);self.selected=[]
        elif key==pygame.K_BACKSPACE:
            for u in us:u.order="idle";u.path=[];u.waypoints=[];u.target_uid=None

    def handle_event(self,e):
        # Keep menu hover state live too; previously mouse motion was only recorded in battle.
        if e.type==pygame.MOUSEMOTION:self.mouse=e.pos
        if e.type==pygame.KEYDOWN and e.key==pygame.K_F11:
            self.toggle_fullscreen();return
        if self.state=="menu":
            self.handle_menu_event(e);return
        if self.state=="setup":
            self.handle_setup_event(e);return
        if self.state=="settings":
            self.handle_settings_event(e);return
        if self.state=="help":
            self.handle_help_menu_event(e);return
        if e.type==pygame.QUIT:self.running=False
        elif e.type==pygame.MOUSEBUTTONDOWN:
            if e.button==1:
                if self.handle_command_bar(e.pos):return
                if self.map_cell_from_mouse(e.pos) is not None:
                    self.drag_start=e.pos
                    self.drag_additive=bool(pygame.key.get_mods() & pygame.KMOD_SHIFT)
                    u=self.unit_at_pixel(e.pos)
                    if u:self.select(u,self.drag_additive)
                    elif not self.drag_additive:self.selected=[]
            elif e.button==3:
                cell=self.map_cell_from_mouse(e.pos)
                if cell:self.issue_context_command(cell,pygame.key.get_mods() & pygame.KMOD_SHIFT)
        elif e.type==pygame.MOUSEBUTTONUP and e.button==1:
            if self.drag_start and max(abs(e.pos[0]-self.drag_start[0]),abs(e.pos[1]-self.drag_start[1]))>8:
                map_rect=pygame.Rect(MAP_X,MAP_Y,MAP_W*TILE,MAP_H*TILE)
                sx,sy=self.drag_start;ex,ey=e.pos
                sx=int(clamp(sx,map_rect.left,map_rect.right));ex=int(clamp(ex,map_rect.left,map_rect.right))
                sy=int(clamp(sy,map_rect.top,map_rect.bottom));ey=int(clamp(ey,map_rect.top,map_rect.bottom))
                x1,x2=sorted((sx,ex));y1,y2=sorted((sy,ey))
                if not self.drag_additive:self.selected=[]
                for u in self.game.living("player"):
                    px=MAP_X+u.x*TILE+TILE/2;py=MAP_Y+u.y*TILE+TILE/2
                    if x1<=px<=x2 and y1<=py<=y2 and u.uid not in self.selected:self.selected.append(u.uid)
            self.drag_start=None;self.drag_additive=False
        elif e.type==pygame.KEYDOWN:self.handle_key(e.key,e.mod)

    # ---------------------------------------------------------------- drawing
    def draw(self):
        self.screen.fill(COLORS["bg"])
        if self.state=="menu":
            self.draw_main_menu()
        elif self.state=="setup":
            self.draw_setup()
        elif self.state=="settings":
            self.draw_settings()
        elif self.state=="help":
            self.draw_help_menu()
        else:
            self.draw_topbar();self.draw_map();self.draw_sidebar();self.draw_command_bar()
            if self.show_help:self.draw_help()
        self.present()

    def draw_menu_background(self):
        self.screen.fill((22,25,22))
        # Stylised trench/no-man's-land backdrop made from game primitives.
        horizon=220
        pygame.draw.rect(self.screen,(66,58,45),(0,horizon,WINDOW_W,WINDOW_H-horizon))
        for i in range(18):
            x=(i*97+35)%WINDOW_W;y=horizon+70+(i*43)%420
            pygame.draw.ellipse(self.screen,(52,47,38),(x,y,80,30),2)
        pygame.draw.line(self.screen,(42,36,30),(0,650),(WINDOW_W,610),16)
        pygame.draw.line(self.screen,(42,36,30),(0,690),(WINDOW_W,650),10)
        haze=pygame.Surface((WINDOW_W,WINDOW_H),pygame.SRCALPHA);haze.fill((15,18,15,80));self.screen.blit(haze,(0,0))

    def draw_main_menu(self):
        self.draw_menu_background()
        title=self.fonts[60].render("KILL ZONE",True,COLORS["white"])
        self.screen.blit(title,(WINDOW_W//2-title.get_width()//2,105))
        sub=self.fonts[16].render("REALTIME TACTICAL INFANTRY",True,COLORS["muted"])
        self.screen.blit(sub,(WINDOW_W//2-sub.get_width()//2,182))
        for name,r in self.main_menu_rects().items():
            label={"continue":"CONTINUE","play":"PLAY","settings":"SETTINGS","help":"HELP","quit":"QUIT"}[name]
            self.button(r,label,self.mouse,accent=name in ("continue","play"))
        self.text("F11 fullscreen • Esc is disabled on main menu • Enter opens Play",(18,WINDOW_H-30),12,"muted")
        self.text("Suppression • positioning • trench assaults • combined infantry tactics",(WINDOW_W//2-280,WINDOW_H-44),14,"muted")

    def draw_setup(self):
        self.draw_menu_background()
        title=self.fonts[48].render("SKIRMISH SETUP",True,COLORS["white"])
        self.screen.blit(title,(WINDOW_W//2-title.get_width()//2,62))
        self.text("PROCEDURAL FRONTLINE",(WINDOW_W//2-330,120),20,"white")
        self.text("Choose difficulty and build the force you want to deploy.",(WINDOW_W//2-330,145),14,"muted")
        self.text("DIFFICULTY",(WINDOW_W//2-330,150),14,"muted")
        for name,r in self.setup_rects().items():
            if name in ("easy","hard","veteran"):
                selected=self.setup_difficulty.lower()==name
                self.button(r,("[ "+name.upper()+" ]") if selected else name.upper(),self.mouse,accent=selected)
        desc={
            "Easy":"Smaller enemy force and slower, less accurate reactions.",
            "Hard":"Baseline enemy numbers, reactions and accuracy.",
            "Veteran":"Larger force with faster decisions and better marksmanship.",
        }[self.setup_difficulty]
        self.text(desc,(WINDOW_W//2-330,228),13,"text")
        total=sum(self.setup_roster.values())
        self.text(f"FORCE ROSTER  {total}/{MAX_PLAYER_UNITS}",(84,252),18,"white")
        self.text("Use - / + to choose your deployment. At least one unit is required.",(315,256),12,"muted")
        role_rects=self.roster_rects()
        left=84;right=WINDOW_W//2+30;top=282;row_h=55
        for i,role in enumerate(PLAYER_ROLE_ORDER):
            col=0 if i<6 else 1;row=i if i<6 else i-6
            x=left if col==0 else right;y=top+row*row_h
            panel=pygame.Rect(x,y,580,46);pygame.draw.rect(self.screen,COLORS["panel"],panel,border_radius=4);pygame.draw.rect(self.screen,COLORS["muted"],panel,1,border_radius=4)
            self.text(role,(x+12,y+13),14,"white")
            count=self.setup_roster.get(role,0)
            self.text(str(count),(x+494,y+13),16,"select" if count else "muted")
            self.button(role_rects[(role,"minus")],"-",self.mouse,enabled=count>0)
            self.button(role_rects[(role,"plus")],"+",self.mouse,enabled=(count<MAX_ROLE_COUNT and total<MAX_PLAYER_UNITS))
        rects=self.setup_rects()
        self.button(rects["balanced"],"BALANCED PRESET",self.mouse)
        self.button(rects["clear"],"CLEAR",self.mouse)
        self.button(rects["start"],"START BATTLE",self.mouse,enabled=total>0,accent=total>0)
        self.button(rects["back"],"BACK",self.mouse)
        if total==0:self.text("Select at least one unit.",(WINDOW_W//2-80,695),12,"danger")

    def draw_settings(self):
        self.draw_menu_background()
        title=self.fonts[48].render("SETTINGS",True,COLORS["white"])
        self.screen.blit(title,(WINDOW_W//2-title.get_width()//2,86))
        self.text("DEFAULT SIMULATION SPEED",(WINDOW_W//2-330,235),16,"muted")
        for name,r in self.settings_rects().items():
            if name.startswith("speed"):
                value={"speed05":.5,"speed1":1.0,"speed2":2.0}[name]
                label=f"{value:g}×"
                self.button(r,("[ "+label+" ]") if self.menu_speed==value else label,self.mouse,accent=self.menu_speed==value)
            elif name=="help":self.button(r,f"HELP ON BATTLE START: {'ON' if self.menu_show_help else 'OFF'}",self.mouse,accent=self.menu_show_help)
            elif name=="audio":self.button(r,f"COMBAT AUDIO: {'ON' if self.audio_enabled else 'OFF'}",self.mouse,accent=self.audio_enabled)
            elif name=="fps":self.button(r,f"FPS COUNTER: {'ON' if self.show_fps else 'OFF'}",self.mouse,accent=self.show_fps)
            elif name=="fullscreen":self.button(r,f"FULLSCREEN: {'ON' if self.fullscreen else 'OFF'}  (F11)",self.mouse,accent=self.fullscreen)
            elif name=="back":self.button(r,"BACK",self.mouse)

    def draw_help_menu(self):
        self.draw_menu_background()
        title=self.fonts[48].render("FIELD MANUAL",True,COLORS["white"])
        self.screen.blit(title,(WINDOW_W//2-title.get_width()//2,55))
        left=78;right=WINDOW_W//2+35;top=135
        self.text("CONTROLS",(left,top),20,"select")
        controls=[
            "LMB select; drag a visible box for multiple units.",
            "Shift+LMB / Shift-drag adds to the current selection.",
            "RMB orders movement or attacks; Shift+RMB queues orders.",
            "Hold Left Alt over terrain to inspect cover/exposure.",
            "` tactical slow motion; Space pause; - / = / ] time speed.",
            "Ctrl+1..9 save groups; 1..9 recall them.",
            "F4 formation; F7 fire discipline; F8 target priority.",
            "Tab known-threat overlay; F11 fullscreen.",
            "F1 toggles the in-battle quick-reference overlay.",
        ]
        yy=top+34
        for line in controls:self.text(line,(left,yy),13,"text");yy+=29
        self.text("TACTICAL BASICS",(left,yy+8),20,"select");yy+=42
        for line in [
            "Suppress before crossing open ground.",
            "Smoke blocks spotting and creates assault windows.",
            "Trenches protect across their face, not along their length.",
            "Use MGs for fire lanes; use recon to find defenders first.",
            "Pinned or isolated troops lose effectiveness quickly.",
        ]:self.text("• "+line,(left,yy),13,"muted");yy+=27
        self.text("SPECIALISTS",(right,top),20,"select")
        yy=top+34
        for line in [
            "Rifleman — flexible infantry, grenades and smoke.",
            "Machine Gunner/HMG — suppression and area denial.",
            "Sniper/Marksman — long-range precision and spotting.",
            "Medic — stabilises incapacitated troops and treats wounds.",
            "Engineer — wire, mines, breaches and fortifications.",
            "Recon — best spotting and mobility.",
            "Grenadier — hand and rifle grenades.",
            "Assault — SMG and strong trench/CQB performance.",
            "Automatic Rifleman — mobile automatic fire support.",
            "Mortar Team — deploy for indirect HE or smoke.",
        ]:self.text(line,(right,yy),13,"text");yy+=29
        self.text("READING THE MAP",(right,yy+8),20,"select");yy+=42
        for line in [
            "Blue rectangles are friendly units; red diamonds are hostile.",
            "? markers show last-known contacts, not live enemy positions.",
            "Blood remains where serious wounds or deaths occurred.",
            "Hold Left Alt for tile cover, concealment, movement and threat.",
        ]:self.text("• "+line,(right,yy),13,"muted");yy+=27
        self.button(self.help_menu_rects()["back"],"BACK",self.mouse)

    def draw_topbar(self):
        pygame.draw.rect(self.screen,COLORS["panel"],(0,0,WINDOW_W,52))
        self.text("KILL ZONE",(18,10),26,"white")
        slow = self.state=="game" and pygame.key.get_pressed()[pygame.K_BACKQUOTE]
        status="PAUSED" if self.game.paused else f"REALTIME ×{self.speed:g}{'  TACTICAL SLOW' if slow else ''}"
        self.text(status,(190,18),14,"select" if self.game.paused else "good")
        self.text(f"Seed {self.game.seed}  |  {self.game.weather.upper()}  |  wind {self.game.wind}",(340,18),14,"muted")
        self.text(f"MODE: {self.command_mode.upper()}  FORM: {self.formation.upper()}",(850,18),14,"contact")
        if self.show_fps:self.text(f"{self.clock.get_fps():5.1f} FPS",(WINDOW_W-105,18),12,"good")

    def cell_rect(self,x,y):return pygame.Rect(MAP_X+x*TILE,MAP_Y+y*TILE,TILE,TILE)

    def draw_map(self):
        for y in range(MAP_H):
            for x in range(MAP_W):
                c=self.game.grid[y][x];r=self.cell_rect(x,y)
                pygame.draw.rect(self.screen,COLORS[c.terrain],r)
                pygame.draw.rect(self.screen,(35,38,33),r,1)
                self.draw_terrain(c,r,x,y)
                if self.show_threat:
                    th=self.game.tile_threat("player",x,y)
                    if th>0:
                        ov=pygame.Surface((TILE,TILE),pygame.SRCALPHA);ov.fill((210,50,40,min(110,int(th*24))))
                        self.screen.blit(ov,r.topleft)
                if c.smoke>.05:
                    alpha=int(clamp(c.smoke/2.4*180,20,190));ov=pygame.Surface((TILE,TILE),pygame.SRCALPHA);ov.fill((185,185,180,alpha));self.screen.blit(ov,r.topleft)
                if c.fire>0:
                    pygame.draw.circle(self.screen,COLORS["fire"],r.center,5+int(min(7,c.fire)))
                if c.mine and c.mine_seen_player:
                    self.text("M",(r.x+9,r.y+7),12,"danger")
        # paths / waypoints / threat preview
        for u in self.selected_units():
            pts=[(MAP_X+u.x*TILE+TILE/2,MAP_Y+u.y*TILE+TILE/2)]
            for x,y in u.path+u.waypoints:pts.append((MAP_X+x*TILE+TILE/2,MAP_Y+y*TILE+TILE/2))
            if len(pts)>1:pygame.draw.lines(self.screen,COLORS["select"],False,pts,2)
        # persistent blood decals (asset-backed when available, procedural offline fallback).
        for b in self.game.blood:
            cx=int(MAP_X+b.x*TILE+TILE/2);cy=int(MAP_Y+b.y*TILE+TILE/2);rr=max(2,int(5+b.size*8))
            if self.blood_sprite:
                spr=pygame.transform.smoothscale(self.blood_sprite,(rr*3,rr*3));spr.set_alpha(145);self.screen.blit(spr,(cx-spr.get_width()//2,cy-spr.get_height()//2))
            else:
                rng=random.Random(b.seed)
                pygame.draw.ellipse(self.screen,COLORS["blood_dark"],(cx-rr,cy-rr//2,rr*2,rr))
                for _ in range(4):
                    ox=rng.randint(-rr,rr);oy=rng.randint(-rr,rr);pygame.draw.circle(self.screen,COLORS["blood"],(cx+ox,cy+oy),max(1,rr//4))
        # last-known enemy contacts expand/fade as certainty decays.
        for uid,info,age in self.game.known_contacts("player",memory=10):
            t=self.game.get_unit(uid)
            if t and self.game.visible_to("player",t):continue
            x,y=info["pos"];cx=int(MAP_X+x*TILE+TILE/2);cy=int(MAP_Y+y*TILE+TILE/2)
            rad=int(5+age*1.6);pygame.draw.circle(self.screen,COLORS["contact"],(cx,cy),rad,1);self.text("?",(cx-4,cy-8),12,"contact")
        # reaction arcs
        for u in self.game.living():
            if (u.overwatch or u.fire_lane) and (u.faction=="player" or self.game.visible_to("player",u)):
                self.draw_arc(u)
        # units
        for u in self.game.units:
            if not u.alive and u.casualty!="dead":continue
            if u.faction=="enemy" and not self.game.visible_to("player",u):continue
            self.draw_unit(u)
        # tracers/explosions
        for t in self.game.tracers:
            a=(MAP_X+t.a[0]*TILE+TILE/2,MAP_Y+t.a[1]*TILE+TILE/2);b=(MAP_X+t.b[0]*TILE+TILE/2,MAP_Y+t.b[1]*TILE+TILE/2)
            q=clamp(1-t.life/max(.001,t.total),0,1);q0=max(0,q-.18)
            p0=(a[0]+(b[0]-a[0])*q0,a[1]+(b[1]-a[1])*q0);p1=(a[0]+(b[0]-a[0])*q,a[1]+(b[1]-a[1])*q)
            pygame.draw.line(self.screen,(245,220,135),p0,p1,2)
        for im in self.game.impacts:
            px=int(MAP_X+im.x*TILE+TILE/2);py=int(MAP_Y+im.y*TILE+TILE/2)
            col=(235,225,195) if im.kind=="body" else (195,190,174) if im.kind=="cover" else (220,195,135)
            pygame.draw.circle(self.screen,col,(px,py),3 if im.kind=="body" else 2)
        for e in self.game.explosions:
            cx=int(MAP_X+e.x*TILE+TILE/2);cy=int(MAP_Y+e.y*TILE+TILE/2)
            pygame.draw.circle(self.screen,COLORS["danger"] if e.kind=="HE" else COLORS["smoke"],(cx,cy),int(e.radius*TILE),1)
            self.text(f"{e.timer:.1f}",(cx-10,cy-8),12,"white")
        self.draw_selection_box()
        if self.game.victory:self.end_banner("VICTORY")
        elif self.game.defeat:self.end_banner("DEFEAT")

    def draw_selection_box(self):
        if not self.drag_start:return
        if max(abs(self.mouse[0]-self.drag_start[0]),abs(self.mouse[1]-self.drag_start[1]))<=5:return
        map_rect=pygame.Rect(MAP_X,MAP_Y,MAP_W*TILE,MAP_H*TILE)
        sx=int(clamp(self.drag_start[0],map_rect.left,map_rect.right));sy=int(clamp(self.drag_start[1],map_rect.top,map_rect.bottom))
        ex=int(clamp(self.mouse[0],map_rect.left,map_rect.right));ey=int(clamp(self.mouse[1],map_rect.top,map_rect.bottom))
        x1,x2=sorted((sx,ex));y1,y2=sorted((sy,ey))
        rect=pygame.Rect(x1,y1,max(1,x2-x1),max(1,y2-y1))
        fill=pygame.Surface(rect.size,pygame.SRCALPHA);fill.fill((229,210,119,28));self.screen.blit(fill,rect.topleft)
        pygame.draw.rect(self.screen,COLORS["select"],rect,2)

    def draw_terrain(self,c:Cell,r:pygame.Rect,x:int,y:int):
        if c.terrain in ("trench","firing_step"):
            if c.axis=="H":pygame.draw.line(self.screen,(38,34,28),(r.x,r.centery),(r.right,r.centery),4)
            else:pygame.draw.line(self.screen,(38,34,28),(r.centerx,r.y),(r.centerx,r.bottom),4)
            if c.terrain=="firing_step":pygame.draw.line(self.screen,(170,145,96),(r.x+4,r.y+5),(r.right-4,r.y+5),2)
        elif c.terrain=="dugout":
            pygame.draw.rect(self.screen,(44,41,35),r.inflate(-5,-5),0);pygame.draw.rect(self.screen,(120,103,75),r.inflate(-5,-5),2)
        elif c.terrain=="woods":
            pygame.draw.circle(self.screen,(39,59,37),(r.centerx-5,r.centery),5);pygame.draw.circle(self.screen,(44,66,41),(r.centerx+5,r.centery-3),5)
        elif c.terrain=="wire":
            pygame.draw.line(self.screen,(180,180,168),(r.x+3,r.y+4),(r.right-3,r.bottom-4),1);pygame.draw.line(self.screen,(180,180,168),(r.right-3,r.y+4),(r.x+3,r.bottom-4),1)
        elif c.terrain=="crater":pygame.draw.ellipse(self.screen,(62,54,43),r.inflate(-7,-10),2)
        elif c.terrain in ("wall","building","woodwall"):
            pygame.draw.rect(self.screen,(55,56,52) if c.terrain!="woodwall" else (84,61,40),r.inflate(-4,-4),2)
        elif c.terrain=="window":
            pygame.draw.rect(self.screen,(60,70,72),r.inflate(-4,-4),2)
            pygame.draw.line(self.screen,(160,180,180),(r.centerx,r.y+4),(r.centerx,r.bottom-4),1)
        elif c.terrain=="door":
            if c.door_open:
                pygame.draw.line(self.screen,(170,135,90),(r.x+5,r.bottom-5),(r.right-5,r.y+5),3)
            else:
                pygame.draw.rect(self.screen,(145,103,65),r.inflate(-8,-3),0)
        elif c.terrain=="sandbags":
            for i in range(3):pygame.draw.rect(self.screen,(156,137,94),(r.x+3+i*8,r.centery-3,7,6),1)

    def draw_arc(self,u:Unit):
        center=(int(MAP_X+u.x*TILE+TILE/2),int(MAP_Y+u.y*TILE+TILE/2));radius=int(u.arc_range*TILE)
        a1=math.radians(u.fire_lane_center-u.arc_width/2);a2=math.radians(u.fire_lane_center+u.arc_width/2)
        p1=(center[0]+math.cos(a1)*radius,center[1]+math.sin(a1)*radius);p2=(center[0]+math.cos(a2)*radius,center[1]+math.sin(a2)*radius)
        col=COLORS["danger"] if u.faction=="enemy" else COLORS["contact"]
        pygame.draw.line(self.screen,col,center,p1,1);pygame.draw.line(self.screen,col,center,p2,1)

    def draw_unit(self,u:Unit):
        cx=int(MAP_X+u.x*TILE+TILE/2);cy=int(MAP_Y+u.y*TILE+TILE/2)
        if u.casualty=="dead":
            pygame.draw.line(self.screen,(65,47,42),(cx-6,cy-6),(cx+6,cy+6),2);pygame.draw.line(self.screen,(65,47,42),(cx+6,cy-6),(cx-6,cy+6),2);return
        friend=u.faction=="player"
        fill=COLORS["nato_friend"] if friend else COLORS["nato_hostile"]
        ink=COLORS["black"]
        # APP-6 affiliation frame: friendly land units use a rectangle; hostile use a diamond.
        if friend:
            rect=pygame.Rect(cx-12,cy-8,24,16);pygame.draw.rect(self.screen,fill,rect);pygame.draw.rect(self.screen,ink,rect,2)
            # Infantry is a full-frame X. Specialist classes retain the infantry base and use a
            # small game-role amplifier instead of inventing fake APP-6 entities.
            pygame.draw.line(self.screen,ink,(rect.left+2,rect.top+2),(rect.right-2,rect.bottom-2),2)
            pygame.draw.line(self.screen,ink,(rect.right-2,rect.top+2),(rect.left+2,rect.bottom-2),2)
        else:
            pts=[(cx,cy-12),(cx+12,cy),(cx,cy+12),(cx-12,cy)]
            pygame.draw.polygon(self.screen,fill,pts);pygame.draw.polygon(self.screen,ink,pts,2)
            pygame.draw.line(self.screen,ink,(cx-7,cy-7),(cx+7,cy+7),2);pygame.draw.line(self.screen,ink,(cx+7,cy-7),(cx-7,cy+7),2)
        role={"Rifleman":"RF","Machine Gunner":"MG","Sniper":"SN","Medic":"MED","Engineer":"ENG","Recon":"REC","Grenadier":"GRN","Assault":"ASLT","Automatic Rifleman":"AR","Marksman":"DMR","HMG Crew":"HMG","Mortar Team":"MTR"}.get(u.role,"INF")
        # Compact role amplifier below the symbol: game metadata, not claimed as an APP-6 entity icon.
        surf=self.fonts[12].render(role,True,COLORS["white"]);self.screen.blit(surf,(cx-surf.get_width()//2,cy+10))
        if u.uid in self.selected:
            pygame.draw.circle(self.screen,COLORS["select"],(cx,cy),17,2)
        ang=math.radians(u.facing);pygame.draw.line(self.screen,COLORS["white"],(cx,cy),(cx+math.cos(ang)*15,cy+math.sin(ang)*15),1)
        pygame.draw.rect(self.screen,(30,30,28),(cx-12,cy+22,24,3));pygame.draw.rect(self.screen,COLORS["good"],(cx-12,cy+22,int(24*clamp(u.hp/u.max_hp,0,1)),3))
        if u.suppression>15:pygame.draw.rect(self.screen,COLORS["contact"],(cx-12,cy+26,int(24*u.suppression/100),2))
        status=""
        if u.reload_timer>0:status="RLD"
        elif u.jammed:status="JAM"
        elif u.order=="rout" or u.morale<16:status="BRK"
        elif u.suppression>=80:status="PIN"
        elif self.game.time<u.disoriented_until:status="CON"
        elif u.order=="suppress":status="SUP"
        elif u.overwatch:status="OW"
        elif u.order=="move":status="MOV"
        if status:
            ss=self.get_font(10).render(status,True,COLORS["status"]);self.screen.blit(ss,(cx-ss.get_width()//2,cy-22))

    def draw_sidebar(self):
        x=SIDEBAR_X
        pygame.draw.rect(self.screen,COLORS["panel"],(x,MAP_Y,WINDOW_W-x-12,MAP_H*TILE))
        self.text("SELECTED",(x+14,MAP_Y+12),20,"white")
        us=self.selected_units()
        y=MAP_Y+44
        if not us:self.text("No units selected",(x+14,y),14,"muted")
        else:
            firing=sum(1 for u in us if u.order=="fire");reloading=sum(1 for u in us if u.reload_timer>0);pinned=sum(1 for u in us if u.suppression>=80);wounded=sum(1 for u in us if u.casualty=="wounded")
            self.text(f"GROUP  fire {firing}  reload {reloading}  pinned {pinned}  wounded {wounded}",(x+14,y),12,"status");y+=20
            for u in us[:5]:
                self.text(f"{u.role} #{u.uid}",(x+14,y),14,"select");y+=19
                self.text(f"HP {u.hp:.0f}/{u.max_hp:.0f}  {u.casualty}",(x+14,y),12);y+=16
                self.text(f"Morale {u.morale:.0f}  Supp {u.suppression:.0f}  Coh {u.cohesion:.0f}",(x+14,y),12);y+=16
                self.text(f"{u.weapon_name}  {u.ammo} | mags {len(u.magazines)}",(x+14,y),12);y+=16
                reserve=sum(u.magazines)
                ammo_col="danger" if u.ammo<=max(2,int(u.weapon["mag"]*.15)) and reserve<=u.weapon["mag"] else "muted"
                self.text(f"Heat {u.heat:.0f}%  Stam {u.stamina:.0f}  {'JAM' if u.jammed else ''}",(x+14,y),12,"contact" if u.heat>70 else "muted");y+=16
                self.text(f"{u.stance} / {u.move_mode} / {u.order}  reserve {reserve}",(x+14,y),12,ammo_col);y+=16
                self.text(f"Ready {u.prepared*100:.0f}%  {'CONCUSSED' if self.game.time<u.disoriented_until else ''}",(x+14,y),12,"muted");y+=16
                auto="ON" if (u.auto_reload and u.auto_cover and u.auto_smoke and u.auto_medic) else "MIX/OFF"
                self.text(f"Fire {u.fire_discipline} / Priority {u.target_priority} / Auto {auto}",(x+14,y),12,"muted");y+=20
            if len(us)>5:self.text(f"+ {len(us)-5} more",(x+14,y),12,"muted");y+=20
        self.text("FIELD REPORT",(x+14,max(y+8,MAP_Y+380)),16,"white")
        yy=max(y+32,MAP_Y+405)
        for line in self.game.log[-9:]:
            self.text(line[:40],(x+14,yy),12,"muted");yy+=17
        # Tile intelligence is intentionally opt-in. Always-on hover text was noisy and
        # previously overlapped because its line coordinates were only two pixels apart.
        keys=pygame.key.get_pressed()
        if keys[pygame.K_LALT]:
            cell=self.map_cell_from_mouse(self.mouse)
            if cell:
                cx,cy=cell;c=self.game.grid[cy][cx];td=TERRAIN[c.terrain]
                base_y=MAP_Y+MAP_H*TILE-108
                pygame.draw.rect(self.screen,COLORS["panel2"],(x+8,base_y-8,WINDOW_W-x-28,104),border_radius=3)
                self.text("TILE INTEL  [LALT]",(x+14,base_y),12,"select")
                self.text(f"{cell}  {c.terrain.upper()}  cover {td['cover']}  conceal {td['conceal']}",(x+14,base_y+18),12,"white")
                self.text(f"move ×{td['move']:.2f}  smoke {c.smoke:.1f}  height {td['height']}",(x+14,base_y+36),12,"muted")
                if c.terrain in ("trench","firing_step") and c.axis:
                    dirs="N/S heavy • E/W low" if c.axis=="H" else "E/W heavy • N/S low"
                else:dirs=f"all directions cover {td['cover']}"
                self.text(f"Directional: {dirs}",(x+14,base_y+54),12,"muted")
                self.text(f"Known exposure threat {self.game.tile_threat('player',cx,cy):.1f}",(x+14,base_y+72),12,"contact")

    def draw_command_bar(self):
        us=self.selected_units()
        if not us:return
        pygame.draw.rect(self.screen,COLORS["panel"],(0,MAP_Y+MAP_H*TILE+3,WINDOW_W,WINDOW_H-(MAP_Y+MAP_H*TILE+3)))
        for name,r in self.command_bar_rects().items():
            active=(name=="FORMATION" or name=="DISCIPLINE" or name=="PRIORITY")
            pygame.draw.rect(self.screen,COLORS["panel2"],r,border_radius=3);pygame.draw.rect(self.screen,COLORS["muted"],r,1,border_radius=3)
            label=name
            if name=="FORMATION":label=self.formation.upper()
            elif name=="DISCIPLINE":label=us[0].fire_discipline.upper()
            elif name=="PRIORITY":label=us[0].target_priority.upper()
            elif name=="AUTO":label="AUTO ON" if all(u.auto_reload and u.auto_cover and u.auto_smoke and u.auto_medic for u in us) else "AUTO OFF"
            surf=self.fonts[12].render(label,True,COLORS["select"] if active or name=="AUTO" else COLORS["white"]);self.screen.blit(surf,(r.centerx-surf.get_width()//2,r.centery-surf.get_height()//2))

    def draw_help(self):
        w,h=790,620;x=(WINDOW_W-w)//2;y=(WINDOW_H-h)//2
        ov=pygame.Surface((w,h),pygame.SRCALPHA);ov.fill((20,23,20,242));self.screen.blit(ov,(x,y));pygame.draw.rect(self.screen,COLORS["select"],(x,y,w,h),2)
        self.text("REALTIME CONTROLS",(x+22,y+18),26,"white")
        lines=[
            "LMB select / visible drag box | Shift+LMB add/remove | RMB order | Shift+RMB queue order",
            "SPACE pause | hold ` tactical slow-motion | Left Alt tile intel | TAB threat overlay | F11 fullscreen",
            "Ctrl+1..9 assign control group | 1..9 recall group | F4 formation | F3 bounding overwatch",
            "F7 fire discipline | F8 target priority | F10 autonomy | bottom command bar mirrors key actions",
            "Z stance | X route mode (fast/safe/manual) | A aimed | F snap | W rapid fire",
            "R tactical reload | Shift+R emergency reload (drops partial mag) | J clear jam | B barrel",
            "O overwatch toward mouse | I MG fire lane toward mouse | Q suppress area then RMB",
            "G grenade then RMB | Shift+C cook grenade | S smoke | L rifle grenade | K satchel",
            "V fix/remove bayonet | P peek | C coordinated covering advance toward mouse",
            "RMB wounded ally: medic/drag | Alt+RMB incapacitated: carry | Ctrl+RMB: share ammo",
            "ENTER toggle door | Shift+E deliberate mine scan | 4 engineer places wire",
            "E engineer contextual action | T dig trench | U Bangalore breach",
            "M on-map mortar HE | N on-map mortar smoke | H off-map HE | Y off-map smoke",
            "BACKSPACE cancel orders | F5 new battle | F6 cycle difficulty + restart",
            "",
            "Implemented systems:",
            "• continuous movement/firing/reloads/suppression/bleeding • fog of war • facing/flanks",
            "• directional trench cover/enfilade • stances • MG heat/jams/barrel changes/fire lanes",
            "• tactical magazines + ammo sharing model • assistant-gunner reload bonuses • HMG teams",
            "• medics/stabilization/dragging • engineers/wire/mines/fortifications/trench digging",
            "• grenades/rifle grenades/satchels/Bangalore • grenade reactions • trench CQB/bayonets",
            "• buildings/doors • hills/reverse slopes • penetration • smoke density/wind • weather/fire",
            "• recon/grenadier/assault/automatic rifleman/marksman • on-map mortar teams/support",
            "• rout/surrender • combat momentum • coherent procedural battlefield • destructible terrain",
            "• control groups/formations • command queue • bounding overwatch • fire discipline/priority",
            "• APP-6 affiliation frames • shared fog/contact memory for AI • animated tracers/near-miss suppression",
            "• auto reload • stamina/fatigue • reaction/traverse delay • concussion • cover degradation",
            "• crossfire/sector overload • position suppression • fallback AI • morale contagion • assault momentum",
        ]
        yy=y+62
        for line in lines:
            self.text(line,(x+22,yy),12,"text" if not line.startswith("•") else "muted");yy+=22

    def end_banner(self,text):
        r=pygame.Rect(MAP_X+300,MAP_Y+250,480,100);pygame.draw.rect(self.screen,COLORS["panel"],r);pygame.draw.rect(self.screen,COLORS["select"],r,3)
        self.text(text,(r.x+160,r.y+28),36,"white")

    def run(self):
        while self.running:
            real_dt=min(.05,self.clock.tick(FPS)/1000.0)
            for e in pygame.event.get():self.handle_event(self.normalize_event_pos(e))
            if self.state=="game" and not self.game.paused:
                slow=.25 if pygame.key.get_pressed()[pygame.K_BACKQUOTE] else 1.0
                self.accum+=real_dt*self.speed*slow
                while self.accum>=SIM_DT:
                    self.game.update(SIM_DT);self.accum-=SIM_DT
                for ev in self.game.drain_events():self.play_event(ev)
            if time.time()>=self.asset_refresh_at:
                self.refresh_assets();self.asset_refresh_at=time.time()+2.0
            self.draw()
        pygame.quit()



# =============================================================================
# KILL ZONE — COMMAND / CAMERA / PERFORMANCE PASS
# =============================================================================
# This layer deliberately extends the existing simulation without duplicating the
# original systems. It concentrates expensive work into caches/budgets and adds
# higher-level tactical commands, squads, deployment, camera controls and richer
# tactical previews. Logistics expansion is intentionally deferred.

@dataclass
class AssaultOrder:
    support: List[int]
    assault: List[int]
    dest: Coord
    target_uid: Optional[int] = None
    phase: int = 0
    timer: float = 0.0


@dataclass
class DustPuff:
    x: float
    y: float
    size: float
    life: float
    total: float


def _kz_event_record(self, kind: str, text: str, pos=None):
    if not hasattr(self, 'battle_events'):
        self.battle_events=[]
    self.battle_events.append({'time': self.time, 'kind': kind, 'text': text, 'pos': pos})
    self.battle_events=self.battle_events[-500:]


def _kz_rebuild_indexes(self):
    self._uid_index={u.uid:u for u in self.units}
    occ={}
    for u in self.units:
        if u.alive:
            occ[u.tile]=u.uid
    self._occupancy=occ
    self._living_cache={
        'player':[u for u in self.units if u.alive and u.faction=='player'],
        'enemy':[u for u in self.units if u.alive and u.faction=='enemy'],
    }


_old_rt_init=RealTimeGame.__init__
def _kz_rt_init(self, seed: Optional[int]=None, difficulty: str='Hard', player_roster: Optional[List[str]]=None, reserve_count: int=0):
    self.reserve_count=max(0,int(reserve_count))
    self._uid_index={};self._occupancy={};self._living_cache={'player':[],'enemy':[]}
    self._threat_grids={};self._threat_cache_time=-999.0
    self._path_budget=3;self._path_cache={};self._terrain_revision=0
    self._ai_cursor=0;self._perf={'sim_ms':0.0,'path_ms':0.0,'ai_ms':0.0,'paths':0,'ai_decisions':0}
    self.battle_events=[];self.assault_orders=[];self.dust=[]
    self.stats={f:{'shots':0,'hits':0,'kills':0,'grenades':0,'smoke':0,'casualties':0,'surrendered':0,'reserves':0} for f in ('player','enemy')}
    self.player_reserves=[]
    self.primary_line_x=MAP_W-13;self.secondary_line_x=MAP_W-6;self.deployment_zone_x=10
    self._mortar_solutions={}
    _old_rt_init(self,seed=seed,difficulty=difficulty,player_roster=player_roster)
    _kz_rebuild_indexes(self)
    self.enemy_estimate=(max(1,DIFFICULTY[self.difficulty]['enemy']-2),DIFFICULTY[self.difficulty]['enemy']+2)

RealTimeGame.__init__=_kz_rt_init


_old_set_cell=RealTimeGame.set_cell
def _kz_set_cell(self,x,y,terrain,axis=None):
    _old_set_cell(self,x,y,terrain,axis)
    self._terrain_revision=getattr(self,'_terrain_revision',0)+1
    if hasattr(self,'_path_cache') and len(self._path_cache)>256:self._path_cache.clear()
RealTimeGame.set_cell=_kz_set_cell


def _kz_generate_map(self):
    # Coherent defensive problem: primary/secondary lines, communication trenches,
    # strongpoints, deliberate breaches and three viable approach corridors.
    for y in range(MAP_H):
        for x in range(MAP_W):
            self.set_cell(x,y,'open')
    road_y=self.rng.randint(7,MAP_H-8)
    for x in range(MAP_W):
        self.set_cell(x,road_y,'road')
    p=self.primary_line_x;s=self.secondary_line_x
    # Primary line zig-zags so it has useful sectors without becoming a straight laser lane.
    for y in range(2,MAP_H-2):
        xx=p + (1 if (y//6)%2 else 0)
        self.set_cell(xx,y,'trench','V')
        if y%6==3:
            self.set_cell(max(1,xx-1),y,'firing_step','H')
    # Secondary fallback line.
    for y in range(3,MAP_H-3):
        if y%2==0 or self.rng.random()<.7:self.set_cell(s,y,'trench','V')
    strong_ys=[6,MAP_H//2,MAP_H-7]
    for sy in strong_ys:
        # communications to secondary line
        for x in range(p,min(MAP_W-2,s+1)):
            self.set_cell(x,sy,'trench','H')
        self.set_cell(p+2,sy,'bunker')
        self.set_cell(p+1,sy-1,'sandbags');self.set_cell(p+1,sy+1,'sandbags')
        if self.in_bounds(p+3,sy+1):self.set_cell(p+3,sy+1,'dugout')
    # Extra communication trench from rear to center.
    cy=MAP_H//2+3
    for x in range(p-4,s+1):self.set_cell(x,cy,'trench','H')
    # Wire belt with deliberately generated assault lanes.
    wx=p-5
    gap_ys=[road_y,5,MAP_H//2+1,MAP_H-6]
    for y in range(1,MAP_H-1):
        if all(abs(y-g)>1 for g in gap_ys):self.set_cell(wx,y,'wire')
    # Mines cluster around the belt, never directly in the known breaches.
    for _ in range(46):
        x=self.rng.randint(wx-2,p-1);y=self.rng.randint(2,MAP_H-3)
        if all(abs(y-g)>1 for g in gap_ys) and self.grid[y][x].terrain in ('open','mud','road'):
            self.grid[y][x].mine=True
    # Build protected-ish approach corridors from west toward each breach.
    for lane_y in gap_ys:
        for x in range(7,wx-1,3):
            yy=int(clamp(lane_y+self.rng.randint(-2,2),1,MAP_H-2))
            if self.grid[yy][x].terrain=='open':
                self.set_cell(x,yy,self.rng.choice(['crater','crater','foxhole','mud']))
            if self.rng.random()<.42 and yy+1<MAP_H-1 and self.grid[yy+1][x].terrain=='open':
                self.set_cell(x,yy+1,'crater')
    # Flank woods and rolling high ground; middle remains a dangerous kill zone.
    for base_y in (4,MAP_H-5):
        for _ in range(5):
            cx=self.rng.randint(10,wx-3);cy=int(clamp(base_y+self.rng.randint(-3,3),2,MAP_H-3))
            for _ in range(self.rng.randint(7,13)):
                x=int(clamp(cx+self.rng.randint(-2,2),1,MAP_W-2));y=int(clamp(cy+self.rng.randint(-2,2),1,MAP_H-2))
                if self.grid[y][x].terrain=='open':self.set_cell(x,y,self.rng.choice(['woods','woods','hill']))
    # Scattered central ruins/compound.
    bx=self.rng.randint(18,25);by=self.rng.randint(7,MAP_H-10)
    for x in range(bx,bx+6):
        for y in (by,by+5):self.set_cell(x,y,'building')
    for y in range(by,by+6):
        for x in (bx,bx+5):self.set_cell(x,y,'building')
    self.set_cell(bx+2,by+5,'door');self.set_cell(bx+1,by,'window');self.set_cell(bx+4,by,'window')
    # Random shell damage and cover in no-man's-land.
    for _ in range(95):
        x=self.rng.randint(8,wx-2);y=self.rng.randint(2,MAP_H-3)
        if self.grid[y][x].terrain=='open':self.set_cell(x,y,self.rng.choice(['crater','crater','mud','open']))
    # Defender wall fragments, but never seal an entire approach.
    for _ in range(18):
        x=self.rng.randint(p-2,MAP_W-3);y=self.rng.randint(2,MAP_H-3)
        if self.grid[y][x].terrain=='open':self.set_cell(x,y,'wall')
    self.map_features={'road_y':road_y,'wire_x':wx,'breaches':gap_ys,'primary_x':p,'secondary_x':s}

RealTimeGame.generate_map=_kz_generate_map


_old_add_unit=RealTimeGame.add_unit
def _kz_add_unit(self,faction,role,x,y):
    u=_old_add_unit(self,faction,role,x,y)
    # Persistent fireteam identity; four soldiers per squad by default.
    same=[a for a in self.units if a.faction==faction and a.uid!=u.uid]
    u.squad_id=len(same)//4+1
    u.wait_until=0.0;u.blocked_since=0.0;u.mortar_ranging=0.0
    u.shots_recent=0;u.last_shot_time=-99.0;u.reserve=False
    if hasattr(self,'_uid_index'):self._uid_index[u.uid]=u
    if hasattr(self,'_occupancy'):self._occupancy[u.tile]=u.uid
    return u
RealTimeGame.add_unit=_kz_add_unit


def _kz_spawn_default_forces(self):
    roles=list(self.player_roster)
    rc=min(self.reserve_count,max(0,len(roles)-1))
    active=roles[:-rc] if rc else roles
    self.player_reserves=roles[-rc:] if rc else []
    # Spread active force inside the deployment zone. Player can rearrange before start.
    for i,role in enumerate(active):
        x=3+(i%4);y=4+(i//4)*6+(i%2)
        self.add_unit('player',role,x,min(y,MAP_H-3))
    enemy_pool=['Rifleman','Rifleman','Machine Gunner','Marksman','Assault','Grenadier','Engineer','Medic','Automatic Rifleman','HMG Crew','Sniper']
    n=DIFFICULTY[self.difficulty]['enemy'];spots=[]
    for xx in (self.primary_line_x,self.primary_line_x+1,self.secondary_line_x):
        for y in range(2,MAP_H-2):
            if self.in_bounds(xx,y) and self.grid[y][xx].terrain in ('trench','firing_step','bunker','sandbags'):
                spots.append((xx,y))
    self.rng.shuffle(spots)
    for i in range(n):
        role=enemy_pool[i%len(enemy_pool)];x,y=spots[i%len(spots)] if spots else (self.primary_line_x,3+i)
        if self.unit_at(x,y) is not None:y=int(clamp(y+1,1,MAP_H-2))
        u=self.add_unit('enemy',role,x,y)
        if role in ('Machine Gunner','HMG Crew'):
            u.deployed=True;u.fire_lane=True;u.fire_lane_center=180;u.arc_width=85
        u.fallback_point=(self.secondary_line_x,int(clamp(y,2,MAP_H-3)))
    _kz_rebuild_indexes(self)

RealTimeGame.spawn_default_forces=_kz_spawn_default_forces


def _kz_get_unit(self,uid):
    if uid is None:return None
    u=getattr(self,'_uid_index',{}).get(uid)
    if u is None:
        u=next((x for x in self.units if x.uid==uid),None)
        if u is not None:self._uid_index[uid]=u
    return u
RealTimeGame.get_unit=_kz_get_unit


def _kz_living(self,faction=None):
    # Unit counts are modest; a direct filter is cheap and remains correct when tests/tools
    # replace the unit list between simulation ticks. Hot lookup paths use dedicated indexes.
    return [u for u in self.units if u.alive and (faction is None or u.faction==faction)]
RealTimeGame.living=_kz_living


def _kz_unit_at(self,x,y,include_incap=True):
    occ=getattr(self,'_occupancy',None)
    if occ is not None:
        uid=occ.get((x,y))
        if not uid:return None
        u=self.get_unit(uid)
        if u and u in self.units and u.alive and u.tile==(x,y) and (include_incap or u.combat_effective):return u
        occ.pop((x,y),None)
        return None
    for u in self.units:
        if not u.alive:continue
        if not include_incap and not u.combat_effective:continue
        if u.tile==(x,y):return u
    return None
RealTimeGame.unit_at=_kz_unit_at


def _kz_compute_threat_grid(self,faction):
    grid=[[0.0 for _ in range(MAP_W)] for _ in range(MAP_H)]
    enemy='enemy' if faction=='player' else 'player'
    for e in self.living(enemy):
        if not e.combat_effective or not self.visible_to(faction,e):continue
        r=int(math.ceil(e.weapon['range']+1.5));ex,ey=e.tile
        y0=max(0,ey-r);y1=min(MAP_H,ey+r+1);x0=max(0,ex-r);x1=min(MAP_W,ex+r+1)
        for y in range(y0,y1):
            dy=y-e.y
            for x in range(x0,x1):
                d=math.hypot(x-e.x,dy)
                if d>e.weapon['range']+1.5:continue
                local=max(.15,1.25-d/max(1.0,e.weapon['range']))
                bearing=angle_to(e,(x,y))
                if (e.overwatch or e.fire_lane) and angle_diff(e.fire_lane_center,bearing)<=e.arc_width/2:local+=.9
                if e.role in ('Machine Gunner','HMG Crew'):local+=.35
                grid[y][x]+=local
    self._threat_grids[faction]=grid


def _kz_tile_threat(self,faction,x,y):
    if not self.in_bounds(x,y):return 99.0
    if self.time-getattr(self,'_threat_cache_time',-999)>.35 or faction not in getattr(self,'_threat_grids',{}):
        self._threat_cache_time=self.time
        self._threat_grids={}
        self._kz_compute_threat_grid('player');self._kz_compute_threat_grid('enemy')
    return self._threat_grids[faction][y][x]
RealTimeGame._kz_compute_threat_grid=_kz_compute_threat_grid
RealTimeGame.tile_threat=_kz_tile_threat


_old_find_path=RealTimeGame.find_path
def _kz_find_path(self,unit,dest,mode=None):
    t0=time.perf_counter();mode=mode or unit.move_mode;start=unit.tile
    key=(start,dest,mode,unit.faction,getattr(self,'_terrain_revision',0)//8)
    cached=self._path_cache.get(key)
    if cached is not None:
        out=list(cached);self._perf['path_ms']+=(time.perf_counter()-t0)*1000;return out
    if not self.passable(*dest,unit):return []
    pq=[(0.0,start)];came={start:None};cost={start:0.0};expanded=0
    while pq and expanded<MAP_W*MAP_H:
        _,cur=heapq.heappop(pq);expanded+=1
        if cur==dest:break
        x,y=cur
        for nx,ny in ((x+1,y),(x-1,y),(x,y+1),(x,y-1)):
            if not self.passable(nx,ny,unit):continue
            c=self.grid[ny][nx];step=TERRAIN[c.terrain]['move']
            if c.terrain=='trench' and self.grid[y][x].terrain=='trench':step*=.62
            if mode=='safe':
                step+=self.tile_threat(unit.faction,nx,ny)*2.25+c.ground_suppression*.022
                step=max(.18,step-min(.68,TERRAIN[c.terrain]['cover']*.11))
            elif mode=='fast':step*=.8
            nc=cost[cur]+step
            if (nx,ny) not in cost or nc<cost[(nx,ny)]:
                cost[(nx,ny)]=nc;h=abs(dest[0]-nx)+abs(dest[1]-ny)
                heapq.heappush(pq,(nc+h*.42,(nx,ny)));came[(nx,ny)]=cur
    if dest not in came:out=[]
    else:
        out=[];cur=dest
        while cur!=start:out.append(cur);cur=came[cur]
        out.reverse()
    if len(self._path_cache)>512:self._path_cache.clear()
    self._path_cache[key]=tuple(out)
    self._perf['paths']+=1;self._perf['path_ms']+=(time.perf_counter()-t0)*1000
    return out
RealTimeGame.find_path=_kz_find_path


_old_issue_move=RealTimeGame.issue_move
def _kz_issue_move(self,units,dest,append=False,mode=None,formation='spread'):
    effective=[u for u in units if u.combat_effective]
    if self.in_bounds(*dest) and self.grid[dest[1]][dest[0]].terrain in ('trench','firing_step','dugout'):
        formation='column'
    elif len(effective)>=4:
        cx=sum(u.x for u in effective)/len(effective);cy=sum(u.y for u in effective)/len(effective)
        corridor=self.line_cells((cx,cy),dest)
        if any(self.grid[y][x].terrain in ('trench','firing_step','door','bridge') for x,y in corridor if self.in_bounds(x,y)):
            formation='column'
    _old_issue_move(self,units,dest,append=append,mode=mode,formation=formation)
    # Path construction is intentionally deferred and budgeted across simulation ticks.
    for i,u in enumerate([x for x in units if x.combat_effective]):
        u.path_ready_at=self.time+i*.008
RealTimeGame.issue_move=_kz_issue_move


_old_update_movement=RealTimeGame.update_movement
def _kz_update_movement(self,u,dt):
    if self.time<getattr(u,'wait_until',0):return
    if not u.path and u.waypoints:
        if self.time<getattr(u,'path_ready_at',0):return
        if self._path_budget<=0:return
        self._path_budget-=1
    # Prevent friendly traffic jams from causing immediate full A* churn.
    if u.path:
        nxt=u.path[0];occ=self._occupancy.get(nxt)
        if occ and occ!=u.uid:
            other=self.get_unit(occ)
            if other and other.faction==u.faction and other.combat_effective:
                if not getattr(u,'blocked_since',0):u.blocked_since=self.time
                u.wait_until=self.time+self.rng.uniform(.05,.13)
                if self.time-u.blocked_since>.65:u.path=[];u.blocked_since=0
                return
        u.blocked_since=0
    old_tile=u.tile
    _old_update_movement(self,u,dt)
    new_tile=u.tile
    if new_tile!=old_tile:
        if self._occupancy.get(old_tile)==u.uid:self._occupancy.pop(old_tile,None)
        self._occupancy[new_tile]=u.uid
    # Gentle local separation outside trenches; prevents large groups visually stacking.
    if self.grid[new_tile[1]][new_tile[0]].terrain not in ('trench','firing_step','dugout'):
        for a in self.living(u.faction):
            if a.uid==u.uid or not a.combat_effective:continue
            dx=u.x-a.x;dy=u.y-a.y;d2=dx*dx+dy*dy
            if 1e-5<d2<.20:
                d=math.sqrt(d2);push=min(.025,(.46-d)*.06)
                u.x=clamp(u.x+dx/d*push,.2,MAP_W-.2);u.y=clamp(u.y+dy/d*push,.2,MAP_H-.2)
RealTimeGame.update_movement=_kz_update_movement


_old_can_see=RealTimeGame.can_see
def _kz_can_see(self,observer,target):
    # Snipers/marksmen become materially harder to acquire while settled and concealed.
    if target.role=='Sniper' and target.prepared>.6 and target.signature<10 and target.combat_effective:
        d=dist(observer,target)
        # At long range a settled sniper requires superior observation to acquire.
        if d>max(5.5,ROLES[observer.role]['spot']*.70):return False
    return _old_can_see(self,observer,target)
RealTimeGame.can_see=_kz_can_see


_old_hit_chance=RealTimeGame.hit_chance
def _kz_hit_chance(self,attacker,target,mode=None,reaction=False):
    c=_old_hit_chance(self,attacker,target,mode=mode,reaction=reaction)
    if attacker.role=='Sniper' and attacker.signature<10 and attacker.prepared>.65 and (mode or attacker.fire_mode)=='aimed':
        c=min(96,c+8)
    return c
RealTimeGame.hit_chance=_kz_hit_chance


_old_perform_shot=RealTimeGame.perform_shot
def _kz_perform_shot(self,attacker,target,reaction=False):
    before_hp=target.hp;before_ammo=attacker.ammo
    _old_perform_shot(self,attacker,target,reaction=reaction)
    if attacker.ammo<before_ammo:
        self.stats[attacker.faction]['shots']+=1;attacker.shots_recent=getattr(attacker,'shots_recent',0)+1;attacker.last_shot_time=self.time
        if target.hp<before_hp:self.stats[attacker.faction]['hits']+=1
        # Keep render transient counts bounded in heavy firefights.
        if len(self.tracers)>260:self.tracers=self.tracers[-220:]
        if len(self.impacts)>220:self.impacts=self.impacts[-180:]
RealTimeGame.perform_shot=_kz_perform_shot


_old_apply_damage=RealTimeGame.apply_damage
def _kz_apply_damage(self,target,damage,source,cause):
    before=target.casualty;_old_apply_damage(self,target,damage,source,cause)
    if before not in ('dead','surrendered') and target.casualty in ('dead','incapacitated'):
        self.stats[target.faction]['casualties']+=1
        if source:self.stats[source.faction]['kills']+=1
        self._kz_event_record('casualty',f'{target.faction} {target.role} {target.casualty}',target.pos)
RealTimeGame.apply_damage=_kz_apply_damage
RealTimeGame._kz_event_record=_kz_event_record


_old_throw_grenade=RealTimeGame.throw_grenade
def _kz_throw_grenade(self,u,pos,smoke=False,cook=0.0,rifle=False):
    gb=u.grenades;sb=u.smoke_grenades;rb=u.rifle_grenades
    _old_throw_grenade(self,u,pos,smoke=smoke,cook=cook,rifle=rifle)
    if u.grenades<gb or u.rifle_grenades<rb:self.stats[u.faction]['grenades']+=1
    if u.smoke_grenades<sb:self.stats[u.faction]['smoke']+=1
RealTimeGame.throw_grenade=_kz_throw_grenade


_old_resolve_explosion=RealTimeGame.resolve_explosion
def _kz_resolve_explosion(self,e):
    _old_resolve_explosion(self,e)
    self._kz_event_record('explosion',f'{e.kind} detonation',(e.x,e.y))
    if e.kind=='HE':
        for _ in range(min(12,max(4,int(e.radius*4)))):
            a=self.rng.random()*math.tau;r=self.rng.random()*e.radius*.75
            self.dust.append(DustPuff(e.x+math.cos(a)*r,e.y+math.sin(a)*r,self.rng.uniform(.18,.48),self.rng.uniform(.35,.8),.8))
        self.dust=self.dust[-100:]
    # Extend staged destruction without multiplying particle counts.
    if e.kind=='HE':
        cx,cy=int(round(e.x)),int(round(e.y))
        for y in range(max(0,cy-int(e.radius)),min(MAP_H,cy+int(e.radius)+1)):
            for x in range(max(0,cx-int(e.radius)),min(MAP_W,cx+int(e.radius)+1)):
                if math.hypot(x-e.x,y-e.y)>e.radius:continue
                c=self.grid[y][x]
                if c.terrain=='woods' and e.damage>55 and self.rng.random()<.45:c.reset_terrain('open')
                elif c.terrain in ('wall','building','woodwall') and c.hp is not None and c.hp<=0:c.reset_terrain('rubble')
                elif c.terrain in ('sandbags','firing_step') and c.cover_wear>.82 and self.rng.random()<.5:c.reset_terrain('rubble')
RealTimeGame.resolve_explosion=_kz_resolve_explosion


def _kz_recrew(self,helper,crew):
    if not helper.combat_effective or dist(helper,crew)>1.6:return False
    if crew.role in ('Machine Gunner','HMG Crew') and crew.combat_effective and not crew.assistant_alive:
        crew.assistant_alive=True;crew.crew=max(2,crew.crew);helper.action_timer=1.5;helper.order='idle'
        self.add_log(f'{helper.role} joined {crew.role} as assistant gunner.');return True
    if crew.role=='HMG Crew' and crew.casualty=='incapacitated':
        helper.role='HMG Crew';helper.weapon_name='Heavy Machine Gun';helper.ammo=max(helper.ammo,crew.ammo);helper.deployed=False;helper.assistant_alive=False
        helper.action_timer=2.2;self.add_log(f'{helper.faction} infantry re-crewed an abandoned HMG.');return True
    return False
RealTimeGame.recrew_weapon=_kz_recrew


_old_mortar_fire=RealTimeGame.mortar_fire
def _kz_mortar_fire(self,u,pos,smoke=False):
    d=dist(u,pos)
    if d<5.0:
        self.add_log('Mortar target inside minimum range.');return
    if d>19.0:
        self.add_log('Mortar target beyond effective range.');return
    if not u.deployed or u.mortar_shells<=0:return
    key=(u.uid,int(pos[0]//2),int(pos[1]//2),bool(smoke));ranged=self._mortar_solutions.get(key,0)
    # A recon/marksman observer with LOS improves the solution.
    observers=[a for a in self.living(u.faction) if a.role in ('Recon','Marksman') and a.combat_effective and dist(a,pos)<15]
    observed=any(self.line_info(a.pos,pos)[0] for a in observers)
    sigma=max(.35,1.45-ranged*.32-(.38 if observed else 0))
    aim=(clamp(pos[0]+self.rng.gauss(0,sigma),1,MAP_W-2),clamp(pos[1]+self.rng.gauss(0,sigma),1,MAP_H-2))
    self._mortar_solutions[key]=min(3,ranged+1)
    _old_mortar_fire(self,u,aim,smoke=smoke)
    self._kz_event_record('mortar',f"Mortar {'smoke' if smoke else 'HE'} ranging {ranged+1}",aim)
RealTimeGame.mortar_fire=_kz_mortar_fire


def _kz_assault_position(self,units,dest,target_uid=None):
    us=[u for u in units if u.combat_effective]
    if not us:return
    support=[u for u in us if u.role in ('Machine Gunner','HMG Crew','Automatic Rifleman','Marksman','Sniper','Mortar Team')]
    assault=[u for u in us if u not in support]
    if not assault:
        assault=us[::2];support=[u for u in us if u not in assault]
    if not support and len(assault)>1:support=[assault.pop()]
    ao=AssaultOrder([u.uid for u in support],[u.uid for u in assault],dest,target_uid,0,0.0)
    self.assault_orders.append(ao);self._kz_event_record('assault','Assault order initiated',dest)
    # Immediate support-by-fire; smoke is thrown by a suitable assault element.
    for u in support:
        if u.role in ('Machine Gunner','HMG Crew') and not u.deployed:self.toggle_deploy(u)
        self.suppress_area(u,dest)
    smoker=next((u for u in assault if u.smoke_grenades>0),None)
    if smoker:
        mid=((smoker.x+dest[0])*.55,(smoker.y+dest[1])*.55);self.throw_grenade(smoker,mid,smoke=True)
    self.add_log('Assault: support element suppressing; assault element standing by.')
RealTimeGame.assault_position=_kz_assault_position


def _kz_update_assault_orders(self,dt):
    for ao in list(self.assault_orders):
        ao.timer+=dt
        support=[self.get_unit(i) for i in ao.support];assault=[self.get_unit(i) for i in ao.assault]
        support=[u for u in support if u and u.combat_effective];assault=[u for u in assault if u and u.combat_effective]
        if not assault:
            self.assault_orders.remove(ao);continue
        dx,dy=ao.dest;ground=self.grid[int(clamp(dy,0,MAP_H-1))][int(clamp(dx,0,MAP_W-1))].ground_suppression
        target=self.get_unit(ao.target_uid) if ao.target_uid else None
        target_supp=target.suppression if target and target.combat_effective else 0
        if ao.phase==0 and (ao.timer>2.2 or ground>24 or target_supp>45):
            for u in assault:
                u.move_mode='fast' if self.grid[int(clamp(dy,0,MAP_H-1))][int(clamp(dx,0,MAP_W-1))].smoke>1.0 else 'safe'
            self.issue_move(assault,ao.dest,mode=assault[0].move_mode,formation='spread');ao.phase=1;ao.timer=0
            self.add_log('Assault element moving under supporting fire.')
        elif ao.phase==1:
            for u in support:
                if u.order in ('idle','overwatch') and u.ammo>0:self.suppress_area(u,ao.dest)
            if any(dist(u.pos,ao.dest)<2.2 for u in assault) or ao.timer>11:
                ao.phase=2;ao.timer=0
                for u in assault:
                    enemies=[e for e in self.living('enemy' if u.faction=='player' else 'player') if e.combat_effective and dist(e,u)<u.weapon['range']]
                    if enemies:self.issue_fire(u,min(enemies,key=lambda e:dist(e,u)),'rapid' if u.role=='Assault' else 'normal')
        elif ao.phase==2 and (ao.timer>5 or all(dist(u.pos,ao.dest)<3 for u in assault)):
            self._kz_event_record('assault','Assault reached objective',ao.dest);self.assault_orders.remove(ao)
RealTimeGame.update_assault_orders=_kz_update_assault_orders


def _kz_deploy_reserves(self):
    if not self.player_reserves:return []
    roles=list(self.player_reserves);self.player_reserves=[];new=[]
    base_y=int(clamp(self.rally_points['player'][1],3,MAP_H-4))
    for i,role in enumerate(roles):
        x=2+(i%3);y=int(clamp(base_y+(i//3)*2-(len(roles)//3),2,MAP_H-3))
        while self.unit_at(x,y) and y<MAP_H-3:y+=1
        u=self.add_unit('player',role,x,y);u.reserve=True;new.append(u)
    self.stats['player']['reserves']+=len(new);_kz_rebuild_indexes(self)
    self.add_log(f'{len(new)} reserve unit(s) entered from the west.');self._kz_event_record('reserve',f'{len(new)} reserves committed',(2,base_y))
    return new
RealTimeGame.deploy_player_reserves=_kz_deploy_reserves


_old_handle_break_ext=RealTimeGame.handle_break
def _kz_handle_break_ext(self,u):
    before=u.casualty;_old_handle_break_ext(self,u)
    if before!='surrendered' and u.casualty=='surrendered':
        self.stats[u.faction]['surrendered']+=1;self._kz_event_record('surrender',f'{u.faction} {u.role} surrendered',u.pos)
RealTimeGame.handle_break=_kz_handle_break_ext


_old_update_ai=RealTimeGame.update_ai
def _kz_update_ai(self,dt):
    t0=time.perf_counter();enemies=[u for u in self.living('enemy') if u.combat_effective]
    if not enemies:return
    budget=2 if self.difficulty=='Easy' else 3 if self.difficulty=='Hard' else 4
    checked=0;done=0;delay=DIFFICULTY[self.difficulty]['ai'];n=len(enemies)
    while checked<n and done<budget:
        u=enemies[self._ai_cursor % n];self._ai_cursor=(self._ai_cursor+1)%max(1,n);checked+=1
        if u.order in ('rout','medic','deploy','pack','barrel','clear_jam') or u.action_timer>0:continue
        if self.time-u.last_ai<delay:continue
        u.last_ai=self.time+self.rng.uniform(0,.12);self.ai_decide(u);done+=1
    self._perf['ai_decisions']+=done;self._perf['ai_ms']+=(time.perf_counter()-t0)*1000
RealTimeGame.update_ai=_kz_update_ai


_old_ai_decide=RealTimeGame.ai_decide
def _kz_ai_decide(self,u):
    visible=[p for p in self.living('player') if p.combat_effective and self.can_see(u,p)]
    if visible:
        target=min(visible,key=lambda p:(0 if p.role in ('Machine Gunner','HMG Crew','Sniper','Medic') else 1,dist(u,p)))
        mates=[a for a in self.living('enemy') if a.uid!=u.uid and a.combat_effective and getattr(a,'squad_id',0)==getattr(u,'squad_id',-1)]
        support_active=any(a.order=='suppress' or a.fire_lane for a in mates)
        tactics=DIFFICULTY[self.difficulty].get('tactics',1)
        # Support weapons establish a base of fire for their squad.
        if u.role in ('Machine Gunner','HMG Crew','Automatic Rifleman') and target.suppression<65:
            if u.role in ('Machine Gunner','HMG Crew') and not u.deployed:self.toggle_deploy(u);return
            self.suppress_area(u,target.pos);return
        # Infantry uses that support to maneuver rather than duplicating fire from one lane.
        if support_active and u.role in ('Rifleman','Assault','Grenadier','Engineer') and dist(u,target)>3 and self.rng.random()<(.32*tactics):
            dx=target.x-u.x;dy=target.y-u.y;ln=max(1,math.hypot(dx,dy));side=-1 if getattr(u,'squad_id',0)%2 else 1
            fx=int(clamp(target.x+side*(-dy/ln)*4.5,1,MAP_W-2));fy=int(clamp(target.y+side*(dx/ln)*4.5,1,MAP_H-2))
            if self.tile_threat('enemy',fx,fy)<self.tile_threat('enemy',*u.tile)+.8:
                if u.smoke_grenades>0 and self.tile_threat('enemy',fx,fy)>1.0 and self.rng.random()<.35*tactics:self.throw_grenade(u,((u.x+fx)/2,(u.y+fy)/2),smoke=True)
                self.issue_move([u],(fx,fy),mode='safe',formation='column');return
    # Snipers that have fired repeatedly relocate before the enemy can fix the position.
    if u.role=='Sniper' and getattr(u,'shots_recent',0)>=3 and u.signature>12 and u.order not in ('move','rout'):
        dest=self.find_nearby_cover(u,6)
        if dest and dest!=u.tile:
            u.shots_recent=0;self.issue_move([u],dest,mode='safe',formation='column');return
    # Prefer prepared secondary positions when falling back.
    if (u.suppression>74 or u.morale<34 or self.crossfire_pressure(u)>.55) and getattr(u,'fallback_point',None):
        fp=u.fallback_point
        if self.passable(*fp,u):
            if u.deployed and u.role in ('Machine Gunner','HMG Crew'):self.toggle_deploy(u);return
            self.issue_move([u],fp,mode='safe',formation='column');return
    _old_ai_decide(self,u)
RealTimeGame.ai_decide=_kz_ai_decide


_old_update=RealTimeGame.update
def _kz_update(self,dt):
    if self.paused or self.victory or self.defeat:return
    t0=time.perf_counter();self._path_budget=3;self._perf['path_ms']=0.0;self._perf['paths']=0;self._perf['ai_ms']=0.0;self._perf['ai_decisions']=0
    _kz_rebuild_indexes(self)
    _old_update(self,dt)
    self.update_assault_orders(dt)
    for puff in list(self.dust):
        puff.life-=dt
        if puff.life<=0:self.dust.remove(puff)
    _kz_rebuild_indexes(self)
    self._perf['sim_ms']=(time.perf_counter()-t0)*1000
RealTimeGame.update=_kz_update


# ------------------------------- App/UI/camera extension ----------------------
_old_app_init=KillZoneApp.__init__
def _kz_app_init(self):
    _old_app_init(self)
    self.camera_x=0.0;self.camera_y=max(0.0,MAP_H/2-10);self.zoom=1.0
    self.zoom_levels=[.72,.85,1.0,1.18,1.35];self.camera_drag=None
    self.preview_cell=None;self.preview_path=[];self.preview_at=0.0;self.preview_eta=0.0
    self.seed_text='';self.seed_active=False;self.setup_reserves=0
    self.deployment_active=False;self.show_perf=False;self.fps_cap=0
    self.shake_until=0.0;self.shake_strength=0.0;self.shake_offset=(0,0)
    self._audio_last={};self._audio_window_start=0.0;self._audio_count=0
    self.after_action_open=False;self._overlay_cache={}
KillZoneApp.__init__=_kz_app_init


def _kz_tile_px(self):return max(14,int(TILE*self.zoom))
def _kz_map_rect(self):return pygame.Rect(MAP_X,MAP_Y,MAP_VIEW_W_PX,MAP_VIEW_H_PX)
KillZoneApp.tile_px=property(_kz_tile_px)
KillZoneApp.map_view_rect=_kz_map_rect


def _kz_clamp_camera(self):
    tp=self.tile_px;vw=MAP_VIEW_W_PX/tp;vh=MAP_VIEW_H_PX/tp
    self.camera_x=clamp(self.camera_x,0,max(0,MAP_W-vw));self.camera_y=clamp(self.camera_y,0,max(0,MAP_H-vh))
KillZoneApp.clamp_camera=_kz_clamp_camera


def _kz_world_to_screen(self,x,y):
    tp=self.tile_px;ox,oy=self.shake_offset
    return (int(MAP_X+(x-self.camera_x)*tp+tp/2+ox),int(MAP_Y+(y-self.camera_y)*tp+tp/2+oy))
def _kz_screen_to_world(self,pos):
    if not self.map_view_rect().collidepoint(pos):return None
    tp=self.tile_px;x=self.camera_x+(pos[0]-MAP_X)/tp;y=self.camera_y+(pos[1]-MAP_Y)/tp
    return (x,y)
KillZoneApp.world_to_screen=_kz_world_to_screen
KillZoneApp.screen_to_world=_kz_screen_to_world


def _kz_map_cell_from_mouse(self,pos):
    w=self.screen_to_world(pos)
    if not w:return None
    x=int(math.floor(w[0]));y=int(math.floor(w[1]))
    return (x,y) if 0<=x<MAP_W and 0<=y<MAP_H else None
KillZoneApp.map_cell_from_mouse=_kz_map_cell_from_mouse


def _kz_unit_at_pixel(self,pos):
    best=None;bd=999
    for u in self.game.units:
        if not u.alive:continue
        if u.faction=='enemy' and not self.game.visible_to('player',u):continue
        sx,sy=self.world_to_screen(u.x,u.y);d=math.hypot(pos[0]-sx,pos[1]-sy)
        if d<max(10,self.tile_px*.55) and d<bd:best=u;bd=d
    return best
KillZoneApp.unit_at_pixel=_kz_unit_at_pixel


def _kz_cell_rect(self,x,y):
    tp=self.tile_px;ox,oy=self.shake_offset
    return pygame.Rect(int(MAP_X+(x-self.camera_x)*tp+ox),int(MAP_Y+(y-self.camera_y)*tp+oy),tp,tp)
KillZoneApp.cell_rect=_kz_cell_rect


def _kz_visible_bounds(self):
    tp=self.tile_px
    x0=max(0,int(math.floor(self.camera_x))-1);y0=max(0,int(math.floor(self.camera_y))-1)
    x1=min(MAP_W,int(math.ceil(self.camera_x+MAP_VIEW_W_PX/tp))+1);y1=min(MAP_H,int(math.ceil(self.camera_y+MAP_VIEW_H_PX/tp))+1)
    return x0,y0,x1,y1
KillZoneApp.visible_bounds=_kz_visible_bounds


def _kz_focus_selected(self):
    us=self.selected_units()
    if not us:return
    cx=sum(u.x for u in us)/len(us);cy=sum(u.y for u in us)/len(us);tp=self.tile_px
    self.camera_x=cx-(MAP_VIEW_W_PX/tp)/2;self.camera_y=cy-(MAP_VIEW_H_PX/tp)/2;self.clamp_camera()
KillZoneApp.focus_selected=_kz_focus_selected


def _kz_zoom(self,delta,anchor=None):
    old=self.zoom;idx=min(range(len(self.zoom_levels)),key=lambda i:abs(self.zoom_levels[i]-old));idx=int(clamp(idx+delta,0,len(self.zoom_levels)-1));new=self.zoom_levels[idx]
    if new==old:return
    anchor=anchor or (MAP_X+MAP_VIEW_W_PX//2,MAP_Y+MAP_VIEW_H_PX//2);before=self.screen_to_world(anchor)
    self.zoom=new
    if before:
        tp=self.tile_px;self.camera_x=before[0]-(anchor[0]-MAP_X)/tp;self.camera_y=before[1]-(anchor[1]-MAP_Y)/tp
    self.clamp_camera();self.preview_cell=None
KillZoneApp.change_zoom=_kz_zoom


def _kz_update_camera(self,dt):
    if self.state not in ('game','deployment'):return
    keys=pygame.key.get_pressed();speed=13*dt/max(.72,self.zoom)
    if keys[pygame.K_LEFT]:self.camera_x-=speed
    if keys[pygame.K_RIGHT]:self.camera_x+=speed
    if keys[pygame.K_UP]:self.camera_y-=speed
    if keys[pygame.K_DOWN]:self.camera_y+=speed
    mx,my=self.mouse;mr=self.map_view_rect();edge=8
    if mr.collidepoint(self.mouse) and not self.drag_start:
        if mx<mr.left+edge:self.camera_x-=speed*.7
        elif mx>mr.right-edge:self.camera_x+=speed*.7
        if my<mr.top+edge:self.camera_y-=speed*.7
        elif my>mr.bottom-edge:self.camera_y+=speed*.7
    self.clamp_camera()
KillZoneApp.update_camera=_kz_update_camera


_old_play_event=KillZoneApp.play_event
def _kz_play_event(self,ev):
    # Heavy automatic fire can otherwise spend more time mixing dozens of near-identical
    # samples than simulating combat. Keep impacts responsive while capping audio spam.
    now=time.perf_counter()
    if now-self._audio_window_start>.05:self._audio_window_start=now;self._audio_count=0
    typ=ev.get('type','');minimum=.025 if typ=='shot' else .05
    if now-self._audio_last.get(typ,-99)<minimum:return
    if self._audio_count>=5:return
    self._audio_last[typ]=now;self._audio_count+=1
    if typ=='explosion':
        pos=ev.get('pos')
        if pos:
            sx,sy=self.world_to_screen(*pos);near=self.map_view_rect().inflate(180,180).collidepoint((sx,sy))
        else:near=True
        if near:self.shake_until=time.time()+.22;self.shake_strength=max(self.shake_strength,4.0)
    _old_play_event(self,ev)
KillZoneApp.play_event=_kz_play_event


def _kz_setup_rects(self):
    x=WINDOW_W//2-330
    return {'easy':pygame.Rect(x,158,200,44),'hard':pygame.Rect(x+230,158,200,44),'veteran':pygame.Rect(x+460,158,200,44),
            'seed':pygame.Rect(x,226,300,38),'reserve_minus':pygame.Rect(x+430,226,38,38),'reserve_plus':pygame.Rect(x+565,226,38,38),
            'balanced':pygame.Rect(WINDOW_W//2-310,660,190,42),'clear':pygame.Rect(WINDOW_W//2-95,660,190,42),'start':pygame.Rect(WINDOW_W//2+120,660,190,42),'back':pygame.Rect(WINDOW_W//2-95,714,190,40)}
KillZoneApp.setup_rects=_kz_setup_rects


def _kz_roster_rects(self):
    rects={};left=74;right=WINDOW_W//2+25;top=286;row_h=57
    for i,role in enumerate(PLAYER_ROLE_ORDER):
        col=0 if i<6 else 1;row=i if i<6 else i-6;x=left if col==0 else right;y=top+row*row_h
        rects[(role,'minus')]=pygame.Rect(x+438,y+6,34,32);rects[(role,'plus')]=pygame.Rect(x+522,y+6,34,32)
    return rects
KillZoneApp.roster_rects=_kz_roster_rects


def _kz_draw_setup(self):
    self.draw_menu_background();title=self.get_font(46).render('SKIRMISH SETUP',True,COLORS['white']);self.screen.blit(title,(WINDOW_W//2-title.get_width()//2,45))
    x=WINDOW_W//2-330;self.text('DIFFICULTY',(x,128),14,'muted')
    for name,r in self.setup_rects().items():
        if name in ('easy','hard','veteran'):
            sel=self.setup_difficulty.lower()==name;self.button(r,('[ '+name.upper()+' ]') if sel else name.upper(),self.mouse,accent=sel)
    lo,hi={'Easy':(6,10),'Hard':(9,13),'Veteran':(12,16)}[self.setup_difficulty]
    self.text(f'Estimated opposition: {lo}–{hi} troops. Difficulty changes tactics, not weapon accuracy.',(x,207),12,'text')
    seedr=self.setup_rects()['seed'];pygame.draw.rect(self.screen,COLORS['panel2'],seedr,border_radius=3);pygame.draw.rect(self.screen,COLORS['select'] if self.seed_active else COLORS['muted'],seedr,2,border_radius=3)
    self.text('MAP SEED: '+(self.seed_text or 'RANDOM'),(seedr.x+10,seedr.y+10),13,'white')
    self.text(f'RESERVES: {self.setup_reserves}',(x+330,237),14,'white');self.button(self.setup_rects()['reserve_minus'],'-',self.mouse,enabled=self.setup_reserves>0);self.button(self.setup_rects()['reserve_plus'],'+',self.mouse,enabled=self.setup_reserves<min(6,max(0,sum(self.setup_roster.values())-1)))
    total=sum(self.setup_roster.values());self.text(f'FORCE ROSTER  {total}/{MAX_PLAYER_UNITS}',(74,260),18,'white')
    rr=self.roster_rects();left=74;right=WINDOW_W//2+25;top=286;row_h=57
    for i,role in enumerate(PLAYER_ROLE_ORDER):
        col=0 if i<6 else 1;row=i if i<6 else i-6;x0=left if col==0 else right;y=top+row*row_h
        panel=pygame.Rect(x0,y,570,45);pygame.draw.rect(self.screen,COLORS['panel'],panel,border_radius=4);pygame.draw.rect(self.screen,COLORS['muted'],panel,1,border_radius=4)
        self.text(role,(x0+12,y+13),14,'white');cnt=self.setup_roster.get(role,0);self.text(str(cnt),(x0+486,y+12),16,'select' if cnt else 'muted')
        self.button(rr[(role,'minus')],'-',self.mouse,enabled=cnt>0);self.button(rr[(role,'plus')],'+',self.mouse,enabled=(cnt<MAX_ROLE_COUNT and total<MAX_PLAYER_UNITS))
    r=self.setup_rects();self.button(r['balanced'],'BALANCED PRESET',self.mouse);self.button(r['clear'],'CLEAR',self.mouse);self.button(r['start'],'DEPLOY FORCE',self.mouse,enabled=total>0,accent=total>0);self.button(r['back'],'BACK',self.mouse)
KillZoneApp.draw_setup=_kz_draw_setup


def _kz_begin_deployment(self):
    roster=self.current_setup_roster()
    if not roster:return
    seed=int(self.seed_text) if self.seed_text.isdigit() else None
    self.battle_roster=list(roster);self.game=RealTimeGame(seed=seed,difficulty=self.setup_difficulty,player_roster=roster,reserve_count=self.setup_reserves)
    self.selected=[];self.command_mode='normal';self.show_threat=False;self.show_help=False;self.control_groups={i:[] for i in range(1,10)}
    self.deployment_active=True;self.battle_active=False;self.state='deployment';self.camera_x=0;self.camera_y=max(0,MAP_H/2-10);self.clamp_camera()
KillZoneApp.start_battle=_kz_begin_deployment


def _kz_finalize_deployment(self):
    self.deployment_active=False;self.battle_active=True;self.state='game';self.game.time=0;self.speed=self.menu_speed;self.show_help=self.menu_show_help
    self.game.add_log('Deployment complete. Battle started.')
KillZoneApp.finalize_deployment=_kz_finalize_deployment


def _kz_handle_setup_event(self,e):
    if e.type==pygame.QUIT:self.running=False;return
    if e.type==pygame.KEYDOWN:
        if e.key==pygame.K_ESCAPE:self.state='menu';self.seed_active=False;return
        if self.seed_active:
            if e.key==pygame.K_BACKSPACE:self.seed_text=self.seed_text[:-1]
            elif e.key==pygame.K_RETURN:self.seed_active=False
            elif e.unicode.isdigit() and len(self.seed_text)<9:self.seed_text+=e.unicode
            return
    if e.type!=pygame.MOUSEBUTTONDOWN or e.button!=1:return
    if self.setup_rects()['seed'].collidepoint(e.pos):self.seed_active=True;return
    self.seed_active=False;total=sum(self.setup_roster.values())
    for (role,action),r in self.roster_rects().items():
        if r.collidepoint(e.pos):
            cnt=self.setup_roster.get(role,0)
            if action=='minus' and cnt>0:self.setup_roster[role]=cnt-1;self.setup_reserves=min(self.setup_reserves,max(0,total-2))
            elif action=='plus' and cnt<MAX_ROLE_COUNT and total<MAX_PLAYER_UNITS:self.setup_roster[role]=cnt+1
            return
    for name,r in self.setup_rects().items():
        if not r.collidepoint(e.pos):continue
        if name in ('easy','hard','veteran'):self.setup_difficulty=name.title()
        elif name=='balanced':self.setup_roster={role:DEFAULT_PLAYER_ROSTER.count(role) for role in PLAYER_ROLE_ORDER};self.setup_reserves=0
        elif name=='clear':self.setup_roster={role:0 for role in PLAYER_ROLE_ORDER};self.setup_reserves=0
        elif name=='reserve_minus':self.setup_reserves=max(0,self.setup_reserves-1)
        elif name=='reserve_plus':self.setup_reserves=min(6,max(0,total-1),self.setup_reserves+1)
        elif name=='start':self.start_battle()
        elif name=='back':self.state='menu'
        return
KillZoneApp.handle_setup_event=_kz_handle_setup_event


def _kz_deploy_click(self,cell):
    if not cell or cell[0]>self.game.deployment_zone_x:return
    us=self.selected_units()
    if not us:return
    offs=self.game.formation_offsets(len(us),self.formation)
    occupied={u.tile for u in self.game.living('player') if u.uid not in {x.uid for x in us}}
    for u,(ox,oy) in zip(us,offs):
        x=int(clamp(round(cell[0]+ox),1,self.game.deployment_zone_x));y=int(clamp(round(cell[1]+oy),1,MAP_H-2))
        if (x,y) in occupied or not self.game.passable(x,y,u):continue
        u.x,u.y=x,y;u.path=[];u.waypoints=[];u.order='idle';occupied.add((x,y))
    _kz_rebuild_indexes(self.game)
KillZoneApp.deploy_click=_kz_deploy_click


def _kz_unit_cards(self):
    units=[u for u in self.game.living('player') if u.combat_effective]
    x=MAP_X;y=MAP_Y+MAP_VIEW_H_PX+39;w=65;h=39
    return [(u,pygame.Rect(x+i*(w+3),y,w,h)) for i,u in enumerate(units[:16])]
KillZoneApp.unit_card_rects=_kz_unit_cards


def _kz_squad_rects(self):
    x=MAP_X;y=MAP_Y+MAP_VIEW_H_PX+5;out={'ALL':pygame.Rect(x,y,78,28)}
    squads=sorted(set(getattr(u,'squad_id',0) for u in self.game.living('player') if u.combat_effective))
    for i,sq in enumerate(squads[:5]):out[sq]=pygame.Rect(x+86+i*88,y,80,28)
    return out
KillZoneApp.squad_rects=_kz_squad_rects


def _kz_command_rects(self):
    labels=['ASSAULT','SUPPRESS','OVERWATCH','GRENADE','SMOKE','RELOAD','STANCE','FORMATION','DISCIPLINE','PRIORITY','BOUND','AUTO']
    gap=3;x=MAP_X;y=MAP_Y+MAP_VIEW_H_PX+84;w=(WINDOW_W-MAP_X*2-gap*(len(labels)-1))//len(labels)
    return {lab:pygame.Rect(x+i*(w+gap),y,w,31) for i,lab in enumerate(labels)}
KillZoneApp.command_bar_rects=_kz_command_rects


def _kz_handle_command_bar(self,pos):
    us=self.selected_units()
    for name,r in self.command_bar_rects().items():
        if not r.collidepoint(pos):continue
        if name=='ASSAULT':self.command_mode='assault'
        elif not us:return True
        elif name=='SUPPRESS':self.command_mode='suppress'
        elif name=='OVERWATCH':
            for u in us:self.game.set_overwatch(u,angle_to(u,self.map_cell_from_mouse(self.mouse) or u.tile),100)
        elif name=='GRENADE':self.command_mode='grenade'
        elif name=='SMOKE':self.command_mode='smoke'
        elif name=='RELOAD':
            for u in us:self.game.start_reload(u)
        elif name=='STANCE':
            for u in us:self.game.cycle_stance(u)
        elif name=='FORMATION':self.cycle_formation()
        elif name=='DISCIPLINE':self.cycle_discipline(us)
        elif name=='PRIORITY':self.cycle_priority(us)
        elif name=='BOUND':self.command_mode='bound'
        elif name=='AUTO':
            new=not all(u.auto_reload and u.auto_cover and u.auto_smoke and u.auto_medic for u in us)
            for u in us:u.auto_reload=u.auto_cover=u.auto_smoke=u.auto_medic=new
        return True
    return False
KillZoneApp.handle_command_bar=_kz_handle_command_bar


_old_issue_context=KillZoneApp.issue_context_command
def _kz_issue_context(self,cell,append=False):
    us=self.selected_units()
    if self.command_mode=='assault' and us:
        t=self.game.unit_at(*cell);uid=t.uid if t and t.faction=='enemy' else None
        self.game.assault_position(us,cell,uid);self.command_mode='normal';return
    # Re-crew context before generic friendly casualty handling.
    t=self.game.unit_at(*cell)
    if t and t.faction=='player' and us:
        for u in us:
            if u.uid!=t.uid and self.game.recrew_weapon(u,t):return
    _old_issue_context(self,cell,append=append)
KillZoneApp.issue_context_command=_kz_issue_context


def _kz_handle_deployment_event(self,e):
    if e.type==pygame.QUIT:self.running=False;return
    if e.type==pygame.KEYDOWN:
        if e.key in (pygame.K_RETURN,pygame.K_SPACE):self.finalize_deployment();return
        if e.key==pygame.K_ESCAPE:self.state='setup';return
        if e.key==pygame.K_F11:self.toggle_fullscreen();return
        if e.key==pygame.K_F4:self.cycle_formation();return
    if e.type==pygame.MOUSEWHEEL:self.change_zoom(-1 if e.y<0 else 1,self.mouse);return
    if e.type==pygame.MOUSEBUTTONDOWN:
        if e.button==2:self.camera_drag=(e.pos,self.camera_x,self.camera_y);return
        if e.button==1:
            for u,r in self.unit_card_rects():
                if r.collidepoint(e.pos):self.select(u,add=bool(pygame.key.get_mods()&pygame.KMOD_SHIFT));return
            for key,r in self.squad_rects().items():
                if r.collidepoint(e.pos):
                    if key=='ALL':self.selected=[u.uid for u in self.game.living('player') if u.combat_effective]
                    else:self.selected=[u.uid for u in self.game.living('player') if u.combat_effective and getattr(u,'squad_id',0)==key]
                    return
            u=self.unit_at_pixel(e.pos)
            if u and u.faction=='player':self.select(u,add=bool(pygame.key.get_mods()&pygame.KMOD_SHIFT));return
            self.drag_start=e.pos;self.drag_additive=bool(pygame.key.get_mods()&pygame.KMOD_SHIFT)
        elif e.button==3:self.deploy_click(self.map_cell_from_mouse(e.pos));return
    if e.type==pygame.MOUSEBUTTONUP:
        if e.button==2:self.camera_drag=None;return
        if e.button==1 and self.drag_start:
            x1,x2=sorted((self.drag_start[0],e.pos[0]));y1,y2=sorted((self.drag_start[1],e.pos[1]))
            if max(x2-x1,y2-y1)>5:
                if not self.drag_additive:self.selected=[]
                for u in self.game.living('player'):
                    sx,sy=self.world_to_screen(u.x,u.y)
                    if x1<=sx<=x2 and y1<=sy<=y2 and u.uid not in self.selected:self.selected.append(u.uid)
            self.drag_start=None;self.drag_additive=False
    if e.type==pygame.MOUSEMOTION and self.camera_drag:
        (sx,sy),cx,cy=self.camera_drag;tp=self.tile_px;self.camera_x=cx-(e.pos[0]-sx)/tp;self.camera_y=cy-(e.pos[1]-sy)/tp;self.clamp_camera()
KillZoneApp.handle_deployment_event=_kz_handle_deployment_event


_old_handle_event=KillZoneApp.handle_event
def _kz_handle_event(self,e):
    self.mouse=self.display_to_logical(pygame.mouse.get_pos())
    if self.state=='deployment':return self.handle_deployment_event(e)
    if self.state in ('menu','setup','settings','help'):return _old_handle_event(self,e)
    if e.type==pygame.MOUSEWHEEL:self.change_zoom(-1 if e.y<0 else 1,self.mouse);return
    if e.type==pygame.MOUSEBUTTONUP and e.button==1 and self.drag_start:
        if max(abs(e.pos[0]-self.drag_start[0]),abs(e.pos[1]-self.drag_start[1]))>8:
            mr=self.map_view_rect();sx=int(clamp(self.drag_start[0],mr.left,mr.right));sy=int(clamp(self.drag_start[1],mr.top,mr.bottom));ex=int(clamp(e.pos[0],mr.left,mr.right));ey=int(clamp(e.pos[1],mr.top,mr.bottom));x1,x2=sorted((sx,ex));y1,y2=sorted((sy,ey))
            if not self.drag_additive:self.selected=[]
            for u in self.game.living('player'):
                px,py=self.world_to_screen(u.x,u.y)
                if x1<=px<=x2 and y1<=py<=y2 and u.uid not in self.selected:self.selected.append(u.uid)
        self.drag_start=None;self.drag_additive=False;return
    if e.type==pygame.MOUSEBUTTONDOWN and e.button==2:self.camera_drag=(e.pos,self.camera_x,self.camera_y);return
    if e.type==pygame.MOUSEBUTTONUP and e.button==2:self.camera_drag=None;return
    if e.type==pygame.MOUSEMOTION and self.camera_drag:
        (sx,sy),cx,cy=self.camera_drag;tp=self.tile_px;self.camera_x=cx-(e.pos[0]-sx)/tp;self.camera_y=cy-(e.pos[1]-sy)/tp;self.clamp_camera();return
    if e.type==pygame.MOUSEBUTTONDOWN and e.button==1:
        for u,r in self.unit_card_rects():
            if r.collidepoint(e.pos):self.select(u,add=bool(pygame.key.get_mods()&pygame.KMOD_SHIFT));return
        for key,r in self.squad_rects().items():
            if r.collidepoint(e.pos):
                if key=='ALL':self.selected=[u.uid for u in self.game.living('player') if u.combat_effective]
                else:self.selected=[u.uid for u in self.game.living('player') if u.combat_effective and getattr(u,'squad_id',0)==key]
                return
    _old_handle_event(self,e)
KillZoneApp.handle_event=_kz_handle_event


_old_handle_key=KillZoneApp.handle_key
def _kz_handle_key(self,key,mods):
    if key==pygame.K_HOME:self.focus_selected();return
    if key==pygame.K_F2:self.command_mode='assault';return
    if key==pygame.K_F12:
        new=self.game.deploy_player_reserves();self.selected=[u.uid for u in new];return
    if key==pygame.K_F9 and not (mods&pygame.KMOD_SHIFT):
        self.show_perf=not self.show_perf;return
    if pygame.K_1<=key<=pygame.K_5 and (mods & pygame.KMOD_ALT):
        sq=key-pygame.K_0
        for u in self.selected_units():u.squad_id=sq
        self.message=f'Assigned selection to Squad {chr(64+sq)}';return
    if key==pygame.K_F5:
        self.game=RealTimeGame(difficulty=self.game.difficulty,player_roster=self.battle_roster,reserve_count=self.setup_reserves);self.selected=[];self.camera_x=0;self.camera_y=max(0,MAP_H/2-10);return
    if key==pygame.K_F6:
        ds=['Easy','Hard','Veteran'];d=ds[(ds.index(self.game.difficulty)+1)%3];self.game=RealTimeGame(difficulty=d,player_roster=self.battle_roster,reserve_count=self.setup_reserves);self.selected=[];self.camera_x=0;self.camera_y=max(0,MAP_H/2-10);return
    _old_handle_key(self,key,mods)
KillZoneApp.handle_key=_kz_handle_key


def _kz_update_preview(self):
    if self.state!='game' or not self.selected:return
    cell=self.map_cell_from_mouse(self.mouse)
    if not cell:return
    now=time.time()
    if cell==self.preview_cell and now-self.preview_at<.12:return
    self.preview_cell=cell;self.preview_at=now;self.preview_path=[];self.preview_eta=0
    u=self.selected_units()[0] if self.selected_units() else None
    t=self.game.unit_at(*cell)
    if u and (not t or t.faction!='enemy'):
        self.game._path_budget=max(1,self.game._path_budget)
        path=self.game.find_path(u,cell,u.move_mode);self.preview_path=path
        if path:
            cost=0
            prev=u.tile
            for x,y in path:
                cost+=TERRAIN[self.game.grid[y][x].terrain]['move'];prev=(x,y)
            self.preview_eta=cost/max(.1,ROLES[u.role]['speed']*STANCE[u.stance]['speed'])
KillZoneApp.update_preview=_kz_update_preview


def _kz_draw_selection_box(self):
    if not self.drag_start:return
    if max(abs(self.mouse[0]-self.drag_start[0]),abs(self.mouse[1]-self.drag_start[1]))<=5:return
    mr=self.map_view_rect();sx=int(clamp(self.drag_start[0],mr.left,mr.right));sy=int(clamp(self.drag_start[1],mr.top,mr.bottom));ex=int(clamp(self.mouse[0],mr.left,mr.right));ey=int(clamp(self.mouse[1],mr.top,mr.bottom))
    x1,x2=sorted((sx,ex));y1,y2=sorted((sy,ey));r=pygame.Rect(x1,y1,max(1,x2-x1),max(1,y2-y1));fill=pygame.Surface(r.size,pygame.SRCALPHA);fill.fill((229,210,119,28));self.screen.blit(fill,r.topleft);pygame.draw.rect(self.screen,COLORS['select'],r,2)
KillZoneApp.draw_selection_box=_kz_draw_selection_box


def _kz_draw_unit(self,u):
    cx,cy=self.world_to_screen(u.x,u.y);tp=self.tile_px
    if not self.map_view_rect().inflate(30,30).collidepoint((cx,cy)):return
    if u.casualty=='dead':pygame.draw.line(self.screen,(65,47,42),(cx-6,cy-6),(cx+6,cy+6),2);pygame.draw.line(self.screen,(65,47,42),(cx+6,cy-6),(cx-6,cy+6),2);return
    friend=u.faction=='player';fill=COLORS['nato_friend'] if friend else COLORS['nato_hostile'];ink=COLORS['black'];sw=max(16,int(tp*.85));sh=max(12,int(tp*.56))
    if friend:
        r=pygame.Rect(cx-sw//2,cy-sh//2,sw,sh);pygame.draw.rect(self.screen,fill,r);pygame.draw.rect(self.screen,ink,r,2);pygame.draw.line(self.screen,ink,(r.left+2,r.top+2),(r.right-2,r.bottom-2),2);pygame.draw.line(self.screen,ink,(r.right-2,r.top+2),(r.left+2,r.bottom-2),2)
    else:
        rad=max(9,int(tp*.42));pts=[(cx,cy-rad),(cx+rad,cy),(cx,cy+rad),(cx-rad,cy)];pygame.draw.polygon(self.screen,fill,pts);pygame.draw.polygon(self.screen,ink,pts,2);pygame.draw.line(self.screen,ink,(cx-6,cy-6),(cx+6,cy+6),2);pygame.draw.line(self.screen,ink,(cx+6,cy-6),(cx-6,cy+6),2)
    role={'Rifleman':'RF','Machine Gunner':'MG','Sniper':'SN','Medic':'MED','Engineer':'ENG','Recon':'REC','Grenadier':'GRN','Assault':'ASLT','Automatic Rifleman':'AR','Marksman':'DMR','HMG Crew':'HMG','Mortar Team':'MTR'}.get(u.role,'INF')
    surf=self.get_font(10 if tp<24 else 12).render(role,True,COLORS['white']);self.screen.blit(surf,(cx-surf.get_width()//2,cy+max(8,sh//2+2)))
    if u.uid in self.selected:pygame.draw.circle(self.screen,COLORS['select'],(cx,cy),max(14,int(tp*.60)),2)
    ang=math.radians(u.facing);pygame.draw.line(self.screen,COLORS['white'],(cx,cy),(cx+math.cos(ang)*max(11,tp*.48),cy+math.sin(ang)*max(11,tp*.48)),1)
    bw=max(20,int(tp*.85));pygame.draw.rect(self.screen,(30,30,28),(cx-bw//2,cy+max(17,int(tp*.78)),bw,3));pygame.draw.rect(self.screen,COLORS['good'],(cx-bw//2,cy+max(17,int(tp*.78)),int(bw*clamp(u.hp/u.max_hp,0,1)),3))
    if u.suppression>12:
        # Highly legible suppression halo: yellow -> orange -> red as pinning approaches.
        col=COLORS['contact'] if u.suppression<55 else COLORS['suppression'] if u.suppression<80 else COLORS['danger'];pygame.draw.circle(self.screen,col,(cx,cy),max(15,int(tp*.64)),1 if u.suppression<55 else 2)
    status=''
    if u.reload_timer>0:status='RLD'
    elif u.jammed:status='JAM'
    elif u.order=='rout' or u.morale<16:status='BRK'
    elif u.suppression>=80:status='PIN'
    elif self.game.time<u.disoriented_until:status='CON'
    elif u.order=='suppress':status='SUP'
    elif u.overwatch:status='OW'
    elif u.order=='move':status='MOV'
    if status:
        ss=self.get_font(10).render(status,True,COLORS['status']);self.screen.blit(ss,(cx-ss.get_width()//2,cy-max(21,int(tp*.8))))
KillZoneApp.draw_unit=_kz_draw_unit


def _kz_draw_arc(self,u):
    center=self.world_to_screen(u.x,u.y);radius=int(u.arc_range*self.tile_px);a1=math.radians(u.fire_lane_center-u.arc_width/2);a2=math.radians(u.fire_lane_center+u.arc_width/2);col=COLORS['danger'] if u.faction=='enemy' else COLORS['contact']
    pygame.draw.line(self.screen,col,center,(center[0]+math.cos(a1)*radius,center[1]+math.sin(a1)*radius),1);pygame.draw.line(self.screen,col,center,(center[0]+math.cos(a2)*radius,center[1]+math.sin(a2)*radius),1)
KillZoneApp.draw_arc=_kz_draw_arc


def _kz_draw_previews(self):
    us=self.selected_units();cell=self.map_cell_from_mouse(self.mouse)
    if not us or not cell:return
    u=us[0];target=self.game.unit_at(*cell)
    if target and target.faction=='enemy' and self.game.visible_to('player',target):
        a=self.world_to_screen(u.x,u.y);b=self.world_to_screen(target.x,target.y);clear,smoke,soft,_=self.game.line_info(u.pos,target.pos);hc=self.game.hit_chance(u,target)
        col=COLORS['good'] if clear and hc>=55 else COLORS['contact'] if clear and hc>0 else COLORS['danger'];pygame.draw.line(self.screen,col,a,b,2)
        tx,ty=self.mouse;box=pygame.Rect(min(tx+14,WINDOW_W-260),min(ty+14,WINDOW_H-92),245,78);pygame.draw.rect(self.screen,COLORS['panel'],box);pygame.draw.rect(self.screen,col,box,2)
        self.text(f'HIT {hc:.0f}%   RANGE {dist(u,target):.1f}/{u.weapon["range"]:.0f}',(box.x+8,box.y+8),12,'white');self.text(f'cover {self.game.effective_cover(u,target):.1f}  smoke {smoke:.1f}  pen {soft}',(box.x+8,box.y+28),12,'muted');self.text(f'target {target.role} — {"PINNED" if target.suppression>=80 else "SUPPRESSED" if target.suppression>=50 else "UNDER FIRE" if target.suppression>=20 else "CALM"}',(box.x+8,box.y+48),12,'contact')
    elif self.preview_path:
        pts=[self.world_to_screen(u.x,u.y)]+[self.world_to_screen(x,y) for x,y in self.preview_path]
        for i in range(1,len(pts)):
            x,y=self.preview_path[i-1];th=self.game.tile_threat('player',x,y);col=COLORS['good'] if th<.6 else COLORS['contact'] if th<1.4 else COLORS['danger'];pygame.draw.line(self.screen,col,pts[i-1],pts[i],2)
        if pts:self.text(f'{u.move_mode.upper()}  ETA {self.preview_eta:.1f}s',(min(self.mouse[0]+12,WINDOW_W-170),max(MAP_Y,self.mouse[1]-22)),12,'white')
KillZoneApp.draw_tactical_previews=_kz_draw_previews


def _kz_draw_directional_cover(self,cell):
    if not cell:return
    x,y=cell;c=self.game.grid[y][x];r=self.cell_rect(x,y);base=max(0,TERRAIN[c.terrain]['cover']-c.cover_wear*2.2)
    # Trench axis produces very strong cross-face protection and weak enfilade protection.
    vals={'N':base,'S':base,'E':base,'W':base}
    if c.terrain in ('trench','firing_step') and c.axis:
        if c.axis=='H':vals.update({'N':5,'S':5,'E':1,'W':1})
        else:vals.update({'E':5,'W':5,'N':1,'S':1})
    def col(v):return COLORS['good'] if v>=3 else COLORS['contact'] if v>=1 else COLORS['danger']
    pygame.draw.line(self.screen,col(vals['N']),(r.left+2,r.top+2),(r.right-2,r.top+2),3);pygame.draw.line(self.screen,col(vals['S']),(r.left+2,r.bottom-2),(r.right-2,r.bottom-2),3);pygame.draw.line(self.screen,col(vals['W']),(r.left+2,r.top+2),(r.left+2,r.bottom-2),3);pygame.draw.line(self.screen,col(vals['E']),(r.right-2,r.top+2),(r.right-2,r.bottom-2),3)
KillZoneApp.draw_directional_cover=_kz_draw_directional_cover


def _kz_draw_planned_orders(self):
    # Paused planning stays readable: current route and queued orders are numbered.
    for u in self.selected_units()[:8]:
        pts=[]
        if u.path:pts.extend(u.path)
        if u.waypoints:pts.extend(u.waypoints)
        last=self.world_to_screen(u.x,u.y)
        for i,(x,y) in enumerate(pts[:16],1):
            cur=self.world_to_screen(x,y);pygame.draw.line(self.screen,COLORS['blue'],last,cur,1)
            if i==len(pts) or i%4==0:
                ss=self.get_font(9).render(str(i),True,COLORS['white']);self.screen.blit(ss,(cur[0]+2,cur[1]-8))
            last=cur
        for qi,(kind,data) in enumerate(u.command_queue[:5],1):
            if kind=='move':
                cur=self.world_to_screen(*data);pygame.draw.circle(self.screen,COLORS['select'],cur,6,1);self.text(f'Q{qi}',(cur[0]+6,cur[1]-7),9,'select')
KillZoneApp.draw_planned_orders=_kz_draw_planned_orders


def _kz_overlay(self,size,color,alpha):
    key=(size,color,int(alpha)//8)
    surf=self._overlay_cache.get(key)
    if surf is None:
        surf=pygame.Surface(size,pygame.SRCALPHA);surf.fill((*color,int(clamp(alpha,0,255))));self._overlay_cache[key]=surf
        if len(self._overlay_cache)>96:self._overlay_cache.clear();self._overlay_cache[key]=surf
    return surf
KillZoneApp.overlay_surface=_kz_overlay


def _kz_draw_map(self):
    mr=self.map_view_rect();pygame.draw.rect(self.screen,COLORS['black'],mr);pygame.draw.rect(self.screen,COLORS['muted'],mr,1)
    self.update_preview();x0,y0,x1,y1=self.visible_bounds();keys=pygame.key.get_pressed()
    for y in range(y0,y1):
        for x in range(x0,x1):
            r=self.cell_rect(x,y)
            if not r.colliderect(mr):continue
            c=self.game.grid[y][x];pygame.draw.rect(self.screen,COLORS.get(c.terrain,COLORS['open']),r);self.draw_terrain(c,r,x,y)
            if c.ground_suppression>18:
                alpha=int(clamp(c.ground_suppression*1.1,20,105));self.screen.blit(self.overlay_surface((r.w,r.h),(190,105,45),alpha),r.topleft)
            if c.smoke>.05:
                self.screen.blit(self.overlay_surface((r.w,r.h),(190,190,185),int(clamp(c.smoke*38,20,165))),r.topleft)
            if c.fire>0:pygame.draw.circle(self.screen,COLORS['fire'],r.center,max(2,int(min(r.w,r.h)*.18)))
            if self.show_threat:
                th=self.game.tile_threat('player',x,y)
                if th>.25:
                    self.screen.blit(self.overlay_surface((r.w,r.h),(210,70,55),int(clamp(th*34,12,100))),r.topleft)
    # Blood and transient impacts only inside the visible viewport.
    for b in self.game.blood:
        sx,sy=self.world_to_screen(b.x,b.y)
        if mr.collidepoint((sx,sy)):pygame.draw.circle(self.screen,COLORS['blood_dark'],(sx,sy),max(2,int(b.size*self.tile_px*.45)))
    for puff in self.game.dust:
        sx,sy=self.world_to_screen(puff.x,puff.y)
        if mr.collidepoint((sx,sy)):
            alpha=int(120*clamp(puff.life/max(.01,puff.total),0,1));rad=max(2,int(puff.size*self.tile_px));surf=pygame.Surface((rad*2+2,rad*2+2),pygame.SRCALPHA);pygame.draw.circle(surf,(135,118,91,alpha),(rad+1,rad+1),rad);self.screen.blit(surf,(sx-rad-1,sy-rad-1))
    for t in self.game.tracers:
        a=self.world_to_screen(*t.a);b=self.world_to_screen(*t.b)
        if mr.clipline(a,b):pygame.draw.line(self.screen,(234,215,145),a,b,1)
    for i in self.game.impacts:
        sx,sy=self.world_to_screen(i.x,i.y)
        if mr.collidepoint((sx,sy)):pygame.draw.circle(self.screen,COLORS['impact'],(sx,sy),2)
    for uid,info,age in self.game.known_contacts('player',memory=10):
        u=self.game.get_unit(uid)
        if u and self.game.visible_to('player',u):continue
        sx,sy=self.world_to_screen(*info['pos'])
        if mr.collidepoint((sx,sy)):
            rad=int(5+age*1.2);pygame.draw.circle(self.screen,COLORS['contact'],(sx,sy),rad,1);self.text('?',(sx-3,sy-7),12,'contact')
    for u in self.game.units:
        if u.faction=='enemy' and u.alive and not self.game.visible_to('player',u):continue
        if u.overwatch or u.fire_lane:self.draw_arc(u)
        self.draw_unit(u)
    for e in self.game.explosions:
        sx,sy=self.world_to_screen(e.x,e.y)
        if mr.collidepoint((sx,sy)):pygame.draw.circle(self.screen,COLORS['danger'] if e.kind=='HE' else COLORS['smoke'],(sx,sy),int(e.radius*self.tile_px),1);self.text(f'{e.timer:.1f}',(sx-10,sy-8),12,'white')
    self.draw_tactical_previews()
    self.draw_planned_orders()
    if keys[pygame.K_LALT]:self.draw_directional_cover(self.map_cell_from_mouse(self.mouse))
    self.draw_selection_box()
    if self.game.victory or self.game.defeat:self.draw_after_action()
KillZoneApp.draw_map=_kz_draw_map


def _kz_draw_sidebar(self):
    x=SIDEBAR_X;pygame.draw.rect(self.screen,COLORS['panel'],(x,MAP_Y,WINDOW_W-x-12,MAP_VIEW_H_PX));self.text('SELECTED',(x+14,MAP_Y+10),18,'white');us=self.selected_units();y=MAP_Y+38
    if not us:self.text('No units selected',(x+14,y),13,'muted')
    else:
        firing=sum(1 for u in us if u.order=='fire');reloading=sum(1 for u in us if u.reload_timer>0);pinned=sum(1 for u in us if u.suppression>=80);wounded=sum(1 for u in us if u.casualty=='wounded')
        self.text(f'{len(us)} troops | fire {firing} rld {reloading} pin {pinned} wnd {wounded}',(x+14,y),11,'status');y+=20
        for u in us[:4]:
            self.text(f'SQ{getattr(u,"squad_id",0)} {u.role} #{u.uid}',(x+14,y),13,'select');y+=17;self.text(f'HP {u.hp:.0f}  MOR {u.morale:.0f}  SUP {u.suppression:.0f}  STA {u.stamina:.0f}',(x+14,y),11);y+=15;self.text(f'{u.weapon_name} {u.ammo} | {u.order} | {u.fire_discipline}',(x+14,y),11,'muted');y+=19
    self.text('FIELD REPORT',(x+14,max(y+4,MAP_Y+300)),15,'white');yy=max(y+24,MAP_Y+322)
    for line in self.game.log[-8:]:self.text(line[:42],(x+14,yy),11,'muted');yy+=16
    if pygame.key.get_pressed()[pygame.K_LALT]:
        cell=self.map_cell_from_mouse(self.mouse)
        if cell:
            cx,cy=cell;c=self.game.grid[cy][cx];td=TERRAIN[c.terrain];base=MAP_Y+MAP_VIEW_H_PX-96;pygame.draw.rect(self.screen,COLORS['panel2'],(x+8,base-5,WINDOW_W-x-28,88),border_radius=3);self.text('TILE INTEL [LALT]',(x+14,base),11,'select');self.text(f'{cell} {c.terrain.upper()} cover {td["cover"]} conceal {td["conceal"]}',(x+14,base+17),11,'white');self.text(f'move x{td["move"]:.2f} smoke {c.smoke:.1f} suppression {c.ground_suppression:.0f}',(x+14,base+34),11,'muted');self.text(f'known threat {self.game.tile_threat("player",cx,cy):.1f}',(x+14,base+51),11,'contact');self.text('edge colors: green strong / yellow partial / red open',(x+14,base+68),10,'muted')
KillZoneApp.draw_sidebar=_kz_draw_sidebar


def _kz_draw_bottom_ui(self):
    y0=MAP_Y+MAP_VIEW_H_PX+2;pygame.draw.rect(self.screen,COLORS['panel'],(0,y0,WINDOW_W,WINDOW_H-y0))
    for key,r in self.squad_rects().items():
        active=(key=='ALL' and len(self.selected)==len([u for u in self.game.living('player') if u.combat_effective])) or (key!='ALL' and self.selected and all(getattr(self.game.get_unit(i),'squad_id',-1)==key for i in self.selected if self.game.get_unit(i)))
        pygame.draw.rect(self.screen,COLORS['panel2'],r,border_radius=3);pygame.draw.rect(self.screen,COLORS['select'] if active else COLORS['muted'],r,1,border_radius=3);lab='ALL' if key=='ALL' else f'SQUAD {chr(64+int(key))}';ss=self.get_font(11).render(lab,True,COLORS['white']);self.screen.blit(ss,(r.centerx-ss.get_width()//2,r.centery-ss.get_height()//2))
    for u,r in self.unit_card_rects():
        sel=u.uid in self.selected;pygame.draw.rect(self.screen,COLORS['panel2'],r,border_radius=2);pygame.draw.rect(self.screen,COLORS['select'] if sel else COLORS['muted'],r,2 if sel else 1,border_radius=2);abbr={'Rifleman':'RF','Machine Gunner':'MG','Sniper':'SN','Medic':'MED','Engineer':'ENG','Recon':'REC','Grenadier':'GRN','Assault':'AS','Automatic Rifleman':'AR','Marksman':'DMR','HMG Crew':'HMG','Mortar Team':'MTR'}.get(u.role,'INF');self.text(abbr,(r.x+4,r.y+3),10,'white');self.text(f'{u.hp:.0f}',(r.x+4,r.y+18),9,'good' if u.hp>u.max_hp*.5 else 'danger');pygame.draw.rect(self.screen,(30,30,28),(r.x+30,r.y+20,30,3));pygame.draw.rect(self.screen,COLORS['contact'],(r.x+30,r.y+20,int(30*u.suppression/100),3))
    us=self.selected_units()
    if us:
        for name,r in self.command_bar_rects().items():
            pygame.draw.rect(self.screen,COLORS['panel2'],r,border_radius=3);pygame.draw.rect(self.screen,COLORS['muted'],r,1,border_radius=3);label=name
            if name=='FORMATION':label=self.formation.upper()
            elif name=='DISCIPLINE':label=us[0].fire_discipline.upper()
            elif name=='PRIORITY':label=us[0].target_priority.upper()
            elif name=='AUTO':label='AUTO ON' if all(u.auto_reload and u.auto_cover and u.auto_smoke and u.auto_medic for u in us) else 'AUTO OFF'
            ss=self.get_font(10).render(label,True,COLORS['select'] if name in ('ASSAULT','FORMATION') else COLORS['white']);self.screen.blit(ss,(r.centerx-ss.get_width()//2,r.centery-ss.get_height()//2))
KillZoneApp.draw_command_bar=_kz_draw_bottom_ui


def _kz_draw_topbar(self):
    pygame.draw.rect(self.screen,COLORS['panel'],(0,0,WINDOW_W,52));self.text('KILL ZONE',(18,10),26,'white');slow=self.state=='game' and pygame.key.get_pressed()[pygame.K_BACKQUOTE];status='DEPLOYMENT' if self.state=='deployment' else 'PAUSED — ORDERS CAN BE PLANNED' if self.game.paused else f'REALTIME ×{self.speed:g}{" TACTICAL SLOW" if slow else ""}';self.text(status,(190,18),13,'select' if self.game.paused or self.state=='deployment' else 'good');self.text(f'Seed {self.game.seed} | {self.game.weather.upper()} | zoom {self.zoom:.2f}x',(500,18),12,'muted');self.text(f'MODE {self.command_mode.upper()} | FORM {self.formation.upper()}',(820,18),12,'contact')
    if self.game.player_reserves:self.text(f'F12 RESERVES {len(self.game.player_reserves)}',(1100,18),11,'select')
    if self.show_fps:self.text(f'{self.clock.get_fps():.0f} FPS',(WINDOW_W-92,8),10,'good')
    if self.show_perf:self.text(f'SIM {self.game._perf.get("sim_ms",0):.2f}ms PATH {self.game._perf.get("path_ms",0):.2f}ms/{self.game._perf.get("paths",0)} AI {self.game._perf.get("ai_ms",0):.2f}ms',(WINDOW_W-350,29),9,'muted')
KillZoneApp.draw_topbar=_kz_draw_topbar


def _kz_draw_after_action(self):
    w,h=620,420;x=MAP_X+(MAP_VIEW_W_PX-w)//2;y=MAP_Y+55;pygame.draw.rect(self.screen,COLORS['panel'],(x,y,w,h));pygame.draw.rect(self.screen,COLORS['select'],(x,y,w,h),3);title='VICTORY' if self.game.victory else 'DEFEAT';self.text(title,(x+25,y+18),32,'white');self.text(f'Battle duration {self.game.time:.1f}s   Seed {self.game.seed}',(x+25,y+58),13,'muted')
    yy=y+95
    for f,label in [('player','YOUR FORCE'),('enemy','OPPOSITION')]:
        st=self.game.stats[f];alive=sum(1 for u in self.game.living(f) if u.combat_effective);self.text(label,(x+25,yy),16,'select');yy+=23;self.text(f'alive {alive}  casualties {st["casualties"]}  shots {st["shots"]}  hits {st["hits"]}  kills {st["kills"]}',(x+25,yy),12,'white');yy+=19;acc=(100*st['hits']/st['shots']) if st['shots'] else 0;self.text(f'accuracy {acc:.1f}%  grenades {st["grenades"]}  smoke {st["smoke"]}  reserves {st["reserves"]}',(x+25,yy),12,'muted');yy+=32
    self.text('RECENT TIMELINE',(x+25,yy),14,'select');yy+=22
    for ev in self.game.battle_events[-7:]:self.text(f'{ev["time"]:5.1f}s  {ev["text"]}'[:72],(x+25,yy),11,'muted');yy+=17
    self.text('F5 new battle • Esc menu',(x+25,y+h-28),11,'white')
KillZoneApp.draw_after_action=_kz_draw_after_action


def _kz_draw_deployment(self):
    self.draw_topbar();self.draw_map();self.draw_sidebar();self.draw_command_bar();overlay=pygame.Rect(MAP_X+220,MAP_Y+12,650,60);pygame.draw.rect(self.screen,COLORS['panel'],overlay);pygame.draw.rect(self.screen,COLORS['select'],overlay,2);self.text('PRE-BATTLE DEPLOYMENT',(overlay.x+12,overlay.y+8),16,'white');self.text('Select troops/squads, RMB inside west deployment zone to place. Enter/Space starts battle.',(overlay.x+12,overlay.y+31),11,'muted');x=int(MAP_X+(self.game.deployment_zone_x-self.camera_x)*self.tile_px);pygame.draw.line(self.screen,COLORS['select'],(x,MAP_Y),(x,MAP_Y+MAP_VIEW_H_PX),2)
KillZoneApp.draw_deployment=_kz_draw_deployment


_old_draw=KillZoneApp.draw
def _kz_draw(self):
    if self.state=='deployment':
        self.screen.fill(COLORS['bg']);self.draw_deployment();self.present();return
    if self.state=='game':
        self.screen.fill(COLORS['bg']);self.draw_topbar();self.draw_map();self.draw_sidebar();self.draw_command_bar();
        if self.show_help:self.draw_help()
        self.present();return
    _old_draw(self)
KillZoneApp.draw=_kz_draw


_old_settings_rects=KillZoneApp.settings_rects
def _kz_settings_rects(self):
    x=WINDOW_W//2-330
    return {'speed05':pygame.Rect(x,230,200,42),'speed1':pygame.Rect(x+230,230,200,42),'speed2':pygame.Rect(x+460,230,200,42),'help':pygame.Rect(WINDOW_W//2-165,305,330,40),'audio':pygame.Rect(WINDOW_W//2-165,353,330,40),'fps':pygame.Rect(WINDOW_W//2-165,401,330,40),'perf':pygame.Rect(WINDOW_W//2-165,449,330,40),'fpscap':pygame.Rect(WINDOW_W//2-165,497,330,40),'fullscreen':pygame.Rect(WINDOW_W//2-165,545,330,40),'back':pygame.Rect(WINDOW_W//2-150,610,300,46)}
KillZoneApp.settings_rects=_kz_settings_rects


_old_handle_settings=KillZoneApp.handle_settings_event
def _kz_handle_settings(self,e):
    if e.type==pygame.QUIT:self.running=False;return
    if e.type==pygame.KEYDOWN and e.key==pygame.K_ESCAPE:self.state='menu';return
    if e.type!=pygame.MOUSEBUTTONDOWN or e.button!=1:return
    for name,r in self.settings_rects().items():
        if not r.collidepoint(e.pos):continue
        if name=='speed05':self.menu_speed=.5
        elif name=='speed1':self.menu_speed=1.0
        elif name=='speed2':self.menu_speed=2.0
        elif name=='help':self.menu_show_help=not self.menu_show_help
        elif name=='audio':self.audio_enabled=not self.audio_enabled
        elif name=='fps':self.show_fps=not self.show_fps
        elif name=='perf':self.show_perf=not self.show_perf
        elif name=='fpscap':
            caps=[0,60,120,240];self.fps_cap=caps[(caps.index(self.fps_cap)+1)%len(caps)]
        elif name=='fullscreen':self.cycle_display_mode()
        elif name=='back':self.state='menu'
        return
KillZoneApp.handle_settings_event=_kz_handle_settings


def _kz_draw_settings(self):
    self.draw_menu_background();title=self.get_font(48).render('SETTINGS',True,COLORS['white']);self.screen.blit(title,(WINDOW_W//2-title.get_width()//2,75));self.text('DEFAULT SIMULATION SPEED',(WINDOW_W//2-330,194),16,'muted')
    for name,r in self.settings_rects().items():
        if name.startswith('speed') and name!='fpscap':
            val={'speed05':.5,'speed1':1.0,'speed2':2.0}[name];lab=f'{val:g}×';self.button(r,('[ '+lab+' ]') if self.menu_speed==val else lab,self.mouse,accent=self.menu_speed==val)
        elif name=='help':self.button(r,f'HELP ON BATTLE START: {"ON" if self.menu_show_help else "OFF"}',self.mouse,accent=self.menu_show_help)
        elif name=='audio':self.button(r,f'COMBAT AUDIO: {"ON" if self.audio_enabled else "OFF"}',self.mouse,accent=self.audio_enabled)
        elif name=='fps':self.button(r,f'FPS COUNTER: {"ON" if self.show_fps else "OFF"}',self.mouse,accent=self.show_fps)
        elif name=='perf':self.button(r,f'PERFORMANCE PROFILER: {"ON" if self.show_perf else "OFF"}',self.mouse,accent=self.show_perf)
        elif name=='fpscap':self.button(r,'RENDER FPS: UNCAPPED' if self.fps_cap==0 else f'RENDER FPS: {self.fps_cap}',self.mouse,accent=self.fps_cap==0)
        elif name=='fullscreen':
            mode={'windowed':'WINDOWED','borderless':'BORDERLESS FULLSCREEN','exclusive':'EXCLUSIVE FULLSCREEN'}.get(self.display_mode,self.display_mode.upper())
            self.button(r,f'DISPLAY MODE: {mode}  (F11 toggle)',self.mouse,accent=self.display_mode!='windowed')
        elif name=='back':self.button(r,'BACK',self.mouse)
KillZoneApp.draw_settings=_kz_draw_settings


def _kz_draw_help(self):
    w,h=860,650;x=(WINDOW_W-w)//2;y=(WINDOW_H-h)//2
    ov=pygame.Surface((w,h),pygame.SRCALPHA);ov.fill((20,23,20,244));self.screen.blit(ov,(x,y));pygame.draw.rect(self.screen,COLORS['select'],(x,y,w,h),2)
    self.text('REALTIME FIELD MANUAL',(x+22,y+16),24,'white')
    lines=[
        'LMB select / drag box | RMB move/attack | Shift+RMB queue | Space pause and plan orders',
        'Middle-drag camera | arrows/edge scroll | mouse wheel zoom | Home focus selection | F11 fullscreen toggle',
        'Alt+1..5 assign persistent Squad A–E | click squad tabs to select | Ctrl+1..9 control groups',
        'F2 ASSAULT then RMB objective: support-by-fire + smoke + assault movement | F3 bounding overwatch',
        'Left Alt directional cover intel | hover enemy for LOS/hit preview | hover ground for route/exposure/ETA',
        'Tab threat overlay | F4 formation | F7 fire discipline | F8 target priority | F10 autonomy',
        'F12 commits reserves | F9 performance profiler | renderer is uncapped by default',
        'MG/HMG suppression creates movement windows; crossfire and enfilade degrade defensive stability',
        'Mortars require 5–19 tile range and range-in; Recon/Marksman observation tightens dispersion',
        'Snipers gain concealment/first-shot benefits when settled; repeated fire increases signature',
        'Friendly troops locally avoid traffic jams; trench destinations compress formations into column',
        'Difficulty changes numbers and tactical coordination, not hidden accuracy bonuses',
        '',
        'ATTACKING PREPARED POSITIONS',
        '1. Recon the line and identify MG sectors.  2. Suppress or overload the position from two bearings.',
        '3. Layer smoke across the dangerous crossing.  4. Move assault troops while support keeps firing.',
        '5. Enter along a flank/enfilade angle; defenders may fall back to secondary positions instead of last-standing.',
        '',
        'PERFORMANCE',
        'Pathfinding and AI decisions are budgeted across ticks; threat/occupancy are cached and transient effects are capped.',
        'The F9 profiler shows simulation, path and AI milliseconds. Render FPS can be capped again in Settings if desired.',
    ]
    yy=y+54
    for line in lines:self.text(line,(x+22,yy),11,'select' if line in ('ATTACKING PREPARED POSITIONS','PERFORMANCE') else 'text' if line and line[0].isdigit() else 'muted');yy+=22
KillZoneApp.draw_help=_kz_draw_help


_old_run=KillZoneApp.run
def _kz_run(self):
    while self.running:
        real_dt=min(.05,self.clock.tick(self.fps_cap)/1000.0 if self.fps_cap else self.clock.tick(0)/1000.0)
        self.mouse=self.display_to_logical(pygame.mouse.get_pos());self.update_camera(real_dt)
        if time.time()<self.shake_until:
            self.shake_offset=(random.randint(-int(self.shake_strength),int(self.shake_strength)),random.randint(-int(self.shake_strength),int(self.shake_strength)));self.shake_strength=max(1,self.shake_strength*.92)
        else:self.shake_offset=(0,0);self.shake_strength=0
        for e in pygame.event.get():self.handle_event(e)
        if self.state=='game' and not self.game.paused:
            slow=.25 if pygame.key.get_pressed()[pygame.K_BACKQUOTE] else 1.0;self.accum+=real_dt*self.speed*slow;steps=0
            while self.accum>=SIM_DT and steps<5:
                self.game.update(SIM_DT);self.accum-=SIM_DT;steps+=1
            if steps>=5:self.accum=min(self.accum,SIM_DT*2)
            for ev in self.game.drain_events():self.play_event(ev)
        if time.time()>=self.asset_refresh_at:self.refresh_assets();self.asset_refresh_at=time.time()+2.0
        self.draw()
    pygame.quit()
KillZoneApp.run=_kz_run


# =============================================================================
# KILL ZONE — VERTICAL SLICE / BATTLE EXPERIENCE PASS
# =============================================================================
# Turns the realtime sandbox into a structured assault battle.  This pass avoids
# unit-symbol animation by design; the NATO markers remain static and readable.

MISSION_VARIANTS = {
    'farmland': {
        'name': 'OPEN FARMLAND',
        'brief': 'Prepared trench line across open agricultural ground. Smoke and support-by-fire are essential.',
    },
    'wooded_ridge': {
        'name': 'WOODED RIDGE',
        'brief': 'Broken woodland and folds in the ground provide covered approaches, but fields of fire open suddenly.',
    },
    'ruined_village': {
        'name': 'RUINED VILLAGE',
        'brief': 'A damaged settlement sits astride the approach. Expect short sight lines and strongpoint fighting.',
    },
    'hill_line': {
        'name': 'RIDGELINE',
        'brief': 'The defensive line sits on rising ground. Reverse slopes and dead ground matter more than raw distance.',
    },
}

ROLE_CONTACT = {
    'Rifleman':'INFANTRY','Machine Gunner':'MACHINE GUN','Sniper':'SNIPER','Medic':'MEDIC',
    'Engineer':'ENGINEER','Recon':'RECON','Grenadier':'GRENADIER','Assault':'ASSAULT INFANTRY',
    'Automatic Rifleman':'AUTOMATIC RIFLE','Marksman':'MARKSMAN','HMG Crew':'HEAVY MG','Mortar Team':'MORTAR',
}

PLAYER_SURNAMES = [
    'Murphy','Byrne','Kelly','Ryan','Doyle','Walsh','Nolan','Keane','Moran','Hayes','Reilly','Flynn',
    'Carroll','Quinn','Brennan','Kavanagh','Daly','Foley','Casey','Murray','OBrien','Sullivan','Lynch','Power',
]


def _vs_sector_name(y):
    if y < MAP_H/3:return 'NORTH'
    if y > MAP_H*2/3:return 'SOUTH'
    return 'CENTRE'


def _vs_nearest_open(self, x, y, unit=None, radius=5, prefer=None):
    prefer=prefer or ('trench','firing_step','bunker','sandbags','foxhole','dugout','crater','open')
    choices=[]
    for rr in range(radius+1):
        for yy in range(max(1,y-rr),min(MAP_H-1,y+rr+1)):
            for xx in range(max(1,x-rr),min(MAP_W-1,x+rr+1)):
                if abs(xx-x)+abs(yy-y)>rr:continue
                if not self.passable(xx,yy,unit):continue
                t=self.grid[yy][xx].terrain
                rank=prefer.index(t) if t in prefer else len(prefer)+2
                choices.append((rank,abs(xx-x)+abs(yy-y),xx,yy))
        if choices:break
    if not choices:return None
    choices.sort()
    return (choices[0][2],choices[0][3])
RealTimeGame.nearest_open=_vs_nearest_open


# ---------------------------- variant-aware tactical map ---------------------
_vs_base_generate_map = RealTimeGame.generate_map
def _vs_generate_map(self):
    _vs_base_generate_map(self)
    variants=list(MISSION_VARIANTS)
    self.battle_variant=variants[self.seed % len(variants)]
    p=self.primary_line_x;s=self.secondary_line_x
    variant=self.battle_variant
    # Deterministic local RNG so decorative/variant work does not perturb combat RNG.
    vr=random.Random(self.seed ^ 0x5A17C0DE)
    if variant=='farmland':
        # Wider open lanes broken by sparse walls and shell holes.
        for _ in range(16):
            y=vr.randint(3,MAP_H-4);x0=vr.randint(10,max(11,p-13));length=vr.randint(3,7)
            for x in range(x0,min(p-6,x0+length)):
                if self.grid[y][x].terrain=='open' and vr.random()<.72:self.set_cell(x,y,'wall')
    elif variant=='wooded_ridge':
        for base_y in (6,MAP_H-7):
            for _ in range(55):
                x=vr.randint(8,max(9,p-6));y=int(clamp(base_y+vr.randint(-5,5),2,MAP_H-3))
                if self.grid[y][x].terrain in ('open','mud','hill'):
                    self.set_cell(x,y,'woods' if vr.random()<.72 else 'hill')
    elif variant=='ruined_village':
        # Several small broken compounds, with deliberate gaps so pathing never seals the map.
        for bi in range(3):
            bx=vr.randint(14,max(15,p-12));by=vr.randint(4,MAP_H-10)
            w=vr.choice((4,5));h=vr.choice((4,5))
            for x in range(bx,bx+w):
                for y in (by,by+h):
                    if self.in_bounds(x,y):self.set_cell(x,y,'building' if vr.random()>.28 else 'rubble')
            for y in range(by,by+h+1):
                for x in (bx,bx+w):
                    if self.in_bounds(x,y):self.set_cell(x,y,'building' if vr.random()>.28 else 'rubble')
            if self.in_bounds(bx+w//2,by+h):self.set_cell(bx+w//2,by+h,'door')
    else:  # hill_line
        for _ in range(95):
            x=vr.randint(12,min(MAP_W-2,p+2));y=vr.randint(2,MAP_H-3)
            if self.grid[y][x].terrain in ('open','mud') and vr.random()<.72:self.set_cell(x,y,'hill')
    # A recognisable command position anchors the final objective.
    command=(MAP_W-4,MAP_H//2)
    cx,cy=command
    self.set_cell(cx,cy,'bunker')
    for dx,dy in ((-1,0),(0,-1),(0,1),(-1,-1),(-1,1)):
        if self.in_bounds(cx+dx,cy+dy) and self.grid[cy+dy][cx+dx].terrain not in ('trench','bunker'):
            self.set_cell(cx+dx,cy+dy,'sandbags')
    # The central bunker on Line 1 becomes the intermediate strongpoint.
    strong=(min(MAP_W-3,p+2),MAP_H//2)
    self.set_cell(*strong,'bunker')
    self.map_features.update({'variant':variant,'command_post':command,'strongpoint':strong})
RealTimeGame.generate_map=_vs_generate_map


# ----------------------------- unit identity / force plan --------------------
_vs_prev_add_unit = RealTimeGame.add_unit
def _vs_add_unit(self,faction,role,x,y):
    u=_vs_prev_add_unit(self,faction,role,x,y)
    rr=random.Random((self.seed<<9) ^ (u.uid*7919) ^ (1 if faction=='player' else 7))
    if faction=='player':
        letter=chr(64+max(1,min(5,getattr(u,'squad_id',1))))
        slot=((u.uid-1)%4)+1
        u.display_name=f'{letter}{slot} {rr.choice(PLAYER_SURNAMES)}'
    else:
        u.display_name=f'{_vs_sector_name(y).title()} {ROLE_CONTACT.get(role,role).title()}'
    u.battle_role='line';u.battle_sector=_vs_sector_name(y);u.reserve_active=True
    u.plan_state='hold';u.counterattack_point=None;u.initial_battle_role='line'
    return u
RealTimeGame.add_unit=_vs_add_unit


_vs_prev_spawn = RealTimeGame.spawn_default_forces
def _vs_spawn_default_forces(self):
    _vs_prev_spawn(self)
    enemies=[u for u in self.units if u.faction=='enemy']
    p=self.primary_line_x;s=self.secondary_line_x;cmd=self.map_features.get('command_post',(MAP_W-4,MAP_H//2))
    # Keep a real reserve instead of placing the whole enemy force on the firing line.
    n=len(enemies);reserve_n=max(2,int(round(n*.28)));command_n=max(1,int(round(n*.12)))
    # Sort rear-most units first for reserve/command assignment so we disturb positions minimally.
    ordered=sorted(enemies,key=lambda u:(u.x,u.uid),reverse=True)
    command_group=ordered[:command_n];reserve_group=ordered[command_n:command_n+reserve_n]
    for u in enemies:
        u.battle_sector=_vs_sector_name(u.y)
        u.initial_battle_role='forward';u.battle_role='forward';u.plan_state='hold';u.reserve_active=True
        u.fallback_point=(s,int(clamp(round(u.y),2,MAP_H-3)))
    for i,u in enumerate(reserve_group):
        u.initial_battle_role='reserve';u.battle_role='reserve';u.plan_state='reserve';u.reserve_active=False
        target=self.nearest_open(s,int(clamp(5+(i*7)%(MAP_H-8),2,MAP_H-3)),u,4)
        if target:u.x,u.y=target;_kz_rebuild_indexes(self)
        u.battle_sector=_vs_sector_name(u.y);u.fallback_point=(cmd[0]-1,int(clamp(round(u.y),2,MAP_H-3)))
    for i,u in enumerate(command_group):
        u.initial_battle_role='command';u.battle_role='command';u.plan_state='command';u.reserve_active=True
        target=self.nearest_open(cmd[0]-1,int(clamp(cmd[1]+i-1,2,MAP_H-3)),u,4)
        if target:u.x,u.y=target;_kz_rebuild_indexes(self)
        u.battle_sector=_vs_sector_name(u.y);u.fallback_point=cmd
    _kz_rebuild_indexes(self)
RealTimeGame.spawn_default_forces=_vs_spawn_default_forces


# ----------------------------- mission / objective model ---------------------
_vs_prev_rt_init = RealTimeGame.__init__
def _vs_rt_init(self,*args,**kwargs):
    _vs_prev_rt_init(self,*args,**kwargs)
    self.notifications=[];self._contact_last_report={};self._mission_timer=0.0;self._stability_timer=0.0
    self._counterattack_launched=False;self._reserves_activated=False;self._mission_complete_recorded=False
    self.combat_intensity=0.0;self.battle_stage='APPROACH';self._last_stage='APPROACH'
    self.initial_enemy_total=max(1,len([u for u in self.units if u.faction=='enemy']))
    self.initial_role_counts={r:max(1,len([u for u in self.units if u.faction=='enemy' and getattr(u,'initial_battle_role','')==r])) for r in ('forward','reserve','command')}
    self.initial_sector_counts={sec:max(1,len([u for u in self.units if u.faction=='enemy' and getattr(u,'battle_sector','')==sec and getattr(u,'initial_battle_role','')=='forward'])) for sec in ('NORTH','CENTRE','SOUTH')}
    self.sector_stability={sec:100.0 for sec in ('NORTH','CENTRE','SOUTH')};self.collapsed_sectors=set()
    p=self.primary_line_x;s=self.secondary_line_x;strong=self.map_features['strongpoint'];cmd=self.map_features['command_post']
    self.objectives=[
        {'title':'BREAK THE FORWARD LINE','desc':'Get a fighting element through Line 1 and force the defenders off the parapet.','pos':(p,MAP_H//2),'progress':0.0,'state':'active'},
        {'title':'SECURE THE STRONGPOINT','desc':'Clear and occupy the central bunker controlling the communication trenches.','pos':strong,'progress':0.0,'state':'locked'},
        {'title':'BREAK THE RESERVE LINE','desc':'Push through Line 2 before the reserve can stabilise the defence.','pos':(s,MAP_H//2),'progress':0.0,'state':'locked'},
        {'title':'CAPTURE THE COMMAND POST','desc':'Seize the rear command bunker or collapse the remaining defensive force.','pos':cmd,'progress':0.0,'state':'locked'},
    ]
    self.objective_index=0
    self.mission_title=f'ASSAULT — {MISSION_VARIANTS[self.battle_variant]["name"]}'
    self.mission_brief=MISSION_VARIANTS[self.battle_variant]['brief']
    self.notify('MISSION — Break the defensive line',kind='objective',duration=5.0)
    self._vs_event('mission',self.mission_title,(p,MAP_H//2))
RealTimeGame.__init__=_vs_rt_init


def _vs_event(self,kind,text,pos=None):
    _kz_event_record(self,kind,text,pos)
RealTimeGame._vs_event=_vs_event


def _vs_notify(self,text,kind='info',duration=4.0):
    if not hasattr(self,'notifications'):self.notifications=[]
    self.notifications.append({'text':text,'kind':kind,'until':self.time+duration,'born':self.time})
    self.notifications=self.notifications[-8:]
RealTimeGame.notify=_vs_notify


def _vs_current_objective(self):
    if 0<=self.objective_index<len(self.objectives):return self.objectives[self.objective_index]
    return None
RealTimeGame.current_objective=property(_vs_current_objective)


def _vs_activate_reserves(self,reason='Line 1 compromised'):
    if self._reserves_activated:return
    units=[u for u in self.living('enemy') if getattr(u,'initial_battle_role','')=='reserve']
    if not units:return
    self._reserves_activated=True
    for u in units:
        u.reserve_active=True;u.plan_state='reinforce'
        if u.role in ('Machine Gunner','HMG Crew'):
            u.fallback_point=(self.secondary_line_x,int(clamp(round(u.y),2,MAP_H-3)))
    self.notify('ENEMY RESERVES COMMITTED',kind='danger',duration=5)
    self._vs_event('reserve',f'Enemy reserves committed — {reason}',(self.secondary_line_x,MAP_H//2))
RealTimeGame.activate_enemy_reserves=_vs_activate_reserves


def _vs_launch_counterattack(self):
    if self._counterattack_launched:return
    candidates=[u for u in self.living('enemy') if u.combat_effective and getattr(u,'initial_battle_role','')=='reserve' and u.role in ('Assault','Rifleman','Grenadier','Automatic Rifleman')]
    if not candidates:
        candidates=[u for u in self.living('enemy') if u.combat_effective and getattr(u,'initial_battle_role','')=='reserve' and u.role not in ('Medic','Mortar Team')]
    if not candidates:return
    self._counterattack_launched=True
    count=1 if self.difficulty=='Easy' else 2 if self.difficulty=='Hard' else min(4,len(candidates))
    point=self.map_features['strongpoint']
    for u in candidates[:count]:
        u.reserve_active=True;u.plan_state='counterattack';u.counterattack_point=point
        self.issue_move([u],point,mode='safe',formation='column')
    self.notify('CONTACT — ENEMY COUNTERATTACK',kind='danger',duration=5)
    self._vs_event('counterattack','Enemy reserve counterattack launched',point)
RealTimeGame.launch_counterattack=_vs_launch_counterattack


def _vs_complete_objective(self):
    if not (0<=self.objective_index<len(self.objectives)):return
    obj=self.objectives[self.objective_index];obj['state']='complete';obj['progress']=1.0
    self.notify(f'OBJECTIVE COMPLETE — {obj["title"]}',kind='good',duration=5)
    self._vs_event('objective',f'Objective complete — {obj["title"]}',obj['pos'])
    done=self.objective_index;self.objective_index+=1
    if done==0:self.activate_enemy_reserves('forward line breached')
    if done==1:self.launch_counterattack()
    if self.objective_index<len(self.objectives):
        self.objectives[self.objective_index]['state']='active'
        nxt=self.objectives[self.objective_index]
        self.notify(f'NEW OBJECTIVE — {nxt["title"]}',kind='objective',duration=5)
    else:
        self.victory=True
        if not self._mission_complete_recorded:
            self._mission_complete_recorded=True;self._vs_event('victory','Enemy defensive system collapsed',self.map_features['command_post'])
RealTimeGame.complete_objective=_vs_complete_objective


def _vs_update_sector_stability(self):
    p=self.primary_line_x
    player_by_sector={sec:[u for u in self.living('player') if u.combat_effective and _vs_sector_name(u.y)==sec and u.x>=p-2] for sec in ('NORTH','CENTRE','SOUTH')}
    for sec in ('NORTH','CENTRE','SOUTH'):
        defenders=[u for u in self.units if u.faction=='enemy' and getattr(u,'initial_battle_role','')=='forward' and getattr(u,'battle_sector','')==sec]
        alive=[u for u in defenders if u.combat_effective]
        initial=max(1,self.initial_sector_counts.get(sec,len(defenders) or 1));loss=1-len(alive)/initial
        if alive:
            supp=sum(u.suppression for u in alive)/len(alive);morale=sum(u.morale for u in alive)/len(alive);cross=sum(self.crossfire_pressure(u) for u in alive)/len(alive)
        else:supp=100;morale=0;cross=1
        breach=1 if player_by_sector[sec] else 0
        stability=100-loss*45-supp*.30-(100-morale)*.22-cross*18-breach*24
        # Collapse in adjacent sectors undermines confidence but does not instantly domino the whole line.
        stability-=sum(1 for other in self.collapsed_sectors if other!=sec)*5
        self.sector_stability[sec]=clamp(stability,0,100)
        if stability<27 and sec not in self.collapsed_sectors:
            self.collapsed_sectors.add(sec)
            self.notify(f'ENEMY LINE COLLAPSING — {sec}',kind='good',duration=5)
            self._vs_event('collapse',f'{sec.title()} defensive sector collapsed',(p,{'NORTH':MAP_H//6,'CENTRE':MAP_H//2,'SOUTH':MAP_H*5//6}[sec]))
            for u in alive:
                # Unsupported, badly shaken defenders can surrender locally; others fall back to Line 2.
                friend_near=sum(1 for a in self.living('enemy') if a.uid!=u.uid and a.combat_effective and dist(a,u)<4.5)
                player_near=sum(1 for a in self.living('player') if a.combat_effective and dist(a,u)<3.5)
                if u.morale<22 and u.suppression>82 and friend_near<=1 and player_near:
                    u.casualty='surrendered';u.order='surrender';u.path=[];u.waypoints=[]
                    self.stats['enemy']['surrendered']+=1;self._vs_event('surrender',f'{u.display_name} surrendered',u.pos)
                else:
                    u.plan_state='fallback';fp=(self.secondary_line_x,int(clamp(round(u.y),2,MAP_H-3)))
                    u.fallback_point=fp
                    if u.deployed and u.role in ('Machine Gunner','HMG Crew'):self.toggle_deploy(u)
                    elif self.passable(*fp,u):self.issue_move([u],fp,mode='safe',formation='column')
RealTimeGame.update_sector_stability=_vs_update_sector_stability


def _vs_update_local_surrenders(self):
    for u in list(self.living('enemy')):
        if not u.combat_effective or u.casualty=='surrendered':continue
        if u.morale>23 or u.suppression<82:continue
        friends=[a for a in self.living('enemy') if a.uid!=u.uid and a.combat_effective and dist(a,u)<5]
        attackers=[a for a in self.living('player') if a.combat_effective and dist(a,u)<3.2]
        rear_cut=any(a.x>u.x+.5 for a in attackers)
        if attackers and len(friends)<=1 and (rear_cut or u.morale<12):
            # Deterministic threshold avoids dicey surrender spam while still making isolation decisive.
            score=(24-u.morale)+(u.suppression-80)*.35+len(attackers)*3-len(friends)*4
            if score>=18:
                u.casualty='surrendered';u.order='surrender';u.path=[];u.waypoints=[];u.command_queue=[]
                self.stats['enemy']['surrendered']+=1
                self.notify(f'ENEMY SECTION SURRENDERS — {u.battle_sector}',kind='good',duration=4)
                self._vs_event('surrender',f'{u.display_name} surrendered',u.pos)
RealTimeGame.update_local_surrenders=_vs_update_local_surrenders


def _vs_update_objectives(self):
    if self.victory or self.defeat:return
    p=self.primary_line_x;s=self.secondary_line_x
    players=[u for u in self.living('player') if u.combat_effective]
    enemies=[u for u in self.living('enemy') if u.combat_effective]
    if not players:self.defeat=True;return
    idx=self.objective_index
    if idx>=len(self.objectives):self.victory=True;return
    obj=self.objectives[idx]
    if idx==0:
        crossers=[u for u in players if u.x>=p-1]
        forward=[u for u in enemies if getattr(u,'initial_battle_role','')=='forward']
        rem=len(forward)/max(1,self.initial_role_counts['forward'])
        obj['progress']=clamp(.55*min(1,len(crossers)/2)+.45*(1-rem),0,1)
        if len(crossers)>=2 and (rem<=.58 or self.collapsed_sectors):self.complete_objective()
    elif idx==1:
        pos=obj['pos'];near_p=[u for u in players if dist(u.pos,pos)<=2.4];near_e=[u for u in enemies if dist(u.pos,pos)<=4.0]
        closest=min((dist(u.pos,pos) for u in players),default=99);obj['progress']=clamp(1-closest/12,0,.82 if near_e else 1)
        if near_p and not near_e:self.complete_objective()
    elif idx==2:
        crossers=[u for u in players if u.x>=s-1]
        reserve=[u for u in enemies if getattr(u,'initial_battle_role','') in ('reserve','forward') and u.x>=p]
        obj['progress']=clamp(.60*min(1,len(crossers)/2)+.40*(1-len(reserve)/max(1,self.initial_role_counts['forward']+self.initial_role_counts['reserve'])),0,1)
        if len(crossers)>=2 and (len(reserve)<=max(2,self.initial_enemy_total//4) or len(self.collapsed_sectors)>=2):self.complete_objective()
    else:
        pos=obj['pos'];near_p=[u for u in players if dist(u.pos,pos)<=2.7];near_e=[u for u in enemies if dist(u.pos,pos)<=4.3]
        enemy_ratio=len(enemies)/max(1,self.initial_enemy_total);closest=min((dist(u.pos,pos) for u in players),default=99)
        obj['progress']=max(clamp(1-closest/15,0,1),clamp(1-enemy_ratio,0,1))
        if (near_p and not near_e) or enemy_ratio<=.20:self.complete_objective()
RealTimeGame.update_objectives=_vs_update_objectives


def _vs_update_battle_stage(self,dt):
    self.combat_intensity=max(0,self.combat_intensity-dt*1.8)
    if self.objective_index>=3 or len(self.collapsed_sectors)>=2:stage='COLLAPSE'
    elif self.objective_index>=1 or self.assault_orders:stage='ASSAULT'
    elif self.combat_intensity>5 or any(self.visible_to('player',u) for u in self.living('enemy')):stage='CONTACT'
    else:stage='APPROACH'
    if stage!=self.battle_stage:
        self._last_stage=self.battle_stage;self.battle_stage=stage
        labels={'CONTACT':'CONTACT — ENEMY ENGAGED','ASSAULT':'ASSAULT PHASE','COLLAPSE':'EXPLOIT — DEFENCE UNRAVELLING'}
        if stage in labels:self.notify(labels[stage],kind='objective' if stage=='ASSAULT' else 'good' if stage=='COLLAPSE' else 'danger',duration=4)
RealTimeGame.update_battle_stage=_vs_update_battle_stage


def _vs_update_mission(self,dt):
    self._mission_timer+=dt;self._stability_timer+=dt
    self.update_battle_stage(dt)
    if self._stability_timer>=.5:
        self._stability_timer=0
        self.update_sector_stability();self.update_local_surrenders();self.update_objectives()
        # Veteran reserves react earlier; easier AI waits for a real breach.
        forward=[u for u in self.living('enemy') if getattr(u,'initial_battle_role','')=='forward']
        ratio=len(forward)/max(1,self.initial_role_counts['forward'])
        trigger=.50 if self.difficulty=='Easy' else .68 if self.difficulty=='Hard' else .80
        if not self._reserves_activated and ratio<trigger:self.activate_enemy_reserves('forward casualties')
    self.notifications=[n for n in self.notifications if n['until']>self.time]
RealTimeGame.update_mission_state=_vs_update_mission


# Contact reporting wraps spotting without leaking hidden live positions.
_vs_prev_update_spotting=RealTimeGame.update_spotting
def _vs_update_spotting(self):
    _vs_prev_update_spotting(self)
    for uid,info,age in self.known_contacts('player',memory=10):
        if age>.08:continue
        last=self._contact_last_report.get(uid,-999)
        if self.time-last<8:continue
        self._contact_last_report[uid]=self.time
        role=ROLE_CONTACT.get(info.get('role',''),'INFANTRY');sec=_vs_sector_name(info['pos'][1])
        self.notify(f'CONTACT — {role}, {sec}',kind='danger',duration=3.8)
        self._vs_event('contact',f'Contact: {role}, {sec}',info['pos'])
RealTimeGame.update_spotting=_vs_update_spotting


# Intensity is driven by actual simulation events and feeds presentation/ambience.
_vs_prev_emit=RealTimeGame.emit
def _vs_emit(self,event_type,**payload):
    _vs_prev_emit(self,event_type,**payload)
    if event_type=='shot':self.combat_intensity=min(100,self.combat_intensity+1.2)
    elif event_type=='explosion':self.combat_intensity=min(100,self.combat_intensity+8)
    elif event_type=='hurt':self.combat_intensity=min(100,self.combat_intensity+2)
    elif event_type=='death':self.combat_intensity=min(100,self.combat_intensity+5)
RealTimeGame.emit=_vs_emit


# Battle-plan aware enemy AI.  It still uses the existing fair-contact logic.
_vs_prev_ai_decide2=RealTimeGame.ai_decide
def _vs_ai_decide(self,u):
    if u.faction=='enemy':
        role=getattr(u,'initial_battle_role','forward')
        if role=='reserve' and not getattr(u,'reserve_active',True):
            # Genuine reserve: stay hidden/prepared until committed.
            if u.role in ('Machine Gunner','HMG Crew') and not u.deployed:self.toggle_deploy(u);return
            if u.order not in ('overwatch','deploy'):self.set_overwatch(u,180,105)
            return
        if getattr(u,'plan_state','')=='counterattack' and getattr(u,'counterattack_point',None):
            point=u.counterattack_point
            visible=[p for p in self.living('player') if p.combat_effective and self.can_see(u,p)]
            if not visible and dist(u.pos,point)>2.5 and u.order in ('idle','overwatch'):
                self.issue_move([u],point,mode='safe',formation='column');return
        if role=='command' and self.objective_index<3:
            # Rear command group does not wander out of the final defensive area.
            visible=[p for p in self.living('player') if p.combat_effective and self.can_see(u,p)]
            if not visible:
                if u.order not in ('overwatch','deploy'):self.set_overwatch(u,180,120)
                return
        if getattr(u,'battle_sector','') in self.collapsed_sectors and u.x<self.secondary_line_x-.5 and u.order not in ('move','rout'):
            fp=(self.secondary_line_x,int(clamp(round(u.y),2,MAP_H-3)))
            if self.passable(*fp,u):self.issue_move([u],fp,mode='safe',formation='column');return
    _vs_prev_ai_decide2(self,u)
RealTimeGame.ai_decide=_vs_ai_decide


# Full modifier breakdown for the hover panel.
def _vs_shot_breakdown(self,a,t,mode=None,reaction=False):
    mode=mode or a.fire_mode;w=a.weapon;d=dist(a,t);mods=[]
    clear,smoke,soft_pen,_=self.line_info(a.pos,t.pos)
    if not clear:return {'chance':0,'mods':[('LINE OF SIGHT',-999)]}
    base=float(w['acc']);mods.append(('weapon base',base))
    range_mod=-max(0,d-2)*2.8;mods.append(('range',range_mod))
    cover_mod=-self.effective_cover(a,t)*9;mods.append(('cover',cover_mod))
    stance=STANCE[a.stance]['acc']+STANCE[t.stance]['hit'];mods.append(('stance',stance))
    supp=-a.suppression*.32;mods.append(('shooter suppression',supp))
    prep=a.prepared*7;mods.append(('prepared',prep))
    smoke_mod=-smoke*19;mods.append(('smoke',smoke_mod))
    pen=-soft_pen*7;mods.append(('intervening cover',pen))
    if mode=='snap':mods.append(('snap fire',-16))
    elif mode=='aimed':mods.append(('aimed fire',18+a.aim_progress*10))
    elif mode=='rapid':mods.append(('rapid fire',-12))
    incoming=angle_to(t,a);flank=angle_diff(t.facing,incoming)
    if flank>125:mods.append(('rear attack',22))
    elif flank>75:mods.append(('flank attack',11))
    tc=self.grid[t.tile[1]][t.tile[0]]
    if tc.terrain in ('trench','firing_step') and tc.axis:
        shot=angle_to(t,a);axis_deg=0 if tc.axis=='H' else 90;along=min(angle_diff(shot,axis_deg),angle_diff(shot,axis_deg+180))
        if along<28:mods.append(('enfilade',12))
    if d<=2.2 and a.role=='Assault':mods.append(('assault CQB',18))
    if self.weather=='rain':mods.append(('rain',-3))
    elif self.weather=='fog':mods.append(('fog',-7))
    return {'chance':self.hit_chance(a,t,mode,reaction),'range':d,'smoke':smoke,'soft_pen':soft_pen,'mods':mods}
RealTimeGame.shot_breakdown=_vs_shot_breakdown


# Update mission state after the existing optimized simulation step.
_vs_prev_update2=RealTimeGame.update
def _vs_update2(self,dt):
    _vs_prev_update2(self,dt)
    if not self.paused and not (self.victory or self.defeat):self.update_mission_state(dt)
RealTimeGame.update=_vs_update2


# ------------------------------ application flow -----------------------------
_vs_prev_app_init=KillZoneApp.__init__
def _vs_app_init(self):
    _vs_prev_app_init(self)
    self.briefing_ready=False;self._ambience_next=0.0;self._ambience_clock=time.perf_counter();self._ambient_channel=None
    self._procedural_audio={};self._vs_init_procedural_audio()
KillZoneApp.__init__=_vs_app_init


def _vs_prepare_briefing(self):
    roster=self.current_setup_roster()
    if not roster:return
    seed=int(self.seed_text) if self.seed_text.isdigit() else None
    self.battle_roster=list(roster);self.game=RealTimeGame(seed=seed,difficulty=self.setup_difficulty,player_roster=roster,reserve_count=self.setup_reserves)
    self.selected=[];self.command_mode='normal';self.show_threat=False;self.show_help=False;self.control_groups={i:[] for i in range(1,10)}
    self.deployment_active=False;self.battle_active=False;self.briefing_ready=True;self.state='briefing';self.camera_x=0;self.camera_y=max(0,MAP_H/2-10);self.clamp_camera()
KillZoneApp.start_battle=_vs_prepare_briefing


def _vs_begin_from_briefing(self):
    self.state='deployment';self.deployment_active=True;self.battle_active=False;self.briefing_ready=False
KillZoneApp.begin_deployment_from_briefing=_vs_begin_from_briefing


def _vs_handle_briefing_event(self,e):
    if e.type==pygame.QUIT:self.running=False;return
    if e.type==pygame.KEYDOWN:
        if e.key==pygame.K_ESCAPE:self.state='setup';return
        if e.key in (pygame.K_RETURN,pygame.K_SPACE):self.begin_deployment_from_briefing();return
    if e.type==pygame.MOUSEBUTTONDOWN and e.button==1:
        deploy=pygame.Rect(WINDOW_W//2-150,690,300,46);back=pygame.Rect(34,690,180,42)
        if deploy.collidepoint(e.pos):self.begin_deployment_from_briefing()
        elif back.collidepoint(e.pos):self.state='setup'
KillZoneApp.handle_briefing_event=_vs_handle_briefing_event


_vs_prev_handle_event2=KillZoneApp.handle_event
def _vs_handle_event2(self,e):
    if self.state=='briefing':return self.handle_briefing_event(e)
    return _vs_prev_handle_event2(self,e)
KillZoneApp.handle_event=_vs_handle_event2


def _vs_draw_briefing(self):
    self.draw_menu_background();self.text('MISSION BRIEFING',(70,55),38,'white');self.text(self.game.mission_title,(70,112),22,'select')
    lo,hi=self.game.enemy_estimate;self.text(f'Seed {self.game.seed}  •  {self.game.weather.upper()}  •  estimated enemy strength {lo}–{hi}',(70,151),13,'muted')
    self.text(self.game.mission_brief,(70,188),14,'text')
    self.text('TASK',(70,242),16,'select');yy=274
    for i,obj in enumerate(self.game.objectives,1):
        self.text(f'{i}. {obj["title"]}',(88,yy),16,'white');yy+=24;self.text(obj['desc'],(112,yy),12,'muted');yy+=39
    self.text('COMMANDER\'S NOTES',(790,242),16,'select')
    notes=[
        '• Recon before committing the whole force.',
        '• Suppression, smoke and crossfire are the intended tools for cracking Line 1.',
        '• Expect the enemy to fall back and commit a reserve rather than die in place.',
        '• A local breach can trigger a counterattack around the central strongpoint.',
        '• The final objective is the rear command bunker, not extermination of every defender.',
    ]
    yy2=278
    for line in notes:self.text(line,(806,yy2),12,'muted');yy2+=32
    self.button(pygame.Rect(WINDOW_W//2-150,690,300,46),'BEGIN DEPLOYMENT',self.mouse,accent=True);self.button(pygame.Rect(34,690,180,42),'BACK',self.mouse)
KillZoneApp.draw_briefing=_vs_draw_briefing


# ------------------------------ tactical overlays ----------------------------
def _vs_draw_objectives(self):
    for i,obj in enumerate(self.game.objectives):
        if obj['state']=='locked' and i>self.game.objective_index+1:continue
        sx,sy=self.world_to_screen(*obj['pos'])
        if not self.map_view_rect().inflate(40,40).collidepoint((sx,sy)):continue
        col=COLORS['good'] if obj['state']=='complete' else COLORS['objective'] if obj['state']=='active' else COLORS['muted']
        pygame.draw.circle(self.screen,col,(sx,sy),14,2);self.text(str(i+1),(sx-4,sy-9),12,col)
        if obj['state']=='active':self.text(obj['title'],(sx+18,sy-8),10,'white')
KillZoneApp.draw_objectives=_vs_draw_objectives


def _vs_draw_assault_plan(self):
    for ao in getattr(self.game,'assault_orders',[]):
        ds=self.world_to_screen(*ao.dest)
        support=[self.game.get_unit(uid) for uid in ao.support];assault=[self.game.get_unit(uid) for uid in ao.assault]
        support=[u for u in support if u and u.combat_effective];assault=[u for u in assault if u and u.combat_effective]
        for u in support:
            a=self.world_to_screen(u.x,u.y);pygame.draw.line(self.screen,COLORS['suppression'],a,ds,2)
        for u in assault:
            a=self.world_to_screen(u.x,u.y);pygame.draw.line(self.screen,COLORS['select'],a,ds,2)
        if support:self.text('SUPPORT / SUPPRESS',(ds[0]+18,ds[1]-28),10,'suppression')
        if assault:self.text('ASSAULT',(ds[0]+18,ds[1]-12),10,'select')
KillZoneApp.draw_assault_plan=_vs_draw_assault_plan


def _vs_draw_contact_intel(self):
    # Last-known contacts widen in uncertainty as they age; no live hidden position is used.
    for uid,info,age in self.game.known_contacts('player',memory=10):
        u=self.game.get_unit(uid)
        if u and self.game.visible_to('player',u):continue
        sx,sy=self.world_to_screen(*info['pos'])
        if not self.map_view_rect().collidepoint((sx,sy)):continue
        rad=int(8+age*2.0);pygame.draw.circle(self.screen,COLORS['contact'],(sx,sy),rad,1)
        ab=ROLE_CONTACT.get(info.get('role',''),'CONTACT').split()[0][:4]
        self.text(f'{ab}? {age:.0f}s',(sx+rad+3,sy-7),9,'contact')
KillZoneApp.draw_contact_intel=_vs_draw_contact_intel


def _vs_draw_notifications(self):
    x=MAP_X+12;y=MAP_Y+12
    for n in self.game.notifications[-4:]:
        col='danger' if n['kind']=='danger' else 'good' if n['kind']=='good' else 'objective' if n['kind']=='objective' else 'white'
        surf=self.get_font(12).render(n['text'],True,COLORS[col]);r=pygame.Rect(x,y,surf.get_width()+16,24);pygame.draw.rect(self.screen,(27,30,26),r);pygame.draw.rect(self.screen,COLORS[col],r,1);self.screen.blit(surf,(x+8,y+5));y+=28
KillZoneApp.draw_notifications=_vs_draw_notifications


def _vs_draw_objective_panel(self):
    obj=self.game.current_objective
    if not obj:return
    x=SIDEBAR_X+8;y=70;w=WINDOW_W-SIDEBAR_X-18
    pygame.draw.rect(self.screen,COLORS['panel2'],(x,y,w,82),border_radius=3);pygame.draw.rect(self.screen,COLORS['objective'],(x,y,w,82),1,border_radius=3)
    self.text(f'OBJECTIVE {self.game.objective_index+1}/{len(self.game.objectives)}',(x+10,y+8),11,'objective');self.text(obj['title'],(x+10,y+26),12,'white')
    pygame.draw.rect(self.screen,(25,27,24),(x+10,y+52,w-20,8));pygame.draw.rect(self.screen,COLORS['objective'],(x+10,y+52,int((w-20)*clamp(obj['progress'],0,1)),8));self.text(f'{obj["progress"]*100:.0f}%',(x+w-45,y+64),9,'muted')
KillZoneApp.draw_objective_panel=_vs_draw_objective_panel


_vs_prev_draw_map2=KillZoneApp.draw_map
def _vs_draw_map2(self):
    _vs_prev_draw_map2(self)
    if self.state in ('game','deployment'):
        self.draw_objectives();self.draw_contact_intel();self.draw_assault_plan();self.draw_notifications()
KillZoneApp.draw_map=_vs_draw_map2


_vs_prev_draw_sidebar2=KillZoneApp.draw_sidebar
def _vs_draw_sidebar2(self):
    x=SIDEBAR_X;w=WINDOW_W-x-12
    pygame.draw.rect(self.screen,COLORS['panel'],(x,MAP_Y,w,MAP_VIEW_H_PX))
    obj=self.game.current_objective
    y=MAP_Y+9
    if obj:
        pygame.draw.rect(self.screen,COLORS['panel2'],(x+8,y,w-16,76),border_radius=3);pygame.draw.rect(self.screen,COLORS['objective'],(x+8,y,w-16,76),1,border_radius=3)
        self.text(f'OBJECTIVE {self.game.objective_index+1}/{len(self.game.objectives)}',(x+16,y+7),10,'objective');self.text(obj['title'][:34],(x+16,y+24),11,'white')
        pygame.draw.rect(self.screen,(25,27,24),(x+16,y+48,w-32,7));pygame.draw.rect(self.screen,COLORS['objective'],(x+16,y+48,int((w-32)*clamp(obj['progress'],0,1)),7));self.text(f'{obj["progress"]*100:.0f}%',(x+w-45,y+59),9,'muted')
        y+=88
    self.text('SELECTED',(x+14,y),15,'white');y+=22;us=self.selected_units()
    if not us:self.text('No units selected',(x+14,y),12,'muted');y+=24
    else:
        firing=sum(1 for u in us if u.order=='fire');reloading=sum(1 for u in us if u.reload_timer>0);pinned=sum(1 for u in us if u.suppression>=80);wounded=sum(1 for u in us if u.casualty=='wounded')
        self.text(f'{len(us)} troops | fire {firing} rld {reloading} pin {pinned} wnd {wounded}',(x+14,y),10,'status');y+=18
        for u in us[:3]:
            name=getattr(u,'display_name',f'SQ{getattr(u,"squad_id",0)} #{u.uid}')
            self.text(f'{name} — {u.role}'[:39],(x+14,y),11,'select');y+=15
            self.text(f'HP {u.hp:.0f} MOR {u.morale:.0f} SUP {u.suppression:.0f} STA {u.stamina:.0f}',(x+14,y),10,'text');y+=14
            self.text(f'{u.weapon_name} {u.ammo} | {u.order} | {u.fire_discipline}',(x+14,y),9,'muted');y+=18
    report_y=max(y+5,MAP_Y+315);self.text('FIELD REPORT',(x+14,report_y),13,'white');yy=report_y+20
    for line in self.game.log[-7:]:self.text(line[:43],(x+14,yy),10,'muted');yy+=15
    # Sector stability makes defensive collapse legible without exposing hidden units.
    sec_y=min(MAP_Y+MAP_VIEW_H_PX-145,yy+7);self.text('ENEMY LINE STABILITY',(x+14,sec_y),10,'muted');sec_y+=15
    for sec in ('NORTH','CENTRE','SOUTH'):
        st=self.game.sector_stability.get(sec,100);col='danger' if st>65 else 'contact' if st>30 else 'good';self.text(f'{sec:6s} {st:3.0f}%'+('  COLLAPSED' if sec in self.game.collapsed_sectors else ''),(x+14,sec_y),9,col);sec_y+=14
    if pygame.key.get_pressed()[pygame.K_LALT]:
        cell=self.map_cell_from_mouse(self.mouse)
        if cell:
            cx,cy=cell;c=self.game.grid[cy][cx];td=TERRAIN[c.terrain];base=MAP_Y+MAP_VIEW_H_PX-96;pygame.draw.rect(self.screen,COLORS['panel2'],(x+8,base-5,w-16,88),border_radius=3);self.text('TILE INTEL [LALT]',(x+14,base),11,'select');self.text(f'{cell} {c.terrain.upper()} cover {td["cover"]} conceal {td["conceal"]}',(x+14,base+17),10,'white');self.text(f'move x{td["move"]:.2f} smoke {c.smoke:.1f} suppression {c.ground_suppression:.0f}',(x+14,base+34),10,'muted');self.text(f'known threat {self.game.tile_threat("player",cx,cy):.1f}',(x+14,base+51),10,'contact');self.text('edges: green strong / yellow partial / red open',(x+14,base+68),9,'muted')
KillZoneApp.draw_sidebar=_vs_draw_sidebar2

_vs_prev_draw_topbar2=KillZoneApp.draw_topbar
def _vs_draw_topbar2(self):
    _vs_prev_draw_topbar2(self)
    if self.state in ('game','deployment'):
        col='good' if self.game.battle_stage=='COLLAPSE' else 'danger' if self.game.battle_stage=='CONTACT' else 'objective' if self.game.battle_stage=='ASSAULT' else 'muted'
        self.text(self.game.battle_stage,(710,36),10,col)
KillZoneApp.draw_topbar=_vs_draw_topbar2


# Expanded hit-chance panel replaces the terse three-number readout with the
# major reasons behind the probability.  It stays compact enough for realtime.
_vs_prev_draw_los=KillZoneApp.draw_los_preview if hasattr(KillZoneApp,'draw_los_preview') else None
def _vs_draw_los_preview(self):
    if not self.selected:return
    u=self.selected_units()[0] if self.selected_units() else None;t=self.unit_at_pixel(self.mouse)
    if not u or not t or t.faction!='enemy':return
    a=self.world_to_screen(u.x,u.y);b=self.world_to_screen(t.x,t.y);bd=self.game.shot_breakdown(u,t);hc=bd['chance'];clear=hc>0
    col=COLORS['good'] if hc>=55 else COLORS['contact'] if clear else COLORS['danger'];pygame.draw.line(self.screen,col,a,b,2)
    box=pygame.Rect(MAP_X+12,MAP_Y+MAP_VIEW_H_PX-150,365,142);pygame.draw.rect(self.screen,COLORS['panel2'],box);pygame.draw.rect(self.screen,col,box,1)
    self.text(f'HIT {hc:.0f}%   RANGE {bd.get("range",0):.1f}/{u.weapon["range"]:.0f}',(box.x+8,box.y+7),12,'white')
    yy=box.y+27
    mods=[m for m in bd.get('mods',[]) if abs(m[1])>=2 and m[1]>-900]
    # show base plus the five strongest non-base modifiers
    if mods:
        base=mods[0];self.text(f'{base[0]:22s} {base[1]:+5.0f}',(box.x+8,yy),10,'muted');yy+=16
        for name,val in sorted(mods[1:],key=lambda z:abs(z[1]),reverse=True)[:5]:
            self.text(f'{name:22s} {val:+5.0f}',(box.x+8,yy),10,'good' if val>0 else 'danger');yy+=16
    status='PINNED' if t.suppression>=80 else 'SUPPRESSED' if t.suppression>=50 else 'UNDER FIRE' if t.suppression>=20 else 'CALM'
    self.text(f'target: {ROLE_CONTACT.get(t.role,t.role)} — {status}',(box.x+8,box.bottom-19),10,'contact')
KillZoneApp.draw_los_preview=_vs_draw_los_preview


# Static terrain detail: additional readability/texture without animating NATO units.
_vs_prev_draw_terrain2=KillZoneApp.draw_terrain
def _vs_draw_terrain2(self,c,r,x,y):
    _vs_prev_draw_terrain2(self,c,r,x,y)
    tp=max(1,r.w);seed=(x*73856093)^(y*19349663)^(self.game.seed*83492791);rr=random.Random(seed)
    ink=(38,40,34)
    if c.terrain in ('trench','firing_step'):
        pygame.draw.line(self.screen,(48,40,31),(r.left+2,r.top+3),(r.right-3,r.top+3),1);pygame.draw.line(self.screen,(48,40,31),(r.left+2,r.bottom-4),(r.right-3,r.bottom-4),1)
    elif c.terrain=='crater':
        pygame.draw.ellipse(self.screen,(54,47,39),r.inflate(-max(4,tp//4),-max(5,tp//3)),1)
    elif c.terrain=='woods':
        for _ in range(2):
            px=r.left+rr.randint(4,max(4,r.w-4));py=r.top+rr.randint(4,max(4,r.h-4));pygame.draw.circle(self.screen,(35,58,36),(px,py),max(2,tp//8))
    elif c.terrain in ('building','woodwall'):
        if rr.random()<.55:pygame.draw.line(self.screen,ink,(r.left+4,r.top+rr.randint(4,max(4,tp-4))),(r.right-5,r.top+rr.randint(4,max(4,tp-4))),1)
    elif c.terrain=='sandbags':
        for i in range(3):pygame.draw.circle(self.screen,(82,70,50),(r.left+5+i*max(3,tp//4),r.centery),max(2,tp//8),1)
KillZoneApp.draw_terrain=_vs_draw_terrain2


# ------------------------------ audio / ambience -----------------------------
def _vs_make_pcm_sound(self,kind,duration=.14):
    try:
        init=pygame.mixer.get_init()
        if not init:return None
        rate,bits,channels=init;rate=int(rate);channels=int(channels);samples=max(1,int(rate*duration));buf=bytearray();rr=random.Random(hash(kind)&0xffffffff);lp=0.0
        import struct
        for i in range(samples):
            t=i/max(1,samples-1);env=(1-t)**2
            if kind=='snap':v=(rr.random()*2-1)*env*(0.9 if i<samples*.3 else .35)
            elif kind=='impact':
                lp=lp*.82+(rr.random()*2-1)*.18;v=lp*env*.75
            elif kind=='thump':v=math.sin(2*math.pi*(58+24*t)*(i/rate))*env*.75+(rr.random()*2-1)*env*.08
            else:
                lp=lp*.97+(rr.random()*2-1)*.03;v=lp*.38*(.5+.5*math.sin(t*math.pi))
            n=int(clamp(v,-1,1)*22000)
            if abs(bits)==16:
                packed=struct.pack('<h',n)
            else:packed=bytes([int(clamp(128+n/256,0,255))])
            buf.extend(packed*channels)
        return pygame.mixer.Sound(buffer=bytes(buf))
    except Exception:return None


def _vs_init_audio(self):
    if not self.audio_enabled:return
    try:
        pygame.mixer.set_num_channels(max(12,pygame.mixer.get_num_channels()))
        for kind,dur in [('snap',.07),('impact',.12),('thump',.28),('wind',1.8)]:
            snd=self._vs_make_pcm_sound(kind,dur)
            if snd:self._procedural_audio[kind]=snd
    except Exception:pass
KillZoneApp._vs_make_pcm_sound=_vs_make_pcm_sound
KillZoneApp._vs_init_procedural_audio=_vs_init_audio


def _vs_listener(self):
    us=self.selected_units()
    if us:return (sum(u.x for u in us)/len(us),sum(u.y for u in us)/len(us))
    return (self.camera_x+MAP_VIEW_W_PX/self.tile_px/2,self.camera_y+MAP_VIEW_H_PX/self.tile_px/2)
KillZoneApp._vs_listener=_vs_listener


def _vs_play_channel(self,snd,vol):
    if not snd or vol<=.005:return
    try:
        ch=snd.play()
        if ch:ch.set_volume(clamp(vol,0,1))
    except Exception:pass
KillZoneApp._vs_play_channel=_vs_play_channel


_vs_prev_play_event2=KillZoneApp.play_event
def _vs_play_event2(self,ev):
    if not self.audio_enabled:return
    typ=ev.get('type');pos=ev.get('pos');listener=self._vs_listener();d=dist(listener,pos) if pos else 0
    attenuation=clamp(1-d/32,.08,1)
    # Preserve the existing throttle, but use distance-dependent channels and layered transients.
    now=time.perf_counter();minimum={'shot':.025,'explosion':.05,'hurt':.08,'death':.15}.get(typ,.03)
    if now-self._audio_last.get(typ,-99)<minimum:return
    if now-self._audio_window_start>.05:self._audio_window_start=now;self._audio_count=0
    if self._audio_count>=6:return
    self._audio_last[typ]=now;self._audio_count+=1
    if typ=='shot':
        w=ev.get('weapon','');name='rifle_762.mp3' if w in ('Scoped Rifle','Marksman Rifle','Heavy Machine Gun') else 'smg_9mm.mp3' if w=='SMG' else 'rifle_556.mp3'
        self._vs_play_channel(self.audio.get(name),(.32 if d<9 else .20 if d<18 else .10)*attenuation)
        if 3<d<15:self._vs_play_channel(self._procedural_audio.get('snap'),.10*attenuation)
    elif typ=='explosion':
        names=[n for n in ('explosion1.ogg','explosion2.ogg') if n in self.audio]
        if names:self._vs_play_channel(self.audio[random.choice(names)],.58*attenuation)
        self._vs_play_channel(self._procedural_audio.get('thump'),.25*attenuation);self._vs_play_channel(self._procedural_audio.get('impact'),.12*attenuation)
        if d<17:self.shake_until=time.time()+.22;self.shake_strength=max(self.shake_strength,4.0*attenuation)
    elif typ=='hurt' and ev.get('damage',0)>=20 and d<16:
        names=[n for n in ('hurt_01.mp3','hurt_03.mp3') if n in self.audio]
        if names:self._vs_play_channel(self.audio[random.choice(names)],.16*attenuation)
    elif typ=='death' and d<18:
        names=[n for n in ('scream_horror1.mp3','hurt_03.mp3') if n in self.audio]
        if names:self._vs_play_channel(self.audio[random.choice(names)],.14*attenuation)
KillZoneApp.play_event=_vs_play_event2


def _vs_update_ambience(self):
    if not self.audio_enabled or self.state!='game':return
    now=time.perf_counter()
    # Low, non-looping wind texture prevents dead silence without monopolising a mixer channel.
    if now>=self._ambience_next:
        intensity=getattr(self.game,'combat_intensity',0);stage=getattr(self.game,'battle_stage','APPROACH')
        gap=random.uniform(2.2,4.8) if intensity<8 else random.uniform(1.0,2.4)
        self._ambience_next=now+gap
        self._vs_play_channel(self._procedural_audio.get('wind'),.025 if self.game.weather=='clear' else .045)
        # Distant battle layer: it is presentation only and does not reveal contacts.
        if random.random()<(.22 if stage=='APPROACH' else .45 if stage=='CONTACT' else .62):
            if random.random()<.72:
                n=random.choice([n for n in ('rifle_556.mp3','rifle_762.mp3') if n in self.audio] or [''])
                self._vs_play_channel(self.audio.get(n),.035)
            else:
                n=random.choice([n for n in ('explosion1.ogg','explosion2.ogg') if n in self.audio] or [''])
                self._vs_play_channel(self.audio.get(n),.045)
KillZoneApp.update_ambience=_vs_update_ambience


# -------------------------- final battle presentation -------------------------
def _vs_draw_after_action(self):
    w,h=760,540;x=MAP_X+(MAP_VIEW_W_PX-w)//2;y=MAP_Y+35;pygame.draw.rect(self.screen,COLORS['panel'],(x,y,w,h));pygame.draw.rect(self.screen,COLORS['select'],(x,y,w,h),3)
    title='VICTORY — DEFENSIVE SYSTEM COLLAPSED' if self.game.victory else 'DEFEAT — ASSAULT BROKEN';self.text(title,(x+24,y+18),25,'white')
    self.text(f'{self.game.mission_title}   •   {self.game.time/60:.1f} min   •   Seed {self.game.seed}',(x+24,y+54),12,'muted')
    yy=y+90
    for f,label in [('player','YOUR FORCE'),('enemy','OPPOSITION')]:
        st=self.game.stats[f];alive=sum(1 for u in self.game.living(f) if u.combat_effective);acc=(100*st['hits']/st['shots']) if st['shots'] else 0
        self.text(label,(x+24,yy),15,'select');self.text(f'alive {alive}   casualties {st["casualties"]}   surrendered {st["surrendered"]}   kills {st["kills"]}',(x+150,yy+2),11,'white');yy+=23
        self.text(f'shots {st["shots"]}   hits {st["hits"]}   accuracy {acc:.1f}%   grenades {st["grenades"]}   smoke {st["smoke"]}   reserves {st["reserves"]}',(x+38,yy),11,'muted');yy+=34
    self.text('OBJECTIVES',(x+24,yy),14,'select');yy+=23
    for i,obj in enumerate(self.game.objectives,1):
        mark='✓' if obj['state']=='complete' else '—';self.text(f'{mark} {i}. {obj["title"]}',(x+38,yy),11,'good' if obj['state']=='complete' else 'muted');yy+=18
    yy+=8;self.text('KEY EVENTS',(x+24,yy),14,'select');yy+=22
    important=[e for e in self.game.battle_events if e['kind'] in ('objective','collapse','counterattack','reserve','surrender','victory','death')]
    for ev in important[-9:]:
        self.text(f'{ev["time"]/60:4.1f}m  {ev["text"]}'[:94],(x+38,yy),10,'muted');yy+=17
    self.text('F5 replay same force • Esc main menu',(x+24,y+h-27),11,'white')
KillZoneApp.draw_after_action=_vs_draw_after_action


# Draw dispatcher adds briefing and ambience, but does not animate NATO markers.
_vs_prev_draw2=KillZoneApp.draw
def _vs_draw2(self):
    self.update_ambience()
    if self.state=='briefing':
        self.screen.fill(COLORS['bg']);self.draw_briefing();self.present();return
    _vs_prev_draw2(self)
KillZoneApp.draw=_vs_draw2


# Make the top-level help explicitly describe the complete battle flow.
_vs_prev_help2=KillZoneApp.draw_help
def _vs_draw_help2(self):
    _vs_prev_help2(self)
    # Small footer only; avoids replacing the already dense field manual.
    self.text('Battle flow: Briefing → Force → Deployment → staged objectives → After Action',(WINDOW_W//2-330,WINDOW_H-53),10,'objective')
KillZoneApp.draw_help=_vs_draw_help2


def main():
    if pygame is None:
        print("Kill Zone Realtime requires pygame. Install with: py -m pip install pygame")
        raise SystemExit(1)
    app=KillZoneApp();app.run()


if __name__=="__main__":
    main()
